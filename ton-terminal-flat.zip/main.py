"""Entrypoint shim for PaaS hosts (Railway / Nixpacks / Heroku-style).

Some hosts launch ``uvicorn app.api.main:app`` directly from a working
directory that is NOT the project root, and modern uvicorn no longer adds the
cwd to ``sys.path`` - which produces ``ModuleNotFoundError: No module named
'app'``. Importing through this shim guarantees the project root is on
``sys.path`` first.

Usage:  uvicorn main:app --host 0.0.0.0 --port $PORT
"""
from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app.api.main import app  # noqa: E402

__all__ = ["app"]
