# 🚀 TON NFT Trading Terminal

An **all-in-one, non-custodial** TON NFT trading terminal: Telegram bot + Telegram Mini App +
analytics engine + DEX/marketplace adapters.

> Discovery, market intelligence, portfolio tracking, wallet connection, NFT buy/sell, TON/USDT
> swaps, alerts, **paper trading** and **strategy automation** — beginner friendly, with the depth
> experienced NFT traders expect.

---

## 1. Quick start (local)

```bash
git clone <your-repo> && cd ton-nft-terminal
python -m venv .venv && source .venv/bin/activate
make install                       # backend dependencies
cp .env.example .env               # then edit it
make api                           # http://localhost:8000  (API + Mini App)
```

Open **http://localhost:8000** for the Mini App, or **/docs** for the interactive API.

Run the Telegram bot (needs `TELEGRAM_BOT_TOKEN`):

```bash
make bot
```

Build the Mini App yourself (the API serves `miniapp/dist` if it exists):

```bash
make install-miniapp && make build-miniapp
```

### Docker (PostgreSQL + Redis + API + bot)

```bash
cp .env.example .env && make docker-up
```

### Index and scan your first collection

```bash
python scripts/scan_collection.py EQ… --items 100 --min-score 40
python scripts/set_monitor.py EQ…        # let the background scanner watch it
python scripts/set_monitor.py --list
```

Database migrations:

```bash
make migrate                             # alembic upgrade head
make revision m="add table x"            # autogenerate a new revision
```

---

## 2. What is implemented

| Area | Status | Notes |
|---|---|---|
| Telegram bot (aiogram 3) | ✅ | 14 commands, inline menus, premium custom-emoji rendering |
| Telegram Mini App (React + TS + Vite) | ✅ | 10 screens, TON Connect UI, mobile-first |
| TON Connect | ✅ | connect, address, `ton_proof` verification, tx requests, backend verification |
| TON Center API v3 client | ✅ | rate limited, retried, cached, documented endpoints only |
| NFT metadata engine | ✅ | HTTP + IPFS, malformed/missing metadata, DB + Redis cache |
| Rarity engine (traits **and** combinations) | ✅ | statistical rarity, log-normalised 0–100, known matches |
| Rare number engine | ✅ | 0/1/7/69/100/111/420/777/888, palindromes, repeats, sequential, mirrored, custom patterns |
| Fair value engine | ✅ | floor + comparables + rarity + number premium + liquidity + trend, with confidence |
| Liquidity engine | ✅ | 0–100 score, risk band, `HIGH VALUE + LOW LIQUIDITY` warning |
| Collection health & trend | ✅ | floor movement, sales activity, volume, buyer/seller balance, listing pressure |
| Market anomaly detector | ✅ | 7 detectors, every flag carries its evidence |
| Whale analytics | ✅ | accumulation/distribution from public sales, labelled as a signal |
| Market Radar + opportunity score (0–100) | ✅ | fully explainable components |
| Opportunity replay (24/48/72 h) | ✅ | theoretical vs actual, past-performance disclaimer |
| Watchlist | ✅ | NFT / collection / price / discount conditions |
| Portfolio | ✅ | balances, holdings, realised vs unrealised P/L, history |
| Paper trading | ✅ | ROI, P/L, win rate, drawdown, best/worst |
| Strategy builder | ✅ | alert / paper / assisted modes, rule engine |
| DEX adapter system | ✅ | STON.fi + DeDust |
| Marketplace adapter system | ✅ | Portals (inactive, documented) + TonAPI (read-only) |
| Buy / sell flows | ✅ | prepare → wallet approval → on-chain verification |
| Swap flow | ✅ | live quote → wallet → verification |
| PostgreSQL schema (18 tables) | ✅ | SQLite supported for local dev |
| Redis caching / rate limiting / locks | ✅ | in-process fallback when Redis is absent |
| Background workers | ✅ | dependency-free asyncio scheduler |
| Tests | ✅ | 72 tests: financial maths, metadata, security, API integration |
| Docker, `.env.example`, Alembic | ✅ | initial migration `8ca6fe2b20d2` (18 tables) |
| Webhook transport | ✅ | `POST /telegram/webhook` + `/telegram/webhook/setup` (secret-token protected) |

---

## 3. External APIs — what was verified

Every integration below was checked against **current official documentation and the live API**
before any code was written. Nothing is invented; unsupported capabilities raise a typed error
instead of returning fake data.

| Provider | Docs | Endpoints used | Capability |
|---|---|---|---|
| **TON Center API v3** | [docs.ton.org/api/v3](https://docs.ton.org/api/v3/overview) | `/masterchainInfo`, `/accountStates`, `/walletStates`, `/addressBook`, `/metadata`, `/transactions`, `/actions`, `/nft/collections`, `/nft/items`, `/nft/transfers`, `/nft/sales`, `/jetton/masters`, `/jetton/wallets`, `/jetton/transfers` | ✅ Indexed blockchain + NFT + jetton data. `action_type=nft_purchase` provides **real sales** (price, buyer, seller, marketplace). |
| **TON Connect** | [docs.ton.org/applications/ton-connect](https://docs.ton.org/applications/ton-connect/get-started) | manifest, `ton_proof`, transaction requests | ✅ Wallet connect/authorisation. Address/public key only — never a seed phrase. |
| **STON.fi DEX API v1** | [docs.ston.fi](https://docs.ston.fi/developer-section/dex/api/reference) | `GET /v1/assets`, `GET /v1/pools/by_market/{a0}/{a1}`, `POST /v1/swap/simulate` (query params) | ✅ **Live quotes** (rate, min received, price impact, fees, gas). Transaction payloads must be built with the official `@ston-fi/sdk` / Omniston SDK — the adapter returns every SDK parameter and never fabricates a BOC. |
| **DeDust** | [docs.dedust.io](https://docs.dedust.io/reference/getting-available-pools) | `GET /v2/pools`, `GET /v2/pools/{address}/trades` | ⚠️ **Pool data only.** DeDust publishes no REST quote endpoint; quotes are computed locally from public reserves (constant product) and flagged `estimate_only`. Swaps execute via `@dedust/sdk`. |
| **TonAPI** | [docs.tonconsole.com/tonapi](https://docs.tonconsole.com/tonapi) | `GET /v2/nfts/{id}`, `GET /v2/nfts/collections/{id}`, `GET /v2/nfts/collections/{id}/items`, `GET /v2/accounts/{id}/nfts` | ✅ Read-only NFT/sale data (optional API key raises limits). |
| **Portals** | [portals.to](https://portals.to) | — | ❌ **No documented public API** (only unofficial reverse-engineered clients exist, which this project refuses to use). The adapter ships the full interface plus an endpoint map; it reports `unavailable` until official credentials are supplied. |

Adding a marketplace later = implement `MarketplaceAdapter` and register it in
`app/integrations/marketplaces/registry.py`. Nothing else changes.

**Live quirks we hit and handled** (full details in [`docs/PROVIDERS.md`](docs/PROVIDERS.md)):

* STON.fi `POST /v1/swap/simulate` takes its parameters in the **query string** (a JSON body is
  rejected).
* TON Center's `/actions?action_type=nft_purchase` **times out** when `start_utime` is used — time
  windows are applied client-side.
* DeDust publishes **no REST quote endpoint**; its quotes are computed from public reserves and
  flagged `estimate_only`.
* Some collections expose **256-bit item indexes**, which are ignored as collector numbers.

---

## 4. Architecture

```
app/
├── bot/             aiogram 3 bot: commands, callbacks, keyboards
│   ├── emojis.py    ⭐ ONE place for every Telegram custom emoji id
│   ├── formatting.py  premium message templates ("{radar}" tokens)
│   └── handlers/    commands + callbacks
├── api/             FastAPI: /api/* routers, deps (initData auth), static Mini App
├── core/            config, logging (secret redaction), http (retry/rate limit),
│                    cache (Redis/memory), rate limit, money (Decimal helpers), errors
├── database/        SQLAlchemy base + async session (Postgres or SQLite)
├── models/          ORM (18 tables) + enums
├── services/        users, wallets, market, opportunities, portfolio, trading,
│                    swaps, watchlist, strategies, paper, notifications
├── integrations/
│   ├── toncenter/   documented API v3 client
│   ├── tonconnect/  manifest, ton_proof verification, tx verification
│   ├── marketplaces/ base + portals + tonapi + registry
│   └── dex/         base + stonfi + dedust + registry
├── nft/             metadata, numbers, traits, rarity, valuation, liquidity, analyzer
├── radar/           scoring, stats (health), anomaly, whale, replay
├── portfolio/       portfolio service lives in services/portfolio.py
├── workers/         asyncio scheduler + metadata/scanner/strategy/watchlist/replay workers
├── security/        initData validation, secret hygiene
└── tests/           66 tests (unit + integration with mocked providers)
miniapp/             React + TypeScript + Vite + TON Connect UI
```

**Data flow**

```
Telegram Mini App ──(initData)──► FastAPI ──► services ──► adapters ──► TON Center / STON.fi / DeDust / TonAPI
        │                            │                        │
        └── TON Connect ──► wallet ──┘                        └──► PostgreSQL (permanent) + Redis (ephemeral)
                    ▲
        user approves every transaction in their own wallet
```

---

## 5. ⭐ Premium custom emoji system

All ids live in **one** dict — `app/bot/emojis.py`:

```python
CUSTOM_EMOJIS = {
    "one": "5247133031235329609",
    "two": "5246772116543512028",
    "three": "5249273776079640466",
    "four": "5247176827016847212",
    "five": "5246960163096632543",
    "six": "524720927549",
    "wallet": "",   # add ids here as you collect them
    "ton": "",
    ...
}
```

Usage in templates:

```python
text = f"{e('radar')} NFT RADAR\n{e('ton')} Listed: 50 TON"
rendered = render(text)
await message.answer(rendered.text, entities=rendered.entities)
```

* `render()` converts `{name}` tokens into real `custom_emoji` entities
  (`MessageEntity(type="custom_emoji", custom_emoji_id=…)`, UTF-16 offsets) — ids are **never**
  printed as text.
* Missing or malformed ids (e.g. the short `six` id above) fall back to the Unicode glyph and are
  reported by `validate_ids()` — the UI degrades gracefully.
* Adding an id = one line in `CUSTOM_EMOJIS`. No id is ever hardcoded elsewhere.

---

## 6. Safety & non-custodial guarantees

1. Seed phrases, private keys and wallet passwords are **never** requested, transmitted or stored.
2. The backend never signs or submits a transaction; it only prepares intents the **user approves in
   their own wallet**.
3. API keys are server-side only (env vars) and are redacted from logs and from every response; the
   Mini App only receives `public_config()`.
4. `ENABLE_REAL_TRADING=false` by default — real-money execution is off; use Paper Mode.
5. Every transaction is re-verified against the blockchain (TON Center) before being marked confirmed.
6. No adapter fabricates data: unavailable capabilities raise `CapabilityNotSupported` /
   `ProviderUnavailable` and the UI explains why.
7. Fees, royalties, slippage and liquidity are always part of the calculation — never hidden.
8. Theoretical P/L and realised P/L are reported separately, and every estimate carries a
   "not financial advice / no profit guarantee" note.

---

## 7. Background workers

Dependency-free asyncio scheduler (`app/workers/scheduler.py`), exponential backoff on failure:

| Worker | Interval | Job |
|---|---|---|
| `metadata` | 120 s | resolve NFT metadata discovered by scans |
| `scanner` | `SCANNER_INTERVAL_SECONDS` | scan monitored collections, score opportunities |
| `strategies` | scan interval | run active strategies (alert / paper / assisted) |
| `watchlists` | 300 s | evaluate alert conditions, dedupe notifications |
| `replay` | 3600 s | 24/48/72 h opportunity replay |
| `portfolio` | `PORTFOLIO_SYNC_INTERVAL_SECONDS` | balances, holdings, P/L |

Enable the scanner with `SCANNER_ENABLED=true` (and mark collections `monitored`).

---

## 8. Testing

```bash
make test
```

* **Unit tests** for every financial calculation: number engine, trait/combination rarity, fair
  value, liquidity, opportunity score, costs, collection health, anomalies, whales, replay.
* **Metadata tests** for malformed, missing and unreachable metadata.
* **Security tests** for Telegram `initData` HMAC validation, TON Connect `ton_proof`
  (real ed25519 signature verification) and secret redaction.
* **Integration tests** for the FastAPI surface and the TON Center `nft_purchase` ingestion using
  mocked providers — no network, no credentials.
* **Bot rendering tests** — every message template renders without unresolved emoji tokens.

---

## 9. Configuration highlights

| Variable | Purpose |
|---|---|
| `TELEGRAM_BOT_TOKEN` | bot token (server-side only) |
| `TON_NETWORK` | `testnet` (default) or `mainnet` |
| `TONCENTER_API_KEY` | optional, lifts the 1 rps anonymous limit |
| `TON_APP_URL` | public HTTPS URL of the Mini App (TON Connect + menu button) |
| `DATABASE_URL` | Postgres in production, SQLite for local dev |
| `REDIS_URL` | optional — falls back to an in-process cache |
| `TON_API_KEY` | optional TonAPI token (read-only NFT data) |
| `PORTALS_API_BASE_URL` + `MARKETPLACE_API_KEY` + `PORTALS_ENDPOINT_MAP` | activate the Portals adapter once official access exists |
| `ENABLE_REAL_TRADING` | kill switch for real-money execution |
| `DEV_MODE` | relaxes WebApp auth for browser testing — **must be false in production** |

See `.env.example` for the full list.

---

## 10. API surface (excerpt)

```
GET    /api/health                        GET  /api/config
GET    /api/providers                     GET  /api/tonconnect-manifest.json
GET    /api/auth/me                       PATCH /api/auth/me
GET    /api/wallets                       POST /api/wallets/connect
POST   /api/wallets/{addr}/sync           GET  /api/wallets/{addr}/balances
GET    /api/collections                   POST /api/collections/{addr}/sync
GET    /api/collections/{addr}            GET  /api/collections/{addr}/listings
GET    /api/collections/{addr}/anomalies  GET  /api/collections/{addr}/whales
GET    /api/nfts/{addr}                   POST /api/radar/scan
GET    /api/radar                         GET  /api/radar/{id}/replay
GET    /api/portfolio                     POST /api/portfolio/sync
GET    /api/watchlist                     POST /api/watchlist
GET    /api/strategies                    POST /api/strategies
GET    /api/paper                         POST /api/paper/open|close
POST   /api/swap/quote                    POST /api/swap/submit
POST   /api/trading/buy/prepare           POST /api/trading/sell/prepare
POST   /api/trading/submit                POST /api/trading/verify/{id}
GET    /api/notifications                 POST /api/notifications/read
```

---

## 11. Disclaimer

This software is provided "as is" for educational and research purposes. All valuations,
opportunity scores and "theoretical" results are **model estimates derived from public data** — they
are not financial advice, not an offer, and **not a guarantee of profit or resale value**.
NFT markets are illiquid and volatile. Always verify prices, fees and contract addresses in your
wallet before approving any transaction.
