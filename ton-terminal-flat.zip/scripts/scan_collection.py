"""Scan a collection once from the command line.

    python scripts/scan_collection.py EQ… --items 100 --min-score 40

Useful for smoke-testing provider access before enabling the background
scanner (SCANNER_ENABLED=true).
"""
from __future__ import annotations

import argparse
import asyncio
import json

from app.core.config import get_settings
from app.core.logging import configure_logging, get_logger
from app.database.session import init_db, session_scope
from app.services.market import MarketService
from app.services.opportunities import OpportunityService

logger = get_logger(__name__)


async def main(collection: str, items: int, min_score: int, limit: int) -> dict:
    await init_db()
    async with session_scope() as session:
        market = MarketService(session)
        record = await market.sync_collection(collection, item_limit=items)
        await session.commit()
        service = OpportunityService(session, market=market)
        opportunities = await service.scan_collection(collection, min_score=min_score, limit=limit)
        await session.commit()
        return {
            "collection": record.address,
            "name": record.name,
            "items": record.item_count,
            "listings": record.listings_count,
            "floor": str(record.floor_price_ton) if record.floor_price_ton else None,
            "health": record.health_score,
            "trend": record.trend,
            "opportunities": [
                {
                    "id": opportunity.id,
                    "score": opportunity.opportunity_score,
                    "price": str(opportunity.listed_price_ton),
                    "fair_value": [
                        str(opportunity.fair_value_low),
                        str(opportunity.fair_value_high),
                    ]
                    if opportunity.fair_value_low is not None
                    else None,
                    "risk": opportunity.risk_level,
                }
                for opportunity in opportunities
            ],
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Scan a TON NFT collection")
    parser.add_argument("collection", help="collection address (EQ… or 0:…)")
    parser.add_argument("--items", type=int, default=100)
    parser.add_argument("--min-score", type=int, default=0)
    parser.add_argument("--limit", type=int, default=25)
    args = parser.parse_args()

    configure_logging()
    settings = get_settings()
    print(f"network={settings.ton_network} indexer={settings.toncenter_base_url}")
    result = asyncio.run(main(args.collection, args.items, args.min_score, args.limit))
    print(json.dumps(result, indent=2, default=str))
