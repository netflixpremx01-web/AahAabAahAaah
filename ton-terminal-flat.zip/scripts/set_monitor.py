"""Mark collections as monitored so the background scanner picks them up.

    python scripts/set_monitor.py EQ…          # enable
    python scripts/set_monitor.py EQ… --off    # disable
    python scripts/set_monitor.py --list
"""
from __future__ import annotations

import argparse
import asyncio

from sqlalchemy import select

from app.core.logging import configure_logging
from app.database.session import init_db, session_scope
from app.models.orm import Collection


async def set_monitored(address: str, enabled: bool) -> str:
    await init_db()
    async with session_scope() as session:
        record = (
            await session.execute(select(Collection).where(Collection.address == address))
        ).scalar_one_or_none()
        if record is None:
            raise SystemExit(f"collection {address} not found - scan it first")
        record.monitored = enabled
        return f"{record.name or record.address}: monitored={enabled}"


async def list_monitored() -> None:
    await init_db()
    async with session_scope() as session:
        rows = (
            await session.execute(select(Collection).where(Collection.monitored.is_(True)))
        ).scalars().all()
        for row in rows:
            print(f"{row.name or row.address}\t{row.address}")
        if not rows:
            print("no monitored collections")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("collection", nargs="?", help="collection address")
    parser.add_argument("--off", action="store_true", help="disable monitoring")
    parser.add_argument("--list", action="store_true", help="list monitored collections")
    args = parser.parse_args()
    configure_logging()
    if args.list:
        asyncio.run(list_monitored())
    elif args.collection:
        print(asyncio.run(set_monitored(args.collection, not args.off)))
    else:
        parser.error("provide a collection address or --list")
