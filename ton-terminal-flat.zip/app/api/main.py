"""FastAPI application factory.

Serves:
* the Mini App API under ``/api``,
* the TON Connect manifest under ``/tonconnect-manifest.json``,
* the built Telegram Mini App (static) at ``/`` when ``miniapp/dist`` exists.
"""
from __future__ import annotations

import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.routers import (
    auth,
    automation,
    market,
    notifications,
    portfolio,
    radar,
    swaps,
    system,
    telegram,
    trading,
    wallets,
)
from app.core.config import get_settings
from app.core.errors import AppError
from app.core.logging import configure_logging, get_logger
from app.database.session import dispose_engine, init_db

logger = get_logger(__name__)

API_PREFIX = "/api"
MINIAPP_DIR = Path(__file__).resolve().parents[2] / "miniapp" / "dist"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings = get_settings()
    configure_logging()
    logger.info(
        "starting %s",
        settings.app_name,
        extra={
            "extra_fields": {
                "env": settings.env,
                "network": settings.ton_network,
                "real_trading": settings.enable_real_trading,
            }
        },
    )
    try:
        await init_db()
    except Exception as exc:  # noqa: BLE001 - surface the cause, keep /health alive
        logger.error(
            "database initialisation failed",
            extra={"extra_fields": {"error": str(exc)}},
        )
    if settings.scanner_enabled:
        from app.workers.scheduler import start_scheduler

        app.state.scheduler = await start_scheduler()
    try:
        yield
    finally:
        scheduler = getattr(app.state, "scheduler", None)
        if scheduler is not None:
            from app.workers.scheduler import stop_scheduler

            await stop_scheduler(scheduler)
        await dispose_engine()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version="1.0.0",
        description="All-in-One TON NFT Trading Terminal API (non-custodial).",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if settings.dev_mode else [settings.ton_app_url or "*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.exception_handler(AppError)
    async def _app_error_handler(_: Request, exc: AppError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.http_status,
            content={"error": exc.__class__.__name__, "detail": exc.message, **exc.context},
        )

    @app.middleware("http")
    async def _timing(request: Request, call_next):
        started = time.perf_counter()
        response = await call_next(request)
        elapsed = (time.perf_counter() - started) * 1000
        response.headers["X-Response-Time-ms"] = f"{elapsed:.1f}"
        return response

    for router in (
        system.router,
        auth.router,
        wallets.router,
        market.router,
        radar.router,
        portfolio.router,
        automation.router,
        swaps.router,
        trading.router,
        notifications.router,
    ):
        app.include_router(router, prefix=API_PREFIX)

    # Telegram webhook lives outside the /api namespace by convention.
    app.include_router(telegram.router, prefix="/telegram")

    @app.get("/tonconnect-manifest.json", include_in_schema=False)
    async def _manifest() -> dict:  # pragma: no cover - convenience alias
        from app.integrations.tonconnect.manifest import build_manifest

        return build_manifest()

    if MINIAPP_DIR.exists():
        app.mount("/app", StaticFiles(directory=str(MINIAPP_DIR), html=True), name="miniapp")
        app.mount("/", StaticFiles(directory=str(MINIAPP_DIR), html=True), name="miniapp-root")

    return app


app = create_app()
