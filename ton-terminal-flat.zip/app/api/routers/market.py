"""Collections, NFTs, listings, sales and market intelligence."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.core.errors import AppError, CapabilityNotSupported, ProviderError
from app.models.orm import User
from app.services.market import MarketService

router = APIRouter(tags=["market"])


class SyncRequest(BaseModel):
    item_limit: int = 200
    resolve_metadata: bool = True


@router.get("/collections")
async def top_collections(
    limit: int = 20,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = MarketService(session)
    rows = await service.top_collections(limit)
    return {
        "collections": [
            {
                "address": row.address,
                "name": row.name,
                "image_url": row.image_url,
                "floor_price_ton": str(row.floor_price_ton) if row.floor_price_ton else None,
                "volume_7d_ton": str(row.volume_7d_ton),
                "sales_24h": row.sales_24h,
                "listings_count": row.listings_count,
                "health_score": row.health_score,
                "trend": row.trend,
            }
            for row in rows
        ]
    }


@router.post("/collections/{address}/sync")
async def sync_collection(
    address: str,
    payload: SyncRequest | None = None,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = MarketService(session)
    try:
        collection = await service.sync_collection(
            address,
            item_limit=(payload.item_limit if payload else 200),
            resolve_metadata=(payload.resolve_metadata if payload else True),
        )
    except ProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    await session.commit()
    return {
        "address": collection.address,
        "name": collection.name,
        "item_count": collection.item_count,
        "floor_price_ton": str(collection.floor_price_ton) if collection.floor_price_ton else None,
        "listings_count": collection.listings_count,
        "health_score": collection.health_score,
        "trend": collection.trend,
    }


@router.get("/collections/{address}")
async def collection_detail(
    address: str,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = MarketService(session)
    collection = await service.ensure_collection(address)
    health = await service.health(address)
    return {
        "address": collection.address,
        "name": collection.name,
        "description": collection.description,
        "image_url": collection.image_url,
        "item_count": collection.item_count,
        "floor_price_ton": str(collection.floor_price_ton) if collection.floor_price_ton else None,
        "floor_updated_at": collection.floor_updated_at.isoformat()
        if collection.floor_updated_at
        else None,
        "volume_24h_ton": str(collection.volume_24h_ton),
        "volume_7d_ton": str(collection.volume_7d_ton),
        "sales_24h": collection.sales_24h,
        "listings_count": collection.listings_count,
        "health": health.as_dict(),
    }


@router.get("/collections/{address}/listings")
async def collection_listings(
    address: str,
    limit: int = 50,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = MarketService(session)
    rows = await service.active_listings(address, limit=limit)
    return {
        "listings": [
            {
                "listing_id": row.listing_id,
                "marketplace": row.marketplace,
                "price_ton": str(row.price_ton),
                "seller_address": row.seller_address,
                "nft_address": None,
                "last_seen_at": row.last_seen_at.isoformat() if row.last_seen_at else None,
            }
            for row in rows
        ]
    }


@router.get("/collections/{address}/anomalies")
async def anomalies(
    address: str,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = MarketService(session)
    return {"collection": address, "anomalies": await service.anomalies(address)}


@router.get("/collections/{address}/whales")
async def whales(
    address: str,
    hours: int = 72,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = MarketService(session)
    return await service.whales(address, hours=hours)


@router.get("/nfts/{address}")
async def nft_detail(
    address: str,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    market = MarketService(session)
    from app.services.opportunities import OpportunityService

    opportunities = OpportunityService(session, market=market)
    try:
        metadata = await market.metadata.resolve(address)
        analysis = await opportunities.analyze_nft(address)
    except (ProviderError, CapabilityNotSupported) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    payload = {"metadata": metadata.as_dict()}
    if analysis:
        payload["analysis"] = analysis.as_dict()
    return payload
