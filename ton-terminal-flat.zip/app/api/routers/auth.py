"""User profile, preferences and session bootstrap."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.models.orm import User
from app.services.users import update_notification_prefs, update_ui_prefs

router = APIRouter(prefix="/auth", tags=["auth"])


class PreferenceUpdate(BaseModel):
    notification_prefs: dict[str, bool] | None = None
    ui_prefs: dict | None = None


@router.get("/me")
async def me(user: User = Depends(current_user)) -> dict:
    return {
        "id": user.id,
        "telegram_id": user.telegram_id,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "is_premium": user.is_premium,
        "paper_balance_ton": str(user.paper_balance_ton),
        "notification_prefs": user.notification_prefs,
        "ui_prefs": user.ui_prefs,
    }


@router.patch("/me")
async def update_preferences(
    payload: PreferenceUpdate,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    if payload.notification_prefs:
        await update_notification_prefs(session, user, payload.notification_prefs)
    if payload.ui_prefs:
        await update_ui_prefs(session, user, payload.ui_prefs)
    await session.commit()
    return {
        "notification_prefs": user.notification_prefs,
        "ui_prefs": user.ui_prefs,
    }
