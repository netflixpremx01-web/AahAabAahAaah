"""Buy / sell preparation, submission and verification."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.core.errors import AppError, NotFoundError
from app.models.enums import TxKind
from app.models.orm import User
from app.services.trading import TradingService

router = APIRouter(prefix="/trading", tags=["trading"])


class BuyPrepare(BaseModel):
    nft_address: str | None = None
    listing_id: str | None = None
    marketplace: str | None = None


class SellPrepare(BaseModel):
    nft_address: str
    price_ton: float
    marketplace: str | None = None


class SubmitRequest(BaseModel):
    kind: str = TxKind.BUY.value
    wallet_address: str
    tx_hash: str | None = None
    subject_address: str | None = None
    provider: str | None = None
    amount_ton: float | None = None
    payload: dict | None = None


@router.post("/buy/prepare")
async def buy_prepare(
    payload: BuyPrepare,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = TradingService(session)
    try:
        return await service.prepare_buy(
            nft_address=payload.nft_address,
            listing_id=payload.listing_id,
            marketplace=payload.marketplace,
        )
    except NotFoundError as exc:
        raise HTTPException(status_code=404, detail=exc.message) from exc


@router.post("/sell/prepare")
async def sell_prepare(
    payload: SellPrepare,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = TradingService(session)
    try:
        return await service.prepare_sell(
            nft_address=payload.nft_address,
            price_ton=payload.price_ton,
            marketplace=payload.marketplace,
        )
    except NotFoundError as exc:
        raise HTTPException(status_code=404, detail=exc.message) from exc


@router.post("/submit")
async def submit(
    payload: SubmitRequest,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = TradingService(session)
    try:
        transaction = await service.submit_transaction(
            user=user,
            kind=payload.kind,
            wallet_address=payload.wallet_address,
            tx_hash=payload.tx_hash,
            subject_address=payload.subject_address,
            provider=payload.provider,
            amount_ton=payload.amount_ton,
            payload=payload.payload,
        )
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {
        "id": transaction.id,
        "status": transaction.status,
        "kind": transaction.kind,
        "tx_hash": transaction.tx_hash,
    }


@router.post("/verify/{transaction_id}")
async def verify(
    transaction_id: int,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = TradingService(session)
    transaction = await session.get(type(await _transaction_model()), transaction_id)
    if transaction is None or transaction.user_id != user.id:
        raise HTTPException(status_code=404, detail="transaction not found")
    transaction = await service.verify_transaction(transaction)
    await session.commit()
    return {
        "id": transaction.id,
        "status": transaction.status,
        "tx_hash": transaction.tx_hash,
        "confirmed_at": transaction.confirmed_at.isoformat() if transaction.confirmed_at else None,
        "error": transaction.error,
    }


async def _transaction_model():
    from app.models.orm import Transaction

    return Transaction


@router.get("/history")
async def history(
    limit: int = 25,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = TradingService(session)
    rows = await service.list_transactions(user.id, limit=limit)
    return {
        "transactions": [
            {
                "id": row.id,
                "kind": row.kind,
                "status": row.status,
                "amount_ton": str(row.amount_ton) if row.amount_ton else None,
                "tx_hash": row.tx_hash,
                "provider": row.provider,
                "submitted_at": row.submitted_at.isoformat() if row.submitted_at else None,
                "confirmed_at": row.confirmed_at.isoformat() if row.confirmed_at else None,
            }
            for row in rows
        ]
    }
