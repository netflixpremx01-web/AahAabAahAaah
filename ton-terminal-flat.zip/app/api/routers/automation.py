"""Watchlist, strategies and paper trading."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.core.errors import AppError
from app.models.enums import StrategyMode, WatchCondition, WatchTarget
from app.models.orm import User
from app.services.paper import PaperTradingService
from app.services.strategies import StrategyService
from app.services.watchlist import WatchlistService

router = APIRouter(tags=["automation"])


# --------------------------------------------------------------------- watchlist
class WatchCreate(BaseModel):
    target_type: str = WatchTarget.NFT.value
    target_ref: str
    condition: str = WatchCondition.PRICE_BELOW.value
    threshold: float | None = None
    label: str | None = None


@router.get("/watchlist")
async def watchlist_list(
    user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    service = WatchlistService(session)
    rows = await service.list(user.id)
    return {
        "watchlist": [
            {
                "id": row.id,
                "target_type": row.target_type,
                "target_ref": row.target_ref,
                "condition": row.condition,
                "threshold": str(row.threshold) if row.threshold is not None else None,
                "label": row.label,
                "is_active": row.is_active,
                "trigger_count": row.trigger_count,
                "last_triggered_at": row.last_triggered_at.isoformat()
                if row.last_triggered_at
                else None,
            }
            for row in rows
        ]
    }


@router.post("/watchlist")
async def watchlist_add(
    payload: WatchCreate,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = WatchlistService(session)
    try:
        row = await service.add(
            user_id=user.id,
            target_type=WatchTarget(payload.target_type),
            target_ref=payload.target_ref,
            condition=WatchCondition(payload.condition),
            threshold=payload.threshold,
            label=payload.label,
        )
    except (AppError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    await session.commit()
    return {"id": row.id, "target_ref": row.target_ref}


@router.delete("/watchlist/{watch_id}")
async def watchlist_remove(
    watch_id: int, user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    service = WatchlistService(session)
    removed = await service.remove(user.id, watch_id)
    await session.commit()
    return {"removed": removed}


@router.post("/watchlist/check")
async def watchlist_check(
    user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    service = WatchlistService(session)
    triggers = await service.check_all(user.id)
    await session.commit()
    return {"triggers": triggers}


# -------------------------------------------------------------------- strategies
class StrategyCreate(BaseModel):
    name: str
    mode: str = StrategyMode.ALERT.value
    rules: dict | None = None


@router.get("/strategies")
async def strategies_list(
    user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    service = StrategyService(session)
    rows = await service.list(user.id)
    return {
        "strategies": [
            {
                "id": row.id,
                "name": row.name,
                "mode": row.mode,
                "is_active": row.is_active,
                "rules": row.rules,
                "stats": row.stats,
            }
            for row in rows
        ]
    }


@router.post("/strategies")
async def strategies_create(
    payload: StrategyCreate,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = StrategyService(session)
    try:
        row = await service.create(
            user_id=user.id, name=payload.name, mode=StrategyMode(payload.mode), rules=payload.rules
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    await session.commit()
    return {"id": row.id, "name": row.name, "mode": row.mode, "rules": row.rules}


@router.patch("/strategies/{strategy_id}")
async def strategies_update(
    strategy_id: int,
    payload: dict,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = StrategyService(session)
    try:
        row = await service.update(user.id, strategy_id, **payload)
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {"id": row.id, "name": row.name, "mode": row.mode, "rules": row.rules}


@router.delete("/strategies/{strategy_id}")
async def strategies_delete(
    strategy_id: int,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = StrategyService(session)
    removed = await service.delete(user.id, strategy_id)
    await session.commit()
    return {"removed": removed}


# ------------------------------------------------------------------ paper mode
class PaperOpen(BaseModel):
    nft_address: str | None = None
    collection_address: str | None = None
    entry_price: float
    strategy_id: int | None = None
    notes: str | None = None


class PaperClose(BaseModel):
    trade_id: int
    exit_price: float
    quantity: int = 1


@router.get("/paper")
async def paper_summary(
    user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    service = PaperTradingService(session)
    open_trades = await service.open_positions(user.id)
    closed = await service.closed_positions(user.id, limit=50)
    return {
        "stats": await service.stats(user.id),
        "open": [
            {
                "id": trade.id,
                "nft_id": trade.nft_id,
                "entry_price_ton": str(trade.entry_price_ton),
                "opened_at": trade.opened_at.isoformat() if trade.opened_at else None,
                "notes": trade.notes,
            }
            for trade in open_trades
        ],
        "closed": [
            {
                "id": trade.id,
                "entry_price_ton": str(trade.entry_price_ton),
                "exit_price_ton": str(trade.exit_price_ton) if trade.exit_price_ton else None,
                "pnl_ton": str(trade.pnl_ton) if trade.pnl_ton else None,
                "pnl_pct": str(trade.pnl_pct) if trade.pnl_pct else None,
                "closed_at": trade.closed_at.isoformat() if trade.closed_at else None,
            }
            for trade in closed
        ],
        "note": "Simulated trading only - no real funds are involved.",
    }


@router.post("/paper/open")
async def paper_open(
    payload: PaperOpen,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = PaperTradingService(session)
    try:
        trade = await service.open_position(
            user_id=user.id,
            entry_price=payload.entry_price,
            nft_address=payload.nft_address,
            collection_address=payload.collection_address,
            strategy_id=payload.strategy_id,
            notes=payload.notes,
        )
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {"id": trade.id, "entry_price_ton": str(trade.entry_price_ton), "status": trade.status}


@router.post("/paper/close")
async def paper_close(
    payload: PaperClose,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = PaperTradingService(session)
    try:
        trade = await service.close_position(
            user_id=user.id,
            trade_id=payload.trade_id,
            exit_price=payload.exit_price,
            quantity=payload.quantity,
        )
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {
        "id": trade.id,
        "pnl_ton": str(trade.pnl_ton) if trade.pnl_ton else None,
        "pnl_pct": str(trade.pnl_pct) if trade.pnl_pct else None,
    }
