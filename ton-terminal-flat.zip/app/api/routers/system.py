"""System endpoints: health, public config, provider status, TON Connect manifest."""
from __future__ import annotations

from fastapi import APIRouter, Depends

from app.core.config import Settings, get_settings
from app.integrations.dex.registry import describe_all as dex_describe
from app.integrations.marketplaces.registry import describe_all as marketplace_describe
from app.integrations.tonconnect.manifest import build_manifest
from app.security.secrets import public_config

router = APIRouter(tags=["system"])


@router.get("/health")
async def health() -> dict:
    settings = get_settings()
    return {
        "status": "ok",
        "app": settings.app_name,
        "env": settings.env,
        "network": settings.ton_network,
        "real_trading": settings.enable_real_trading,
        "paper_trading": settings.enable_paper_trading,
    }


@router.get("/config")
async def config() -> dict:
    """Public, non-secret configuration for the Mini App."""
    return public_config()


@router.get("/providers")
async def providers() -> dict:
    """Live status of every external provider and its capabilities."""
    return {
        "marketplaces": marketplace_describe(),
        "dex": dex_describe(),
        "indexer": {
            "name": "toncenter",
            "docs_url": "https://docs.ton.org/api/v3/overview",
            "base_url": get_settings().toncenter_base_url,
            "api_key_configured": bool(get_settings().toncenter_api_key),
        },
    }


@router.get("/tonconnect-manifest.json")
async def tonconnect_manifest() -> dict:
    return build_manifest()


@router.get("/settings")
async def raw_settings(settings: Settings = Depends(lambda: get_settings())) -> dict:
    """Redacted settings dump - safe for support/debug."""
    return settings.safe_dict()
