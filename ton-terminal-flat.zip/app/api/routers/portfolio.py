"""Portfolio endpoints."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.models.orm import User
from app.services import wallets as wallet_service
from app.services.portfolio import PortfolioService

router = APIRouter(prefix="/portfolio", tags=["portfolio"])


@router.get("")
async def summary(
    user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    service = PortfolioService(session)
    wallet = await wallet_service.get_primary_wallet(session, user.id)
    return await service.summary(user.id, wallet)


@router.post("/sync")
async def sync(
    user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    wallet = await wallet_service.get_primary_wallet(session, user.id)
    if wallet is None:
        raise HTTPException(status_code=409, detail="connect a wallet first")
    service = PortfolioService(session)
    result = await service.sync_wallet(wallet)
    await session.commit()
    return result


@router.get("/history")
async def history(
    limit: int = 50,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    wallet = await wallet_service.get_primary_wallet(session, user.id)
    service = PortfolioService(session)
    return await service.history(user.id, wallet, limit=limit)
