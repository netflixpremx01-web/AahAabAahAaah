"""Wallet connection and balances (public keys/addresses only)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.core.errors import AppError
from app.integrations.tonconnect.verify import wallet_auth_from_payload
from app.models.orm import User
from app.services import wallets as wallet_service

router = APIRouter(prefix="/wallets", tags=["wallets"])


class ConnectRequest(BaseModel):
    address: str
    publicKey: str | None = None
    network: str | None = None
    walletApp: str | None = None
    device: dict | None = None
    proof: dict | None = None


@router.get("")
async def list_wallets(
    user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    rows = await wallet_service.list_wallets(session, user.id)
    return {
        "wallets": [
            {
                "address": row.address,
                "network": row.network,
                "wallet_app": row.wallet_app,
                "is_primary": row.is_primary,
                "verified": row.verified,
                "balance_ton": str(row.balance_ton),
                "last_synced_at": row.last_synced_at.isoformat() if row.last_synced_at else None,
            }
            for row in rows
        ]
    }


@router.post("/connect")
async def connect(
    payload: ConnectRequest,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    try:
        auth = wallet_auth_from_payload(payload.model_dump())
        wallet = await wallet_service.connect_wallet(
            session, user_id=user.id, auth=auth, verify_proof=bool(payload.proof)
        )
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {
        "address": wallet.address,
        "verified": wallet.verified,
        "is_primary": wallet.is_primary,
        "network": wallet.network,
        "note": "Only public wallet data is stored. Seed phrases and private keys are never requested.",
    }


@router.post("/{address}/primary")
async def make_primary(
    address: str, user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    try:
        wallet = await wallet_service.set_primary(session, user.id, address)
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {"address": wallet.address, "is_primary": wallet.is_primary}


@router.delete("/{address}")
async def disconnect(
    address: str, user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    await wallet_service.disconnect_wallet(session, user.id, address)
    await session.commit()
    return {"removed": address}


@router.get("/{address}/balances")
async def balances(
    address: str, user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    rows = await wallet_service.list_wallets(session, user.id)
    wallet = next((row for row in rows if row.address == address), None)
    if wallet is None:
        raise HTTPException(status_code=404, detail="wallet not connected")
    return await wallet_service.sync_balances(session, wallet)


@router.post("/{address}/sync")
async def sync(
    address: str, user: User = Depends(current_user), session: AsyncSession = Depends(db_session)
) -> dict:
    from app.services.portfolio import PortfolioService

    rows = await wallet_service.list_wallets(session, user.id)
    wallet = next((row for row in rows if row.address == address), None)
    if wallet is None:
        raise HTTPException(status_code=404, detail="wallet not connected")
    service = PortfolioService(session)
    result = await service.sync_wallet(wallet)
    await session.commit()
    return result
