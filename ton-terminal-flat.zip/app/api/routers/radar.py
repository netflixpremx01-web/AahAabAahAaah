"""NFT Market Radar endpoints."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import current_user, db_session
from app.core.errors import AppError
from app.models.orm import User
from app.services.opportunities import OpportunityService

router = APIRouter(prefix="/radar", tags=["radar"])


class ScanRequest(BaseModel):
    collection: str
    min_score: int = 0
    limit: int = 25


def _opportunity_payload(row) -> dict:
    nft = getattr(row, "nft", None)
    collection = getattr(row, "collection", None)
    return {
        "id": row.id,
        "nft_address": nft.address if nft else None,
        "collection_address": collection.address if collection else None,
        "marketplace": row.marketplace,
        "listing_id": row.listing_id,
        "listed_price_ton": str(row.listed_price_ton),
        "fair_value_low": str(row.fair_value_low) if row.fair_value_low else None,
        "fair_value_high": str(row.fair_value_high) if row.fair_value_high else None,
        "fair_value_mid": str((row.fair_value_low + row.fair_value_high) / 2)
        if row.fair_value_low is not None and row.fair_value_high is not None
        else None,
        "discount_pct": str(row.discount_pct) if row.discount_pct else None,
        "rarity_score": row.rarity_score,
        "number_score": row.number_score,
        "liquidity_score": row.liquidity_score,
        "confidence": row.confidence,
        "roi_pct": str(row.roi_pct) if row.roi_pct else None,
        "estimated_costs_ton": str(row.estimated_costs_ton) if row.estimated_costs_ton else None,
        "theoretical_profit_ton": str(row.theoretical_profit_ton)
        if row.theoretical_profit_ton
        else None,
        "risk_level": row.risk_level,
        "opportunity_score": row.opportunity_score,
        "reasons": row.reasons,
        "detected_at": row.detected_at.isoformat() if row.detected_at else None,
        "status": row.status,
    }


@router.post("/scan")
async def scan(
    payload: ScanRequest,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = OpportunityService(session)
    try:
        opportunities = await service.scan_collection(
            payload.collection, min_score=payload.min_score, limit=payload.limit
        )
    except AppError as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {
        "collection": payload.collection,
        "count": len(opportunities),
        "opportunities": [_opportunity_payload(row) for row in opportunities],
        "disclaimer": (
            "Opportunity scores are model estimates based on public data. "
            "They are not profit guarantees."
        ),
    }


@router.get("")
async def list_opportunities(
    collection: str | None = None,
    min_score: int = 0,
    limit: int = 20,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = OpportunityService(session)
    rows = await service.list_opportunities(
        collection_address=collection, min_score=min_score, limit=limit
    )
    await _attach_relations(session, rows)
    return {"opportunities": [_opportunity_payload(row) for row in rows]}


async def _attach_relations(session: AsyncSession, rows: list) -> None:
    """Load NFT/collection addresses for the response payload."""
    from app.models.orm import Opportunity

    ids = [row.id for row in rows]
    if not ids:
        return
    result = await session.execute(
        select(Opportunity)
        .where(Opportunity.id.in_(ids))
        .options(selectinload(Opportunity.nft), selectinload(Opportunity.collection))
    )
    loaded = {row.id: row for row in result.scalars().all()}
    for row in rows:
        source = loaded.get(row.id)
        if source is not None:
            row.nft = source.nft
            row.collection = source.collection


@router.get("/replay/summary")
async def replay_summary(
    collection: str | None = None,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = OpportunityService(session)
    return await service.replay_summary(collection_address=collection)


@router.get("/{opportunity_id}")
async def get_opportunity(
    opportunity_id: int,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = OpportunityService(session)
    row = await service.get_opportunity(opportunity_id)
    if row is None:
        raise HTTPException(status_code=404, detail="opportunity not found")
    return _opportunity_payload(row)


@router.get("/{opportunity_id}/replay")
async def replay(
    opportunity_id: int,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = OpportunityService(session)
    results = await service.replay(opportunity_id)
    await session.commit()
    return {"opportunity_id": opportunity_id, "replay": results}
