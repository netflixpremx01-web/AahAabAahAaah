"""Telegram webhook transport (alternative to long polling).

Security: the secret token is compared with ``hmac.compare_digest`` and the
update is only accepted when it matches ``TELEGRAM_WEBHOOK_SECRET``.
"""
from __future__ import annotations

import hmac
from typing import Any

from aiogram import Bot, Dispatcher
from aiogram.types import Update
from fastapi import APIRouter, Depends, HTTPException, Request, status

from app.bot.main import build_dispatcher
from app.core.config import get_settings
from app.core.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(tags=["telegram"])

_BOT: Bot | None = None
_DISPATCHER: Dispatcher | None = None


def _get_bot() -> tuple[Bot, Dispatcher]:
    """Lazily create the bot/dispatcher (only when a token is configured)."""
    global _BOT, _DISPATCHER
    settings = get_settings()
    if not settings.telegram_bot_token:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="TELEGRAM_BOT_TOKEN is not configured - use polling (make bot)",
        )
    if _BOT is None:
        _BOT = Bot(token=settings.telegram_bot_token)
        _DISPATCHER = build_dispatcher()
    return _BOT, _DISPATCHER


def verify_secret(request: Request) -> None:
    settings = get_settings()
    expected = settings.telegram_webhook_secret
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="TELEGRAM_WEBHOOK_SECRET is not configured",
        )
    provided = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    if not hmac.compare_digest(provided, expected):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid secret token")


@router.post("/webhook")
async def telegram_webhook(
    request: Request, _: None = Depends(verify_secret)
) -> dict[str, Any]:
    """Receive an update from Telegram and hand it to aiogram."""
    bot, dispatcher = _get_bot()
    payload = await request.json()
    update = Update.model_validate(payload)
    await dispatcher.feed_update(bot, update)
    return {"ok": True}


@router.get("/webhook/info")
async def webhook_info(_: None = Depends(verify_secret)) -> dict[str, Any]:
    """Current webhook state (useful when wiring up a deployment)."""
    bot, _dispatcher = _get_bot()
    info = await bot.get_webhook_info()
    return info.model_dump(mode="json")


@router.post("/webhook/setup")
async def setup_webhook(_: None = Depends(verify_secret)) -> dict[str, Any]:
    """Register the webhook URL with Telegram (idempotent)."""
    settings = get_settings()
    if not settings.telegram_webhook_url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="TELEGRAM_WEBHOOK_URL is not set"
        )
    bot, _dispatcher = _get_bot()
    await bot.set_webhook(
        url=settings.telegram_webhook_url,
        secret_token=settings.telegram_webhook_secret,
        drop_pending_updates=False,
    )
    return {"url": settings.telegram_webhook_url, "ok": True}
