"""Notification inbox."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.models.orm import User
from app.services.notifications import NotificationService

router = APIRouter(prefix="/notifications", tags=["notifications"])


class ReadRequest(BaseModel):
    notification_id: int | None = None


@router.get("")
async def list_notifications(
    limit: int = 30,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = NotificationService(session)
    rows = await service.list(user.id, limit=limit)
    return {
        "notifications": [
            {
                "id": row.id,
                "category": row.category,
                "title": row.title,
                "body": row.body,
                "payload": row.payload,
                "status": row.status,
                "created_at": row.created_at.isoformat(),
                "read_at": row.read_at.isoformat() if row.read_at else None,
            }
            for row in rows
        ]
    }


@router.post("/read")
async def mark_read(
    payload: ReadRequest,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = NotificationService(session)
    count = await service.mark_read(user.id, payload.notification_id)
    await session.commit()
    return {"marked_read": count}
