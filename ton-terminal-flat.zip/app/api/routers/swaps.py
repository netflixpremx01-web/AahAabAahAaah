"""Swap endpoints: quotes, submission and history."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import current_user, db_session
from app.core.errors import AppError, ProviderError
from app.models.orm import User
from app.services.swaps import SwapService

router = APIRouter(prefix="/swap", tags=["swap"])


class QuoteRequest(BaseModel):
    from_token: str = "TON"
    to_token: str = "USDT"
    amount: float
    slippage: float | None = None
    provider: str | None = None


class SubmitRequest(BaseModel):
    quote_id: int
    wallet_address: str
    tx_hash: str | None = None


@router.get("/providers")
async def providers() -> dict:
    return {"providers": SwapService.providers()}


@router.get("/tokens")
async def tokens() -> dict:
    return {"tokens": SwapService.known_tokens()}


@router.post("/quote")
async def quote(
    payload: QuoteRequest,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = SwapService(session)
    try:
        row = await service.quote(
            user=user,
            from_token=payload.from_token,
            to_token=payload.to_token,
            amount=payload.amount,
            slippage=payload.slippage,
            provider=payload.provider,
        )
    except (ProviderError, AppError) as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {
        "quote_id": row.id,
        "provider": row.provider,
        "from_token": row.from_token,
        "to_token": row.to_token,
        "from_amount": str(row.from_amount),
        "to_amount": str(row.to_amount),
        "min_received": str(row.min_received),
        "rate": str(row.rate),
        "price_impact": str(row.price_impact),
        "network_fee_ton": str(row.network_fee_ton),
        "route": row.route,
        "slippage": str(row.slippage),
        "expires_at": row.expires_at.isoformat(),
        "notes": getattr(row, "payload_notes", None),
        "disclaimer": "Quote is time limited. Amounts change until the transaction is confirmed.",
    }


@router.post("/submit")
async def submit(
    payload: SubmitRequest,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = SwapService(session)
    try:
        swap = await service.submit(
            user=user,
            quote_id=payload.quote_id,
            wallet_address=payload.wallet_address,
            tx_hash=payload.tx_hash,
        )
    except (ProviderError, AppError) as exc:
        raise HTTPException(status_code=exc.http_status, detail=exc.message) from exc
    await session.commit()
    return {
        "id": swap.id,
        "status": swap.status,
        "tx_hash": swap.tx_hash,
        "expected_amount": str(swap.expected_amount),
        "actual_amount": str(swap.actual_amount) if swap.actual_amount else None,
        "error": swap.error,
    }


@router.get("/history")
async def history(
    limit: int = 25,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> dict:
    service = SwapService(session)
    rows = await service.list_swaps(user.id, limit=limit)
    return {
        "swaps": [
            {
                "id": row.id,
                "provider": row.provider,
                "from_token": row.from_token,
                "to_token": row.to_token,
                "from_amount": str(row.from_amount),
                "expected_amount": str(row.expected_amount),
                "actual_amount": str(row.actual_amount) if row.actual_amount else None,
                "status": row.status,
                "tx_hash": row.tx_hash,
                "submitted_at": row.submitted_at.isoformat() if row.submitted_at else None,
            }
            for row in rows
        ]
    }
