"""Shared FastAPI dependencies: DB session and Telegram Mini App identity."""
from __future__ import annotations

from collections.abc import AsyncIterator

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings, get_settings
from app.database.session import get_session
from app.models.orm import User
from app.security.initdata import InitData, validate_init_data
from app.services.users import get_or_create_user


async def db_session() -> AsyncIterator[AsyncSession]:
    async for session in get_session():
        yield session


def settings_dep() -> Settings:
    return get_settings()


async def init_data(
    request: Request,
    x_telegram_init_data: str | None = Header(default=None, alias="X-Telegram-Init-Data"),
) -> InitData:
    """Validate the Mini App ``initData``.

    Accepted from the ``X-Telegram-Init-Data`` header, ``?initData=`` or
    ``?_auth=`` (used by some hosts). In development mode a missing value falls
    back to a local dev user so the app can run in a normal browser.
    """
    raw = (
        x_telegram_init_data
        or request.query_params.get("initData")
        or request.query_params.get("_auth")
    )
    try:
        return validate_init_data(raw)
    except Exception as exc:  # noqa: BLE001 - surfaced as 401
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc


async def current_user(
    session: AsyncSession = Depends(db_session),
    data: InitData = Depends(init_data),
) -> User:
    telegram_id = data.telegram_id
    if telegram_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="initData contains no user"
        )
    user_data = data.user or {}
    return await get_or_create_user(
        session,
        telegram_id=telegram_id,
        username=user_data.get("username"),
        first_name=user_data.get("first_name"),
        last_name=user_data.get("last_name"),
        language_code=user_data.get("language_code"),
        is_premium=bool(user_data.get("is_premium")),
        photo_url=user_data.get("photo_url"),
    )
