"""Dependency-free asyncio scheduler for the background workers."""
from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field

from app.core.config import get_settings
from app.core.logging import get_logger

logger = get_logger(__name__)

Task = Callable[[], Awaitable[object]]


@dataclass
class ScheduledTask:
    name: str
    coro: Task
    interval_seconds: int
    run_immediately: bool = False
    task: asyncio.Task | None = field(default=None, repr=False)


class Scheduler:
    """Runs each task on an interval with error isolation and backoff."""

    def __init__(self) -> None:
        self.tasks: list[ScheduledTask] = []
        self._running = False

    def add(self, name: str, coro: Task, *, interval_seconds: int, run_immediately: bool = False) -> None:
        self.tasks.append(
            ScheduledTask(
                name=name,
                coro=coro,
                interval_seconds=max(5, interval_seconds),
                run_immediately=run_immediately,
            )
        )

    async def start(self) -> None:
        self._running = True
        for scheduled in self.tasks:
            scheduled.task = asyncio.create_task(self._loop(scheduled), name=scheduled.name)
        logger.info(
            "scheduler started",
            extra={"extra_fields": {"tasks": [t.name for t in self.tasks]}},
        )

    async def stop(self) -> None:
        self._running = False
        for scheduled in self.tasks:
            if scheduled.task:
                scheduled.task.cancel()
        await asyncio.gather(
            *(scheduled.task for scheduled in self.tasks if scheduled.task),
            return_exceptions=True,
        )

    async def _loop(self, scheduled: ScheduledTask) -> None:
        if not scheduled.run_immediately:
            await asyncio.sleep(min(scheduled.interval_seconds, 30))
        failures = 0
        while self._running:
            try:
                await scheduled.coro()
                failures = 0
            except asyncio.CancelledError:  # pragma: no cover
                raise
            except Exception as exc:  # noqa: BLE001 - isolate worker failures
                failures += 1
                logger.warning(
                    "worker failed",
                    extra={
                        "extra_fields": {
                            "task": scheduled.name,
                            "error": str(exc),
                            "failures": failures,
                        }
                    },
                )
            backoff = min(scheduled.interval_seconds * (2 ** min(failures, 4)), 3600)
            await asyncio.sleep(backoff if failures else scheduled.interval_seconds)


def build_scheduler(notifier=None) -> Scheduler:
    settings = get_settings()
    from app.workers import tasks

    scheduler = Scheduler()
    scheduler.add(
        "metadata",
        lambda: tasks.metadata_worker(),
        interval_seconds=120,
        run_immediately=True,
    )
    if settings.scanner_enabled:
        scheduler.add(
            "scanner",
            lambda: tasks.scanner_worker(),
            interval_seconds=settings.scanner_interval_seconds,
        )
        scheduler.add(
            "strategies",
            lambda: tasks.strategy_worker(),
            interval_seconds=max(60, settings.scanner_interval_seconds),
        )
    scheduler.add(
        "watchlists",
        lambda: tasks.watchlist_worker(notifier),
        interval_seconds=300,
    )
    if settings.opportunity_replay_enabled:
        scheduler.add("replay", lambda: tasks.replay_worker(), interval_seconds=3600)
    scheduler.add(
        "portfolio",
        lambda: tasks.portfolio_worker(),
        interval_seconds=settings.portfolio_sync_interval_seconds,
    )
    return scheduler


async def start_scheduler(notifier=None) -> Scheduler:
    scheduler = build_scheduler(notifier)
    await scheduler.start()
    return scheduler


async def stop_scheduler(scheduler: Scheduler) -> None:
    await scheduler.stop()
