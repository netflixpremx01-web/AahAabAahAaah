"""Background workers.

Each worker is a plain coroutine so it can be driven by the built-in asyncio
scheduler (see :mod:`app.workers.scheduler`), by cron, or manually from tests.

Every worker:
* respects provider rate limits (the HTTP layer throttles),
* catches its own exceptions so one failure never kills the loop,
* logs structured events without secrets.
"""
from __future__ import annotations

import asyncio
from typing import Any

from sqlalchemy import select

from app.core.logging import get_logger
from app.database.session import session_scope
from app.models.enums import NotificationCategory
from app.models.orm import Collection, Notification, Opportunity, User
from app.services.market import MarketService
from app.services.notifications import NotificationService, make_dedupe_key
from app.services.opportunities import OpportunityService
from app.services.portfolio import PortfolioService
from app.services.strategies import StrategyService
from app.services.watchlist import WatchlistService

logger = get_logger(__name__)


async def metadata_worker(batch_size: int = 25) -> int:
    """Resolve metadata for NFTs discovered by other workers."""
    async with session_scope() as session:
        service = MarketService(session)
        resolved = await service.resolve_pending_metadata(limit=batch_size)
    if resolved:
        logger.info("metadata resolved", extra={"extra_fields": {"count": resolved}})
    return resolved


async def scanner_worker(limit_per_collection: int = 25) -> dict[str, Any]:
    """Scan every monitored collection and store new opportunities."""
    async with session_scope() as session:
        monitored = (
            await session.execute(select(Collection).where(Collection.monitored.is_(True)))
        ).scalars().all()
        addresses = [collection.address for collection in monitored]
    if not addresses:
        return {"scanned": 0, "opportunities": 0}

    results = {"scanned": 0, "opportunities": 0, "collections": addresses}
    for address in addresses:
        try:
            async with session_scope() as session:
                service = OpportunityService(session)
                opportunities = await service.scan_collection(
                    address, min_score=60, limit=limit_per_collection
                )
                results["scanned"] += 1
                results["opportunities"] += len(opportunities)
        except Exception as exc:  # noqa: BLE001 - keep the loop alive
            logger.warning(
                "scan failed",
                extra={"extra_fields": {"collection": address, "error": str(exc)}},
            )
        await asyncio.sleep(1)  # be gentle with upstream providers
    logger.info("scan cycle complete", extra={"extra_fields": results})
    return results


async def strategy_worker() -> int:
    """Run active strategies over fresh opportunities (alert/paper/assisted)."""
    applied = 0
    async with session_scope() as session:
        strategies = (
            await session.execute(select(__import__("app.models.orm", fromlist=["Strategy"]).Strategy).where(
                __import__("app.models.orm", fromlist=["Strategy"]).Strategy.is_active.is_(True)
            ))
        ).scalars().all()
        payloads = []
        for strategy in strategies:
            service = OpportunityService(session)
            opportunities = await service.list_opportunities(min_score=0, limit=50)
            for opportunity in opportunities:
                payloads.append((strategy, opportunity))
        for strategy, opportunity in payloads:
            try:
                result = await StrategyService(session).apply(strategy, opportunity)
                applied += 1 if result.get("matched") else 0
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "strategy apply failed",
                    extra={"extra_fields": {"strategy": strategy.id, "error": str(exc)}},
                )
    return applied


async def watchlist_worker(notifier=None) -> int:
    """Evaluate watchlists and queue notifications for triggered items."""
    sent = 0
    async with session_scope() as session:
        users = (await session.execute(select(User))).scalars().all()
        service = WatchlistService(session)
        notifications = NotificationService(session, sender=notifier)
        for user in users:
            try:
                triggers = await service.check_all(user.id)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "watchlist check failed",
                    extra={"extra_fields": {"user": user.id, "error": str(exc)}},
                )
                continue
            for trigger in triggers:
                notification = await notifications.notify(
                    user=user,
                    category=NotificationCategory.WATCHLIST,
                    title="{notification} Watchlist trigger",
                    body=(
                        f"{trigger['target_type']} {trigger['target'][:16]}… "
                        f"{trigger['condition']} {trigger['threshold']} "
                        f"(observed {trigger['observed']})"
                    ),
                    payload=trigger,
                    dedupe_key=make_dedupe_key(
                        "watch", user.id, trigger["watch_id"], trigger["observed"]
                    ),
                )
                sent += 1 if notification else 0
    return sent


async def replay_worker() -> int:
    """Compute 24/48/72h replays for opportunities whose horizon has passed."""
    processed = 0
    async with session_scope() as session:
        rows = (
            await session.execute(
                select(Opportunity).where(Opportunity.detected_at.isnot(None)).limit(100)
            )
        ).scalars().all()
        service = OpportunityService(session)
        for row in rows:
            try:
                results = await service.replay(row.id)
                processed += len(results)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "replay failed",
                    extra={"extra_fields": {"opportunity": row.id, "error": str(exc)}},
                )
    return processed


async def portfolio_worker() -> int:
    """Refresh balances and holdings for users with a connected wallet."""
    from app.models.orm import Wallet
    from app.services import wallets as wallet_service

    synced = 0
    async with session_scope() as session:
        rows = (await session.execute(select(Wallet))).scalars().all()
        for wallet in rows:
            try:
                service = PortfolioService(session)
                await service.sync_wallet(wallet, item_limit=100)
                await wallet_service.sync_balances(session, wallet)
                synced += 1
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "portfolio sync failed",
                    extra={"extra_fields": {"wallet": wallet.address, "error": str(exc)}},
                )
            await asyncio.sleep(0.5)
    return synced


async def notification_worker(notifier=None) -> int:
    """Deliver queued notifications that have not been sent yet."""
    if notifier is None:
        return 0
    async with session_scope() as session:
        pending = (
            await session.execute(
                select(Notification).where(Notification.status == "pending").limit(50)
            )
        ).scalars().all()
        sent = 0
        for notification in pending:
            user = await session.get(User, notification.user_id)
            if user is None:
                continue
            try:
                delivered = await notifier.send(user.telegram_id, notification.title, notification.body)
                notification.status = "sent" if delivered else "failed"
                sent += 1 if delivered else 0
            except Exception as exc:  # noqa: BLE001
                notification.status = "failed"
                notification.error = str(exc)
        return sent


async def demo_seed_worker(collection: str) -> dict[str, Any]:
    """Convenience helper: index one collection end-to-end (used by scripts)."""
    async with session_scope() as session:
        service = MarketService(session)
        record = await service.sync_collection(collection, item_limit=50)
        opportunities = await OpportunityService(session).scan_collection(
            collection, min_score=0, limit=10
        )
        return {
            "collection": record.address,
            "name": record.name,
            "items": record.item_count,
            "listings": record.listings_count,
            "opportunities": len(opportunities),
        }
