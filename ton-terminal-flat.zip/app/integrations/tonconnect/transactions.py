"""On-chain verification of transactions submitted through TON Connect.

Nothing is ever trusted from the client: after the user approves a transaction
in the wallet, the backend re-reads it from the blockchain (TON Center API v3)
before marking anything as confirmed.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from app.core.logging import get_logger
from app.integrations.toncenter.client import TonCenterClient

logger = get_logger(__name__)


@dataclass
class VerificationResult:
    confirmed: bool
    tx_hash: str | None = None
    lt: int | None = None
    utime: int | None = None
    success: bool = False
    raw: dict | None = None
    reason: str | None = None


class TransactionVerifier:
    """Verify transactions using documented TON Center endpoints."""

    def __init__(self, client: TonCenterClient | None = None) -> None:
        self.client = client or TonCenterClient()

    async def verify_by_hash(self, tx_hash: str) -> VerificationResult:
        """GET /transactions?hash=... - simplest, most reliable check."""
        txs = await self.client.get_transactions(hash_=tx_hash)
        if not txs:
            return VerificationResult(confirmed=False, reason="transaction not indexed yet")
        tx = txs[0]
        description = tx.get("description") or {}
        compute = description.get("compute_ph") or {}
        success = not description.get("aborted", False) and compute.get("success", True)
        return VerificationResult(
            confirmed=True,
            tx_hash=tx.get("hash") or tx_hash,
            lt=int(tx.get("lt") or 0) or None,
            utime=tx.get("now"),
            success=bool(success),
            raw=tx,
        )

    async def find_transaction(
        self,
        wallet_address: str,
        *,
        to_address: str | None = None,
        min_amount_nano: int | None = None,
        since_utime: int | None = None,
        lookback: int = 900,
    ) -> VerificationResult:
        """Locate a recent outgoing transaction matching the intent.

        Used when the Mini App cannot provide a tx hash (e.g. the wallet only
        returns the signed BOC). Matching is done on destination + amount.
        """
        now = int(time.time())
        start = since_utime or (now - lookback)
        txs = await self.client.get_transactions(
            account=wallet_address, start_utime=start, end_utime=now, limit=100
        )
        for tx in txs:
            out_msgs = (tx.get("out_msgs") or []) if isinstance(tx, dict) else []
            for msg in out_msgs:
                destination = (msg.get("destination") or "").upper()
                value = int(msg.get("value") or 0)
                if to_address and to_address.upper() not in destination:
                    continue
                if min_amount_nano is not None and value < int(min_amount_nano):
                    continue
                return VerificationResult(
                    confirmed=True,
                    tx_hash=tx.get("hash"),
                    lt=int(tx.get("lt") or 0) or None,
                    utime=tx.get("now"),
                    success=True,
                    raw=tx,
                )
        return VerificationResult(confirmed=False, reason="no matching transaction found yet")
