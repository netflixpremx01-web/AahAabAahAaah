"""TON Connect manifest (https://docs.ton.org/applications/ton-connect/get-started).

The manifest is served from the backend over HTTPS so wallets can display the
app name and icon inside the connect sheet. It contains no secrets.
"""
from __future__ import annotations

from typing import Any

from app.core.config import get_settings


def manifest_url() -> str:
    """Public URL of ``tonconnect-manifest.json`` served by the API."""
    settings = get_settings()
    base = (settings.ton_app_url or "").rstrip("/")
    return f"{base}/tonconnect-manifest.json"


def build_manifest() -> dict[str, Any]:
    settings = get_settings()
    base = (settings.ton_app_url or "http://localhost:8000").rstrip("/")
    return {
        "url": base,
        "name": settings.app_name,
        "iconUrl": f"{base}/icons/icon-180.png",
        "termsOfUseUrl": f"{base}/terms.html",
        "privacyPolicyUrl": f"{base}/privacy.html",
    }
