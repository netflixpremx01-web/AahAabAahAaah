"""TON Connect wallet authorisation verification (``ton_proof``).

Reference: https://docs.ton.org/applications/ton-connect/protocol/wallet-authorization

The wallet signs:

    0xffff || "ton-connect" || sha256(
        "ton-proof-item-v2/" || workchain(int32 BE) || address_hash(32)
        || domain_len(int32 LE) || domain || timestamp(int64 LE) || payload
    )

with its ed25519 private key. Verifying the signature proves control of the
wallet without ever touching a seed phrase or a private key.
"""
from __future__ import annotations

import base64
import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any

from app.core.config import get_settings
from app.core.errors import AuthenticationError
from app.core.logging import get_logger

logger = get_logger(__name__)

DEFAULT_PROOF_TTL = 300  # seconds


@dataclass
class TonProof:
    timestamp: int
    domain: str
    signature: str
    payload: str


@dataclass
class WalletAuth:
    address: str
    network: str
    public_key: str
    wallet_app: str | None = None
    wallet_state_init: str | None = None
    proof: TonProof | None = None
    raw: dict[str, Any] = field(default_factory=dict)


def _b64_decode(value: str) -> bytes:
    value = value.strip()
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def parse_raw_address(address: str) -> tuple[int, bytes]:
    """Parse ``"<workchain>:<64 hex>"`` into ``(workchain, hash_bytes)``."""
    if ":" not in address:
        raise AuthenticationError(f"unsupported address format: {address}")
    workchain, hex_part = address.split(":", 1)
    hex_part = hex_part.lower().replace("_", "")
    if len(hex_part) != 64:
        raise AuthenticationError("address hash must be 32 bytes")
    try:
        return int(workchain), bytes.fromhex(hex_part)
    except ValueError as exc:  # pragma: no cover - defensive
        raise AuthenticationError("invalid address hash") from exc


def build_proof_message(address: str, domain: str, timestamp: int, payload: str) -> bytes:
    workchain, address_hash = parse_raw_address(address)
    message = (
        b"ton-proof-item-v2/"
        + workchain.to_bytes(4, "big")
        + address_hash
        + len(domain).to_bytes(4, "little")
        + domain.encode()
        + timestamp.to_bytes(8, "little")
        + payload.encode()
    )
    inner = hashlib.sha256(message).digest()
    return b"\xff\xff" + b"ton-connect" + inner


def verify_ton_proof(
    auth: WalletAuth,
    *,
    expected_domain: str | None = None,
    max_age_seconds: int = DEFAULT_PROOF_TTL,
) -> bool:
    """Verify a TON Connect ``ton_proof``. Raises :class:`AuthenticationError`."""
    if auth.proof is None:
        raise AuthenticationError("wallet did not provide a ton_proof payload")
    proof = auth.proof

    if expected_domain and proof.domain.lower() != expected_domain.lower():
        raise AuthenticationError("ton_proof domain mismatch")

    age = abs(int(time.time()) - int(proof.timestamp))
    if age > max_age_seconds:
        raise AuthenticationError("ton_proof is too old")

    try:
        from nacl.exceptions import BadSignatureError  # type: ignore
        from nacl.signing import VerifyKey  # type: ignore
    except ImportError as exc:  # pragma: no cover - dependency guard
        raise AuthenticationError("PyNaCl is required to verify ton_proof") from exc

    message = build_proof_message(auth.address, proof.domain, int(proof.timestamp), proof.payload)
    try:
        public_key = bytes.fromhex(auth.public_key)
        if len(public_key) != 32:
            raise ValueError
    except ValueError:
        try:
            public_key = _b64_decode(auth.public_key)
        except Exception as exc:  # pragma: no cover
            raise AuthenticationError("invalid public key encoding") from exc
    if len(public_key) != 32:
        raise AuthenticationError("public key must be 32 bytes")

    try:
        VerifyKey(public_key).verify(message, _b64_decode(proof.signature))
    except BadSignatureError as exc:
        raise AuthenticationError("ton_proof signature is invalid") from exc
    except Exception as exc:  # pragma: no cover - malformed input
        raise AuthenticationError(f"ton_proof verification failed: {exc}") from exc
    return True


def wallet_auth_from_payload(payload: dict[str, Any]) -> WalletAuth:
    """Build a :class:`WalletAuth` from the payload sent by the Mini App."""
    proof_raw = payload.get("proof") or {}
    proof = None
    if proof_raw and all(k in proof_raw for k in ("timestamp", "domain", "signature", "payload")):
        proof = TonProof(
            timestamp=int(proof_raw["timestamp"]),
            domain=str(proof_raw["domain"]),
            signature=str(proof_raw["signature"]),
            payload=str(proof_raw.get("payload", "")),
        )
    device = payload.get("device") or {}
    return WalletAuth(
        address=str(payload.get("address") or ""),
        network=str(payload.get("network") or get_settings().ton_network),
        public_key=str(payload.get("publicKey") or ""),
        wallet_app=device.get("appName") or payload.get("walletApp"),
        wallet_state_init=payload.get("walletStateInit"),
        proof=proof,
        raw=payload,
    )


def expected_domain(ton_app_url: str | None = None) -> str | None:
    settings = get_settings()
    url = ton_app_url or settings.ton_app_url
    if not url:
        return None
    from urllib.parse import urlparse

    host = urlparse(url).hostname
    return host


def dumps(payload: Any) -> str:  # pragma: no cover - helper
    return json.dumps(payload, default=str)
