"""Marketplace adapter contract.

Every marketplace (Portals, GetGems, ...) is integrated behind this interface so
providers can be swapped or added without touching business logic.

Rules enforced across adapters:

* no adapter invents an endpoint - unverified capabilities raise
  :class:`~app.core.errors.CapabilityNotSupported`;
* an adapter never signs anything and never asks for a private key/seed;
* listing/sales data is *raw*: scoring and valuation live in :mod:`app.nft`
  and :mod:`app.radar`.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from app.core.errors import CapabilityNotSupported
from app.core.money import d, nano_from_ton


@dataclass
class Listing:
    marketplace: str
    listing_id: str
    nft_address: str
    collection_address: str | None = None
    price_ton: Any = None            # Decimal
    price_nano: int = 0
    currency: str = "TON"
    seller_address: str | None = None
    marketplace_fee_bps: int = 500
    royalty_bps: int = 500
    expires_at: datetime | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.price_nano and self.price_ton is not None:
            self.price_nano = nano_from_ton(self.price_ton)
        if not self.price_ton and self.price_nano:
            from app.core.money import ton_from_nano

            self.price_ton = ton_from_nano(self.price_nano)


@dataclass
class SaleRecord:
    marketplace: str
    sale_id: str
    nft_address: str
    collection_address: str | None = None
    price_ton: Any = None
    price_nano: int = 0
    currency: str = "TON"
    buyer_address: str | None = None
    seller_address: str | None = None
    sold_at: datetime | None = None
    tx_hash: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class CollectionStats:
    address: str
    floor_ton: Any | None = None
    volume_24h_ton: Any | None = None
    volume_7d_ton: Any | None = None
    sales_24h: int | None = None
    listings_count: int | None = None
    owners_count: int | None = None
    source: str = "adapter"


@dataclass
class PreparedTransaction:
    """A transaction the *user's wallet* must approve.

    The backend only ever produces these - it never signs and never submits.
    """

    marketplace: str
    action: str
    to_address: str
    amount_nano: int
    payload_boc: str | None = None
    state_init: str | None = None
    valid_until: int | None = None
    requires_client_sdk: bool = False
    notes: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def amount_ton(self) -> Any:
        return d(self.amount_nano) / d(1_000_000_000)


@dataclass
class Capabilities:
    collections: bool = False
    listings: bool = False
    sales: bool = False
    floor: bool = False
    stats: bool = False
    buy: bool = False
    sell: bool = False
    cancel: bool = False

    def as_dict(self) -> dict[str, bool]:
        return {
            "collections": self.collections,
            "listings": self.listings,
            "sales": self.sales,
            "floor": self.floor,
            "stats": self.stats,
            "buy": self.buy,
            "sell": self.sell,
            "cancel": self.cancel,
        }


class MarketplaceAdapter(ABC):
    """Interface every marketplace integration must implement."""

    name: str = "abstract"
    docs_url: str | None = None
    # Human readable status shown in the UI ("live", "read-only", "unavailable").
    status: str = "unknown"
    status_note: str | None = None

    def capabilities(self) -> Capabilities:
        return Capabilities()

    def supports(self, capability: str) -> bool:
        return bool(getattr(self.capabilities(), capability, False))

    def _require(self, capability: str) -> None:
        if not self.supports(capability):
            raise CapabilityNotSupported(
                f"{self.name} does not expose '{capability}' "
                f"(documented API: {self.docs_url or 'n/a'})",
                marketplace=self.name,
                capability=capability,
            )

    # ------------------------------------------------------------- reads
    @abstractmethod
    async def get_collections(self, *, limit: int = 20, offset: int = 0) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def get_listings(
        self, collection: str | None = None, *, limit: int = 50, offset: int = 0
    ) -> list[Listing]: ...

    @abstractmethod
    async def get_listing(self, nft_address: str) -> Listing | None: ...

    async def get_floor_price(self, collection: str) -> Any | None:
        """Floor = cheapest active listing (default implementation)."""
        self._require("listings")
        listings = await self.get_listings(collection, limit=100)
        prices = [d(item.price_ton) for item in listings if d(item.price_ton) > 0]
        return min(prices) if prices else None

    @abstractmethod
    async def get_sales(self, collection: str | None = None, *, limit: int = 50) -> list[SaleRecord]: ...

    @abstractmethod
    async def get_collection_stats(self, collection: str) -> CollectionStats: ...

    # ------------------------------------------------------------ writes
    @abstractmethod
    async def prepare_buy_transaction(self, listing: Listing, buyer_address: str) -> PreparedTransaction: ...

    @abstractmethod
    async def prepare_sell_transaction(
        self, nft_address: str, price_ton: Any, seller_address: str
    ) -> PreparedTransaction: ...

    async def create_listing(
        self, nft_address: str, price_ton: Any, seller_address: str
    ) -> PreparedTransaction:
        return await self.prepare_sell_transaction(nft_address, price_ton, seller_address)

    @abstractmethod
    async def cancel_listing(self, listing: Listing, owner_address: str) -> PreparedTransaction: ...

    # -------------------------------------------------------------- meta
    def describe(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "status_note": self.status_note,
            "docs_url": self.docs_url,
            "capabilities": self.capabilities().as_dict(),
        }
