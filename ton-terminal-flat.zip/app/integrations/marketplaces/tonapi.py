"""Read-only NFT data adapter backed by TonAPI (https://docs.tonconsole.com/tonapi).

Only endpoints that were verified against the live API are used:

    GET /v2/nfts/{nft_id}                          - NFT + optional sale object
    GET /v2/nfts/collections/{account_id}          - collection metadata
    GET /v2/nfts/collections/{account_id}/items    - collection items

TonAPI is used as *read-only market data*. Transaction building is not part of
its public REST surface, so buy/sell capabilities raise
:class:`CapabilityNotSupported` instead of fabricating a payload.
"""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from app.core.cache import cached
from app.core.config import get_settings
from app.core.errors import CapabilityNotSupported
from app.core.http import HttpClient
from app.core.logging import get_logger
from app.core.money import d, nano_from_ton
from app.integrations.marketplaces.base import (
    Capabilities,
    CollectionStats,
    Listing,
    MarketplaceAdapter,
    PreparedTransaction,
    SaleRecord,
)

logger = get_logger(__name__)


class TonApiAdapter(MarketplaceAdapter):
    """Read-only adapter over TonAPI v2."""

    name = "tonapi"
    docs_url = "https://docs.tonconsole.com/tonapi"
    status = "read-only"
    status_note = (
        "Read-only NFT/sale data. Buy and sell transactions require the "
        "marketplace's own SDK; this adapter never fabricates payloads."
    )

    def __init__(self, api_key: str | None = None) -> None:
        settings = get_settings()
        self.api_key = api_key if api_key is not None else settings.ton_api_key
        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        self.http = HttpClient("https://tonapi.io/v2", headers=headers, limiter_name="tonapi")

    def capabilities(self) -> Capabilities:
        return Capabilities(collections=True, listings=True, floor=True)

    # ------------------------------------------------------------- plumbing
    async def _get(self, path: str, *, ttl: int = 60) -> dict[str, Any]:
        key = f"tonapi:{path}"

        async def call() -> dict[str, Any]:
            result = await self.http.get(path)
            return result if isinstance(result, dict) else {}

        return await cached(key, ttl, call)

    @staticmethod
    def _listing_from_payload(nft: dict[str, Any]) -> Listing | None:
        sale = nft.get("sale") or {}
        if not sale:
            return None
        price = d(sale.get("price", {}).get("value", 0)) / d(1_000_000_000)
        return Listing(
            marketplace="tonapi",
            listing_id=str(sale.get("address") or nft.get("address")),
            nft_address=str(nft.get("address")),
            collection_address=(nft.get("collection") or {}).get("address"),
            price_ton=price,
            price_nano=nano_from_ton(price),
            seller_address=(sale.get("seller") or {}).get("address"),
            raw=nft,
        )

    # ---------------------------------------------------------------- reads
    async def get_collections(self, *, limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
        raise CapabilityNotSupported(
            "TonAPI exposes collection lookup by address only "
            "(GET /v2/nfts/collections/{account_id}) - no public collection listing.",
            marketplace=self.name,
        )

    async def get_listings(
        self, collection: str | None = None, *, limit: int = 50, offset: int = 0
    ) -> list[Listing]:
        if not collection:
            raise CapabilityNotSupported(
                "TonAPI requires a collection address to enumerate items", marketplace=self.name
            )
        data = await self._get(
            f"/nfts/collections/{collection}/items?limit={min(limit, 1000)}&offset={offset}"
        )
        items = data.get("nft_items", [])
        listings = [item for item in (self._listing_from_payload(i) for i in items) if item]
        return listings

    async def get_listing(self, nft_address: str) -> Listing | None:
        nft = await self._get(f"/nfts/{nft_address}")
        return self._listing_from_payload(nft)

    async def get_nft(self, nft_address: str) -> dict[str, Any]:
        return await self._get(f"/nfts/{nft_address}")

    async def get_collection(self, collection: str) -> dict[str, Any]:
        return await self._get(f"/nfts/collections/{collection}")

    async def get_collection_items(
        self, collection: str, *, limit: int = 100, offset: int = 0
    ) -> list[dict[str, Any]]:
        data = await self._get(
            f"/nfts/collections/{collection}/items?limit={min(limit, 1000)}&offset={offset}",
            ttl=120,
        )
        return data.get("nft_items", [])

    async def get_wallet_nfts(self, owner: str, *, limit: int = 100) -> list[dict[str, Any]]:
        data = await self._get(
            f"/accounts/{owner}/nfts?limit={min(limit, 1000)}&indirect_ownership=false", ttl=60
        )
        return data.get("nft_items", [])

    async def get_sales(self, collection: str | None = None, *, limit: int = 50) -> list[SaleRecord]:
        raise CapabilityNotSupported(
            "TonAPI's public REST surface does not expose a historical sales feed; "
            "sales are derived on-chain in this project via TON Center "
            "(GET /nft/transfers + /actions).",
            marketplace=self.name,
        )

    async def get_collection_stats(self, collection: str) -> CollectionStats:
        raise CapabilityNotSupported(
            "Collection statistics are computed locally by the stats engine from "
            "indexed listings/sales instead of relying on an unverified endpoint.",
            marketplace=self.name,
        )

    # --------------------------------------------------------------- writes
    async def prepare_buy_transaction(self, listing: Listing, buyer_address: str) -> PreparedTransaction:
        raise CapabilityNotSupported(
            "Buying requires the marketplace's own transaction builder "
            "(GetGems/Portals SDK). No payload is fabricated here.",
            marketplace=self.name,
        )

    async def prepare_sell_transaction(
        self, nft_address: str, price_ton: Any, seller_address: str
    ) -> PreparedTransaction:
        raise CapabilityNotSupported(
            "Listing requires the marketplace's own SDK. No payload is fabricated here.",
            marketplace=self.name,
        )

    async def cancel_listing(self, listing: Listing, owner_address: str) -> PreparedTransaction:
        raise CapabilityNotSupported(
            "Cancelling a listing requires the marketplace's own SDK.",
            marketplace=self.name,
        )

    @staticmethod
    def parse_datetime(value: Any) -> datetime | None:
        if isinstance(value, int):
            return datetime.fromtimestamp(value, tz=UTC).replace(tzinfo=None)
        return None

    async def aclose(self) -> None:
        await self.http.aclose()
