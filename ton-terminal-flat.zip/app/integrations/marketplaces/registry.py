"""Registry of marketplace adapters."""
from __future__ import annotations

from app.integrations.marketplaces.base import MarketplaceAdapter
from app.integrations.marketplaces.portals import PortalsAdapter
from app.integrations.marketplaces.tonapi import TonApiAdapter

_ADAPTERS: dict[str, MarketplaceAdapter] | None = None


def build_adapters() -> dict[str, MarketplaceAdapter]:
    return {
        "tonapi": TonApiAdapter(),
        "portals": PortalsAdapter(),
    }


def get_adapters() -> dict[str, MarketplaceAdapter]:
    global _ADAPTERS
    if _ADAPTERS is None:
        _ADAPTERS = build_adapters()
    return _ADAPTERS


def get_adapter(name: str) -> MarketplaceAdapter:
    adapters = get_adapters()
    if name not in adapters:
        raise KeyError(f"unknown marketplace adapter: {name}")
    return adapters[name]


def get_read_adapters() -> list[MarketplaceAdapter]:
    """Adapters that can actually serve listing data right now."""
    return [a for a in get_adapters().values() if a.supports("listings")]


def describe_all() -> list[dict]:
    return [adapter.describe() for adapter in get_adapters().values()]
