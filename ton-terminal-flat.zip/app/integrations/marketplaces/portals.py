"""Portals marketplace adapter.

STATUS: **no official public API is published by Portals** at the time this
adapter was written. The only public references found are unofficial,
reverse-engineered clients, which this project deliberately does not use
(bypassing authentication or scraping is out of scope).

Therefore:

* every capability reports ``False``;
* each method raises :class:`CapabilityNotSupported` / :class:`ProviderUnavailable`
  with an actionable message instead of returning fake data;
* the adapter nevertheless exposes the *exact* endpoint map that Portals would
  need to provide. Supply them through configuration (``PORTALS_ENDPOINT_MAP``)
  and the adapter becomes live with no code change.
"""
from __future__ import annotations

import json
from typing import Any

from app.core.config import get_settings
from app.core.errors import CapabilityNotSupported, ProviderUnavailable
from app.core.logging import get_logger
from app.integrations.marketplaces.base import (
    Capabilities,
    CollectionStats,
    Listing,
    MarketplaceAdapter,
    PreparedTransaction,
    SaleRecord,
)

logger = get_logger(__name__)

REQUIRED_ENDPOINTS = (
    "collections",
    "listings",
    "listing_by_nft",
    "sales",
    "collection_stats",
    "buy",
    "sell",
    "cancel",
)


class PortalsAdapter(MarketplaceAdapter):
    """Adapter skeleton for the Portals marketplace."""

    name = "portals"
    docs_url = "https://portals.to"
    status = "unavailable"
    status_note = (
        "Portals does not publish a documented public API. Supply official "
        "credentials (MARKETPLACE_API_KEY) and the endpoint map "
        "(PORTALS_ENDPOINT_MAP) to activate this adapter."
    )

    def __init__(self, endpoints: dict[str, str] | None = None) -> None:
        settings = get_settings()
        self.endpoints: dict[str, str] = dict(endpoints or {})
        raw_map = getattr(settings, "portals_endpoint_map", None)
        if raw_map:
            try:
                self.endpoints.update(json.loads(raw_map))
            except json.JSONDecodeError:
                logger.warning("PORTALS_ENDPOINT_MAP is not valid JSON - ignoring")
        self.api_key = settings.marketplace_api_key
        self.base_url = settings.portals_api_base_url

    # --------------------------------------------------------------- status
    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.api_key and self.endpoints)

    def capabilities(self) -> Capabilities:
        if not self.configured:
            return Capabilities()
        return Capabilities(
            collections="collections" in self.endpoints,
            listings="listings" in self.endpoints,
            sales="sales" in self.endpoints,
            floor="listings" in self.endpoints,
            stats="collection_stats" in self.endpoints,
            buy="buy" in self.endpoints,
            sell="sell" in self.endpoints,
            cancel="cancel" in self.endpoints,
        )

    def _unavailable(self, capability: str) -> Exception:
        if self.configured and capability not in self.endpoints:
            return CapabilityNotSupported(
                f"Portals endpoint map has no '{capability}' entry", marketplace="portals"
            )
        return ProviderUnavailable(
            "Portals has no documented public API for this capability. "
            "Provide PORTALS_API_BASE_URL, MARKETPLACE_API_KEY and "
            "PORTALS_ENDPOINT_MAP from official access to enable it.",
            marketplace="portals",
            capability=capability,
        )

    # ---------------------------------------------------------------- reads
    async def get_collections(self, *, limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
        raise self._unavailable("collections")

    async def get_listings(
        self, collection: str | None = None, *, limit: int = 50, offset: int = 0
    ) -> list[Listing]:
        raise self._unavailable("listings")

    async def get_listing(self, nft_address: str) -> Listing | None:
        raise self._unavailable("listing_by_nft")

    async def get_sales(self, collection: str | None = None, *, limit: int = 50) -> list[SaleRecord]:
        raise self._unavailable("sales")

    async def get_collection_stats(self, collection: str) -> CollectionStats:
        raise self._unavailable("collection_stats")

    # --------------------------------------------------------------- writes
    async def prepare_buy_transaction(self, listing: Listing, buyer_address: str) -> PreparedTransaction:
        raise self._unavailable("buy")

    async def prepare_sell_transaction(
        self, nft_address: str, price_ton: Any, seller_address: str
    ) -> PreparedTransaction:
        raise self._unavailable("sell")

    async def cancel_listing(self, listing: Listing, owner_address: str) -> PreparedTransaction:
        raise self._unavailable("cancel")

    def describe(self) -> dict[str, Any]:
        payload = super().describe()
        payload.update(
            {
                "configured": self.configured,
                "required_endpoints": list(REQUIRED_ENDPOINTS),
                "endpoint_map": sorted(self.endpoints),
            }
        )
        return payload
