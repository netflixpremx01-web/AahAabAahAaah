"""TON Center API v3 client.

Only endpoints documented at https://docs.ton.org/api/v3/overview are used:

    GET /masterchainInfo            GET /nft/collections
    GET /accountStates              GET /nft/items
    GET /walletStates               GET /nft/transfers
    GET /addressBook                GET /nft/sales
    GET /metadata                   GET /jetton/masters
    GET /transactions               GET /jetton/wallets
    GET /actions                    GET /jetton/transfers
    GET /transactionsByMessage

Every call is rate limited, retried with exponential backoff and cached.
The API key (``X-API-Key``) is added server-side only and never leaves the
backend.
"""
from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterable
from typing import Any

from app.core.cache import cached
from app.core.config import get_settings
from app.core.http import HttpClient
from app.core.logging import get_logger

logger = get_logger(__name__)

DEFAULT_LIMIT = 100
MAX_LIMIT = 1000


class TonCenterClient:
    """Typed wrapper over the documented TON Center API v3 surface."""

    def __init__(self, api_key: str | None = None, base_url: str | None = None) -> None:
        settings = get_settings()
        self.api_key = api_key if api_key is not None else settings.toncenter_api_key
        self.base_url = (base_url or settings.toncenter_base_url or "").rstrip("/")
        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        self.http = HttpClient(
            base_url=self.base_url, headers=headers, limiter_name="toncenter"
        )
        self.has_api_key = bool(self.api_key)

    # ---------------------------------------------------------------- utils
    @staticmethod
    def _as_list(value: str | Iterable[str] | None) -> list[str] | None:
        if value is None:
            return None
        if isinstance(value, str):
            return [value]
        return [item for item in value]

    def _cache_key(self, path: str, params: dict[str, Any]) -> str:
        return f"toncenter:{self.base_url}:{path}:{json.dumps(params, sort_keys=True, default=str)}"

    async def _get(
        self, path: str, params: dict[str, Any] | None = None, *, ttl: int | None = None
    ) -> dict[str, Any]:
        payload = {k: v for k, v in (params or {}).items() if v is not None}
        ttl = ttl if ttl is not None else get_settings().provider_cache_ttl_seconds

        async def call() -> dict[str, Any]:
            logger.debug("toncenter.request", extra={"extra_fields": {"path": path, "params": payload}})
            result = await self.http.get(path, params=payload)
            return result if isinstance(result, dict) else {"result": result}

        return await cached(self._cache_key(path, payload), ttl, call)

    # ------------------------------------------------------------ blockchain
    async def get_masterchain_info(self) -> dict[str, Any]:
        """GET /masterchainInfo - last indexed masterchain block."""
        return await self._get("/masterchainInfo", ttl=10)

    async def get_account_states(self, addresses: str | Iterable[str]) -> list[dict[str, Any]]:
        """GET /accountStates - balance and status for one or many accounts."""
        data = await self._get("/accountStates", {"address": self._as_list(addresses)}, ttl=15)
        return data.get("accounts", [])

    async def get_wallet_states(self, addresses: str | Iterable[str]) -> list[dict[str, Any]]:
        """GET /walletStates - wallet contract states (is_wallet, seqno, balance)."""
        data = await self._get("/walletStates", {"address": self._as_list(addresses)}, ttl=15)
        return data.get("wallets", [])

    async def get_address_book(self, addresses: str | Iterable[str]) -> dict[str, Any]:
        """GET /addressBook - interfaces (nft_item, jetton_wallet, ...) and domains."""
        data = await self._get("/addressBook", {"address": self._as_list(addresses)}, ttl=300)
        return data.get("address_book", {})

    async def get_metadata(self, addresses: str | Iterable[str]) -> dict[str, Any]:
        """GET /metadata - indexed token/collection metadata."""
        data = await self._get("/metadata", {"address": self._as_list(addresses)}, ttl=600)
        return data.get("metadata", {})

    async def get_transactions(
        self,
        account: str | None = None,
        *,
        limit: int = 20,
        offset: int = 0,
        start_utime: int | None = None,
        end_utime: int | None = None,
        hash_: str | None = None,
    ) -> list[dict[str, Any]]:
        """GET /transactions - raw transactions for an account."""
        data = await self._get(
            "/transactions",
            {
                "account": account,
                "hash": hash_,
                "start_utime": start_utime,
                "end_utime": end_utime,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
            },
            ttl=20,
        )
        return data.get("transactions", [])

    async def get_transactions_by_message(self, msg_hash: str, direction: str = "in") -> list[dict]:
        """GET /transactionsByMessage - resolve tx from a message hash."""
        data = await self._get(
            "/transactionsByMessage",
            {"msg_hash": msg_hash, "direction": direction},
            ttl=60,
        )
        return data.get("transactions", [])

    async def get_actions(
        self,
        account: str | None = None,
        *,
        action_type: str | Iterable[str] | None = None,
        limit: int = 50,
        offset: int = 0,
        start_utime: int | None = None,
        end_utime: int | None = None,
        include_transactions: bool = False,
        sort: str = "desc",
    ) -> list[dict[str, Any]]:
        """GET /actions - decoded, human readable blockchain activity."""
        data = await self._get(
            "/actions",
            {
                "account": account,
                "action_type": self._as_list(action_type),
                "start_utime": start_utime,
                "end_utime": end_utime,
                "include_transactions": include_transactions,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
                "sort": sort,
            },
            ttl=30,
        )
        return data.get("actions", [])

    async def get_supported_action_types(self) -> list[str]:
        """GET /actions - list of action types supported by the indexer."""
        data = await self._get("/actions", {"supported_action_types": "true"}, ttl=3600)
        return data.get("action_types", data.get("supported_action_types", []))

    # ----------------------------------------------------------------- NFTs
    async def get_nft_collections(
        self,
        address: str | Iterable[str] | None = None,
        *,
        owner_address: str | None = None,
        limit: int = 10,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /nft/collections - NFT collection records."""
        data = await self._get(
            "/nft/collections",
            {
                "address": self._as_list(address),
                "owner_address": owner_address,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
            },
            ttl=300,
        )
        return data.get("nft_collections", [])

    async def get_nft_items(
        self,
        address: str | Iterable[str] | None = None,
        *,
        owner_address: str | None = None,
        collection_address: str | None = None,
        index: str | Iterable[str] | None = None,
        include_on_sale: bool | None = None,
        limit: int = DEFAULT_LIMIT,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /nft/items - NFT item records (ownership, content, sale state)."""
        data = await self._get(
            "/nft/items",
            {
                "address": self._as_list(address),
                "owner_address": owner_address,
                "collection_address": collection_address,
                "index": self._as_list(index),
                "include_on_sale": include_on_sale,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
            },
            ttl=60,
        )
        return data.get("nft_items", [])

    async def iter_owner_nft_items(
        self, owner_address: str, *, page_size: int = DEFAULT_LIMIT, max_items: int = 1000
    ) -> AsyncIterator[dict[str, Any]]:
        """Paginate through every NFT owned by an address (1 NFT = 1 item)."""
        offset = 0
        fetched = 0
        while fetched < max_items:
            batch = await self.get_nft_items(
                owner_address=owner_address,
                limit=min(page_size, max_items - fetched),
                offset=offset,
            )
            if not batch:
                return
            for item in batch:
                yield item
            fetched += len(batch)
            offset += len(batch)
            if len(batch) < page_size:
                return

    async def get_nft_transfers(
        self,
        *,
        nft_address: str | None = None,
        collection_address: str | None = None,
        owner_address: str | None = None,
        start_utime: int | None = None,
        end_utime: int | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /nft/transfers - ownership change history (sales detection)."""
        data = await self._get(
            "/nft/transfers",
            {
                "nft_address": nft_address,
                "nft_collection": collection_address,
                "owner_address": owner_address,
                "start_utime": start_utime,
                "end_utime": end_utime,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
            },
            ttl=60,
        )
        return data.get("nft_transfers", [])

    async def get_nft_purchases(
        self,
        *,
        collection_address: str | None = None,
        nft_address: str | None = None,
        owner_address: str | None = None,
        start_utime: int | None = None,
        end_utime: int | None = None,
        limit: int = 100,
        offset: int = 0,
        pages: int = 1,
    ) -> list[dict[str, Any]]:
        """GET /actions?action_type=nft_purchase - decoded NFT sales.

        Each action ``details`` contains ``nft_item``, ``nft_collection``,
        ``price`` (nanoTON), ``old_owner`` (seller), ``new_owner`` (buyer),
        ``marketplace_address`` and ``payout_amount``.

        NOTE: the indexer's ``start_utime``/``end_utime`` filters are expensive
        for ``nft_purchase`` (they regularly time out server-side), so the time
        window is applied client-side while paging with ``offset`` only.
        """
        actions: list[dict[str, Any]] = []
        for page in range(max(1, pages)):
            data = await self._get(
                "/actions",
                {
                    "account": owner_address,
                    "action_type": "nft_purchase",
                    "limit": min(limit, MAX_LIMIT),
                    "offset": offset + page * min(limit, MAX_LIMIT),
                },
                ttl=60,
            )
            page_actions = data.get("actions", [])
            actions.extend(page_actions)
            if len(page_actions) < min(limit, MAX_LIMIT):
                break

        def _ts(action: dict[str, Any]) -> int:
            return int(action.get("end_utime") or action.get("start_utime") or 0)

        if start_utime:
            actions = [action for action in actions if _ts(action) >= start_utime]
        if end_utime:
            actions = [action for action in actions if _ts(action) <= end_utime]
        if collection_address:
            needle = collection_address.lower().replace("-1:", "0:")
            actions = [
                action
                for action in actions
                if str((action.get("details") or {}).get("nft_collection") or "")
                .lower()
                .replace("-1:", "0:")
                == needle
            ]
        if nft_address:
            needle = nft_address.lower().replace("-1:", "0:")
            actions = [
                action
                for action in actions
                if str((action.get("details") or {}).get("nft_item") or "")
                .lower()
                .replace("-1:", "0:")
                == needle
            ]
        return actions

    async def get_nft_sales(self, addresses: str | Iterable[str]) -> list[dict[str, Any]]:
        """GET /nft/sales - sale/auction contracts (GetGems sale contracts)."""
        data = await self._get("/nft/sales", {"address": self._as_list(addresses)}, ttl=60)
        return data.get("nft_sales", [])

    # -------------------------------------------------------------- jettons
    async def get_jetton_masters(
        self,
        address: str | Iterable[str] | None = None,
        *,
        admin_address: str | None = None,
        limit: int = 10,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /jetton/masters - jetton master metadata (symbol, decimals)."""
        data = await self._get(
            "/jetton/masters",
            {
                "address": self._as_list(address),
                "admin_address": admin_address,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
            },
            ttl=600,
        )
        return data.get("jetton_masters", [])

    async def get_jetton_wallets(
        self,
        *,
        owner_address: str | None = None,
        jetton_address: str | None = None,
        limit: int = 10,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /jetton/wallets - per-owner jetton balances."""
        data = await self._get(
            "/jetton/wallets",
            {
                "owner_address": owner_address,
                "jetton_address": jetton_address,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
            },
            ttl=20,
        )
        return data.get("jetton_wallets", [])

    async def get_jetton_transfers(
        self,
        *,
        owner_address: str | None = None,
        jetton_wallet: str | None = None,
        jetton_master: str | None = None,
        start_utime: int | None = None,
        end_utime: int | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /jetton/transfers - jetton transfer history."""
        data = await self._get(
            "/jetton/transfers",
            {
                "owner_address": owner_address,
                "jetton_wallet": jetton_wallet,
                "jetton_master": jetton_master,
                "start_utime": start_utime,
                "end_utime": end_utime,
                "limit": min(limit, MAX_LIMIT),
                "offset": offset,
            },
            ttl=30,
        )
        return data.get("jetton_transfers", [])

    # --------------------------------------------------------- convenience
    async def get_balance_ton(self, address: str) -> int:
        """Account balance in nanoTON (0 for uninitialised accounts)."""
        states = await self.get_account_states(address)
        if not states:
            return 0
        return int(states[0].get("balance") or 0)

    async def get_jetton_balance(self, owner_address: str, jetton_master: str) -> int:
        """Balance of a specific jetton for an owner, in jetton base units."""
        wallets = await self.get_jetton_wallets(
            owner_address=owner_address, jetton_address=jetton_master, limit=100
        )
        return int(wallets[0].get("balance") or 0) if wallets else 0

    async def aclose(self) -> None:
        await self.http.aclose()


_client: TonCenterClient | None = None


def get_toncenter_client() -> TonCenterClient:
    global _client
    if _client is None:
        _client = TonCenterClient()
    return _client
