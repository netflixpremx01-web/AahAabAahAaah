"""DEX adapter contract (STON.fi, DeDust, future providers).

Flow enforced everywhere::

    QUOTE -> USER CONFIRMATION -> TON CONNECT -> WALLET APPROVAL
          -> BLOCKCHAIN TX -> BACKEND VERIFICATION

An adapter never swaps autonomously and never holds funds.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

from app.core.config import get_settings
from app.core.errors import CapabilityNotSupported
from app.core.money import d, nano_from_ton


@dataclass
class TokenInfo:
    address: str
    symbol: str
    name: str = ""
    decimals: int = 9
    kind: str = "jetton"   # "jetton" | "native"
    image_url: str | None = None
    verified: bool = False


@dataclass
class PoolInfo:
    address: str
    token0: str
    token1: str
    reserve0: int = 0
    reserve1: int = 0
    fee_bps: int = 30
    last_price: Any | None = None
    provider: str = ""
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class SwapQuoteRequest:
    from_token: str
    to_token: str
    amount: Any                 # human units (Decimal)
    slippage: Any | None = None  # 0.01 = 1%
    wallet_address: str | None = None
    referral_address: str | None = None

    @property
    def slippage_value(self) -> Any:
        settings = get_settings()
        value = d(self.slippage if self.slippage is not None else settings.default_slippage)
        max_slip = d(settings.max_slippage)
        return min(value, max_slip)


@dataclass
class RouteHop:
    provider: str
    pool_address: str | None
    from_token: str
    to_token: str
    fee_bps: int = 0
    share: Any = 1


@dataclass
class SwapQuote:
    provider: str
    from_token: str
    to_token: str
    from_amount: Any            # human units
    to_amount: Any              # human units
    min_received: Any
    rate: Any                   # to_amount / from_amount
    price_impact: Any           # 0.01 = 1%
    network_fee_ton: Any = 0
    route: list[RouteHop] = field(default_factory=list)
    slippage: Any = 0.01
    expires_at: datetime | None = None
    quote_id: str | None = None
    estimate_only: bool = False   # True when derived locally, not from the provider
    notes: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.expires_at is None:
            ttl = get_settings().quote_ttl_seconds
            self.expires_at = datetime.now(UTC).replace(tzinfo=None) + timedelta(seconds=ttl)

    @property
    def is_expired(self) -> bool:
        return self.expires_at is not None and self.expires_at < datetime.now(UTC).replace(
            tzinfo=None
        )

    @property
    def from_amount_nano(self) -> int:
        return nano_from_ton(self.from_amount) if self.from_token in NATIVE_ALIASES else 0


NATIVE_ALIASES = {"TON", "native", "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"}


@dataclass
class UnsignedSwap:
    """Transaction the wallet must approve. Payload is only present when the
    official SDK/endpoint provided it - never hand-rolled."""

    provider: str
    to_address: str
    amount_nano: int
    payload_boc: str | None = None
    state_init: str | None = None
    valid_until: int | None = None
    requires_client_sdk: bool = False
    sdk_hint: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class DexCapabilities:
    quote: bool = True
    route: bool = True
    pools: bool = True
    tokens: bool = True
    build_transaction: bool = False


class DexAdapter(ABC):
    name = "abstract"
    docs_url: str | None = None
    status: str = "unknown"
    status_note: str | None = None

    def capabilities(self) -> DexCapabilities:
        return DexCapabilities()

    def _require(self, capability: str) -> None:
        if not getattr(self.capabilities(), capability, False):
            raise CapabilityNotSupported(
                f"{self.name} cannot '{capability}' through its public API "
                f"(docs: {self.docs_url})",
                provider=self.name,
                capability=capability,
            )

    @abstractmethod
    async def get_supported_tokens(self, search: str | None = None) -> list[TokenInfo]: ...

    @abstractmethod
    async def get_pool_data(self, token0: str, token1: str) -> list[PoolInfo]: ...

    @abstractmethod
    async def get_quote(self, request: SwapQuoteRequest) -> SwapQuote: ...

    @abstractmethod
    async def get_swap_route(self, request: SwapQuoteRequest) -> list[RouteHop]: ...

    @abstractmethod
    async def prepare_swap_transaction(
        self, quote: SwapQuote, wallet_address: str
    ) -> UnsignedSwap: ...

    @abstractmethod
    async def get_token_decimals(self, address: str) -> int: ...

    def describe(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "status_note": self.status_note,
            "docs_url": self.docs_url,
            "capabilities": self.capabilities().__dict__,
        }
