"""STON.fi adapter (https://docs.ston.fi) - DEX API v1.

Verified endpoints (https://docs.ston.fi/developer-section/dex/api/reference):

    GET  /v1/assets                          - asset list (decimals, symbol)
    GET  /v1/assets/{address}                - single asset
    GET  /v1/pools                           - pool list
    GET  /v1/pools/by_market/{asset0}/{asset1}
    POST /v1/swap/simulate                   - swap simulation (query params)

``POST /v1/swap/simulate`` returns the *simulated amounts*, not a signed
transaction. Building the swap message body requires the official
``@ston-fi/sdk`` (or the Omniston SDK); the adapter therefore returns an
:class:`UnsignedSwap` flagged ``requires_client_sdk`` with every parameter the
SDK needs, and never fabricates a BOC.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any

from app.core.cache import cached
from app.core.constants import STONFI_NATIVE_TON
from app.core.errors import CapabilityNotSupported, ProviderError
from app.core.http import HttpClient
from app.core.logging import get_logger
from app.core.money import d, safe_div
from app.integrations.dex.base import (
    DexAdapter,
    DexCapabilities,
    PoolInfo,
    RouteHop,
    SwapQuote,
    SwapQuoteRequest,
    TokenInfo,
    UnsignedSwap,
)

logger = get_logger(__name__)

NANO = Decimal(1_000_000_000)


class StonFiAdapter(DexAdapter):
    name = "stonfi"
    docs_url = "https://docs.ston.fi/developer-section/dex/api/reference"
    status = "live-quotes"
    status_note = (
        "Live quotes via POST /v1/swap/simulate. Swap messages must be built with "
        "the official @ston-fi/sdk (or Omniston SDK) in the client; no payload "
        "is fabricated server-side."
    )

    def __init__(self) -> None:
        self.http = HttpClient("https://api.ston.fi/v1", limiter_name="stonfi")
        self._decimals_cache: dict[str, int] = {}

    def capabilities(self) -> DexCapabilities:
        return DexCapabilities(quote=True, route=True, pools=True, tokens=True, build_transaction=False)

    # ------------------------------------------------------------- helpers
    async def _get(self, path: str, *, ttl: int = 300, params: dict | None = None) -> Any:
        key = f"stonfi:{path}:{params}"

        async def call() -> Any:
            return await self.http.get(path, params=params)

        return await cached(key, ttl, call)

    async def get_token_decimals(self, address: str) -> int:
        if address == STONFI_NATIVE_TON or address.upper() == "TON":
            return 9
        if address in self._decimals_cache:
            return self._decimals_cache[address]
        data = await self._get(f"/assets/{address}", ttl=3600)
        asset = data.get("asset") if isinstance(data, dict) else None
        decimals = int((asset or {}).get("decimals") or 9)
        self._decimals_cache[address] = decimals
        return decimals

    async def get_supported_tokens(self, search: str | None = None) -> list[TokenInfo]:
        data = await self._get("/assets", ttl=1800, params={"search_term": search} if search else None)
        assets = data.get("asset_list", []) if isinstance(data, dict) else []
        tokens: list[TokenInfo] = []
        for asset in assets:
            tokens.append(
                TokenInfo(
                    address=str(asset.get("contract_address")),
                    symbol=str(asset.get("symbol") or ""),
                    name=str(asset.get("display_name") or asset.get("symbol") or ""),
                    decimals=int(asset.get("decimals") or 9),
                    kind="native" if asset.get("kind") == "Ton" else "jetton",
                    image_url=asset.get("image_url"),
                    verified=bool(asset.get("default_symbol")),
                )
            )
        return tokens

    async def get_pool_data(self, token0: str, token1: str) -> list[PoolInfo]:
        data = await self._get(f"/pools/by_market/{token0}/{token1}", ttl=120)
        pools = data.get("pool_list", []) if isinstance(data, dict) else []
        result: list[PoolInfo] = []
        for pool in pools:
            result.append(
                PoolInfo(
                    address=str(pool.get("address")),
                    token0=str(pool.get("token0_address") or token0),
                    token1=str(pool.get("token1_address") or token1),
                    reserve0=int(pool.get("reserve0") or 0),
                    reserve1=int(pool.get("reserve1") or 0),
                    fee_bps=int(float(pool.get("lp_fee") or pool.get("lp_fee_bps") or 0) * 100)
                    if pool.get("lp_fee") is not None
                    else 30,
                    last_price=pool.get("last_price"),
                    provider=self.name,
                    raw=pool,
                )
            )
        return result

    # --------------------------------------------------------------- quotes
    async def get_quote(self, request: SwapQuoteRequest) -> SwapQuote:
        from_decimals = await self.get_token_decimals(request.from_token)
        to_decimals = await self.get_token_decimals(request.to_token)
        units = int((d(request.amount) * (Decimal(10) ** from_decimals)).to_integral_value())

        params: dict[str, Any] = {
            "offer_address": request.from_token,
            "ask_address": request.to_token,
            "units": str(units),
            "slippage_tolerance": float(request.slippage_value),
            "dex_v2": "true",
        }
        if request.referral_address:
            params["referral_address"] = request.referral_address

        data = await self.http.post("/swap/simulate", params=params)
        if not isinstance(data, dict):
            raise ProviderError("unexpected response from STON.fi swap/simulate")

        to_raw = Decimal(str(data.get("ask_units") or 0))
        to_amount = to_raw / (Decimal(10) ** to_decimals)
        min_received = Decimal(str(data.get("min_ask_units") or 0)) / (Decimal(10) ** to_decimals)
        from_amount = Decimal(str(data.get("offer_units") or units)) / (Decimal(10) ** from_decimals)
        gas = data.get("gas_params") or {}
        network_fee = (
            Decimal(str(gas.get("estimated_gas_consumption") or 0)) / NANO
        ).quantize(Decimal("0.000000001"))

        fee_percent = d(data.get("fee_percent"))
        route = [
            RouteHop(
                provider=self.name,
                pool_address=data.get("pool_address"),
                from_token=request.from_token,
                to_token=request.to_token,
                fee_bps=int((fee_percent * 10000).to_integral_value()),
            )
        ]

        return SwapQuote(
            provider=self.name,
            from_token=request.from_token,
            to_token=request.to_token,
            from_amount=from_amount,
            to_amount=to_amount,
            min_received=min_received,
            rate=safe_div(to_amount, from_amount),
            price_impact=d(data.get("price_impact")),
            network_fee_ton=network_fee,
            route=route,
            slippage=request.slippage_value,
            notes=(
                "Quote from STON.fi DEX API v1 (/swap/simulate). "
                "Execution requires the official SDK in the client wallet flow."
            ),
            raw=data,
        )

    async def get_swap_route(self, request: SwapQuoteRequest) -> list[RouteHop]:
        quote = await self.get_quote(request)
        return quote.route

    async def prepare_swap_transaction(
        self, quote: SwapQuote, wallet_address: str
    ) -> UnsignedSwap:
        self._require("build_transaction")
        raise CapabilityNotSupported(  # pragma: no cover - explicit guard
            "STON.fi REST API returns simulations only. Build the swap message "
            "with @ston-fi/sdk (v2 router) or the Omniston SDK using the "
            "parameters returned here.",
            provider=self.name,
        )

    def build_sdk_params(self, quote: SwapQuote, wallet_address: str) -> dict[str, Any]:
        """Everything the official SDK needs to build the swap message."""
        raw = quote.raw or {}
        return {
            "sdk": "@ston-fi/sdk",
            "dex_v2": True,
            "router_address": raw.get("router_address"),
            "pool_address": raw.get("pool_address"),
            "offer_address": quote.from_token,
            "ask_address": quote.to_token,
            "offer_units": raw.get("offer_units"),
            "min_ask_units": raw.get("min_ask_units"),
            "forward_gas": (raw.get("gas_params") or {}).get("forward_gas"),
            "user_wallet_address": wallet_address,
        }
