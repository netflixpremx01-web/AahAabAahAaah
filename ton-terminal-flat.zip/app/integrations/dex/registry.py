"""Registry of DEX adapters."""
from __future__ import annotations

from app.integrations.dex.base import DexAdapter
from app.integrations.dex.dedust import DeDustAdapter
from app.integrations.dex.stonfi import StonFiAdapter

_ADAPTERS: dict[str, DexAdapter] | None = None


def build_adapters() -> dict[str, DexAdapter]:
    return {"stonfi": StonFiAdapter(), "dedust": DeDustAdapter()}


def get_adapters() -> dict[str, DexAdapter]:
    global _ADAPTERS
    if _ADAPTERS is None:
        _ADAPTERS = build_adapters()
    return _ADAPTERS


def get_adapter(name: str) -> DexAdapter:
    adapters = get_adapters()
    if name not in adapters:
        raise KeyError(f"unknown dex adapter: {name}")
    return adapters[name]


def describe_all() -> list[dict]:
    return [adapter.describe() for adapter in get_adapters().values()]
