"""DeDust adapter (https://docs.dedust.io).

Verified endpoints:

    GET /v2/pools                       - all pools (assets, reserves, tradeFee)
    GET /v2/pools/{address}/trades      - latest trades for a pool

DeDust publishes **no REST quote endpoint**: swaps are executed through the
official SDK (https://docs.dedust.io/docs/swaps). This adapter therefore:

* serves pool/token data straight from the documented REST API;
* computes an *indicative* quote from public pool reserves using the
  constant-product formula documented in DeDust concepts, clearly flagged with
  ``estimate_only=True``;
* refuses to fabricate a swap payload (``build_transaction`` capability off).
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any

from app.core.cache import cached
from app.core.errors import CapabilityNotSupported
from app.core.http import HttpClient
from app.core.logging import get_logger
from app.core.money import d
from app.integrations.dex.base import (
    DexAdapter,
    DexCapabilities,
    PoolInfo,
    RouteHop,
    SwapQuote,
    SwapQuoteRequest,
    TokenInfo,
    UnsignedSwap,
)
from app.integrations.toncenter.client import TonCenterClient

logger = get_logger(__name__)

NATIVE = "native"


class DeDustAdapter(DexAdapter):
    name = "dedust"
    docs_url = "https://docs.dedust.io/reference/getting-available-pools"
    status = "pool-data"
    status_note = (
        "Pool data from the documented REST API. Quotes are computed locally "
        "from public reserves (constant product) and are clearly marked as "
        "estimates; swaps execute through the official DeDust SDK."
    )

    def __init__(self) -> None:
        self.http = HttpClient("https://api.dedust.io/v2", limiter_name="dedust")
        self.toncenter = TonCenterClient()
        self._decimals: dict[str, int] = {}

    def capabilities(self) -> DexCapabilities:
        return DexCapabilities(quote=True, route=True, pools=True, tokens=True, build_transaction=False)

    # ----------------------------------------------------------- pool data
    async def _pools(self) -> list[dict[str, Any]]:
        async def call() -> list[dict[str, Any]]:
            data = await self.http.get("/pools")
            return data if isinstance(data, list) else []

        # The full pool list is large (~25 MB); cache it aggressively.
        return await cached("dedust:pools", 900, call)

    async def get_pool_data(self, token0: str, token1: str) -> list[PoolInfo]:
        for token in (token0, token1):
            if not (token == NATIVE or len(token) > 40):
                # Avoid downloading the (large) full pool list for a symbol the
                # API cannot resolve: DeDust identifies assets by address.
                raise CapabilityNotSupported(
                    f"DeDust requires asset addresses, got '{token}'", provider=self.name
                )
        pools = await self._pools()
        matched: list[PoolInfo] = []
        for pool in pools:
            assets = pool.get("assets") or []
            if len(assets) != 2:
                continue
            addresses = []
            for asset in assets:
                addresses.append(NATIVE if asset.get("type") == NATIVE else asset.get("address"))
            if {token0, token1} != set(addresses):
                continue
            reserves = [int(x) for x in pool.get("reserves") or [0, 0]]
            trade_fee = d(pool.get("tradeFee") or 0)  # DeDust reports fee in percent
            matched.append(
                PoolInfo(
                    address=str(pool.get("address")),
                    token0=str(addresses[0]),
                    token1=str(addresses[1]),
                    reserve0=reserves[0],
                    reserve1=reserves[1],
                    fee_bps=int((trade_fee * 100).to_integral_value()),
                    last_price=d(pool.get("lastPrice")) if pool.get("lastPrice") else None,
                    provider=self.name,
                    raw=pool,
                )
            )
        return matched

    async def get_supported_tokens(self, search: str | None = None) -> list[TokenInfo]:
        pools = await self._pools()
        seen: dict[str, TokenInfo] = {}
        for pool in pools:
            for asset in pool.get("assets") or []:
                address = NATIVE if asset.get("type") == NATIVE else asset.get("address")
                if not address or address in seen:
                    continue
                meta = asset.get("metadata") or {}
                symbol = str(meta.get("symbol") or "")
                token = TokenInfo(
                    address=str(address),
                    symbol=symbol or (address[:8] if address != NATIVE else "TON"),
                    name=str(meta.get("name") or symbol or ""),
                    decimals=int(meta.get("decimals") or 9),
                    kind="native" if asset.get("type") == NATIVE else "jetton",
                    image_url=meta.get("image"),
                )
                seen[str(address)] = token
        tokens = list(seen.values())
        if search:
            needle = search.lower()
            tokens = [t for t in tokens if needle in t.symbol.lower() or needle in t.name.lower()]
        return tokens

    async def get_token_decimals(self, address: str) -> int:
        if address == NATIVE:
            return 9
        if address in self._decimals:
            return self._decimals[address]
        masters = await self.toncenter.get_jetton_masters(address)
        decimals = 9
        if masters:
            decimals = int((masters[0].get("jetton_content") or {}).get("decimals") or 9)
        self._decimals[address] = decimals
        return decimals

    # -------------------------------------------------------------- quotes
    async def get_quote(self, request: SwapQuoteRequest) -> SwapQuote:
        pools = await self.get_pool_data(request.from_token, request.to_token)
        if not pools:
            raise CapabilityNotSupported(
                "No DeDust pool exists for this pair", provider=self.name
            )
        pool = max(pools, key=lambda p: p.reserve0 + p.reserve1)
        from_decimals = await self.get_token_decimals(request.from_token)
        to_decimals = await self.get_token_decimals(request.to_token)

        amount_in_raw = d(request.amount) * (Decimal(10) ** from_decimals)
        reserve_in = Decimal(pool.reserve0 if pool.token0 == request.from_token else pool.reserve1)
        reserve_out = Decimal(pool.reserve1 if pool.token0 == request.from_token else pool.reserve0)
        if reserve_in <= 0 or reserve_out <= 0:
            raise CapabilityNotSupported("Pool has no liquidity", provider=self.name)

        fee_bps = Decimal(pool.fee_bps)
        amount_in_after_fee = amount_in_raw * (Decimal(10_000) - fee_bps) / Decimal(10_000)
        amount_out_raw = (amount_in_after_fee * reserve_out) / (reserve_in + amount_in_after_fee)
        to_amount = amount_out_raw / (Decimal(10) ** to_decimals)
        min_received = to_amount * (Decimal(1) - d(request.slippage_value))

        spot = reserve_out / reserve_in
        effective = amount_out_raw / amount_in_raw
        price_impact = ((spot - effective) / spot) if spot else Decimal(0)

        return SwapQuote(
            provider=self.name,
            from_token=request.from_token,
            to_token=request.to_token,
            from_amount=d(request.amount),
            to_amount=to_amount,
            min_received=min_received,
            rate=effective,
            price_impact=price_impact,
            network_fee_ton=d(0),  # DeDust does not publish gas estimates over REST
            route=[
                RouteHop(
                    provider=self.name,
                    pool_address=pool.address,
                    from_token=request.from_token,
                    to_token=request.to_token,
                    fee_bps=pool.fee_bps,
                )
            ],
            slippage=request.slippage_value,
            estimate_only=True,
            notes=(
                "Indicative quote computed locally from public DeDust pool "
                "reserves (constant product). Not an executable provider quote."
            ),
            raw={"pool": pool.address, "reserves": [pool.reserve0, pool.reserve1]},
        )

    async def get_swap_route(self, request: SwapQuoteRequest) -> list[RouteHop]:
        quote = await self.get_quote(request)
        return quote.route

    async def prepare_swap_transaction(
        self, quote: SwapQuote, wallet_address: str
    ) -> UnsignedSwap:
        self._require("build_transaction")
        raise CapabilityNotSupported(  # pragma: no cover
            "DeDust swaps are executed through the official @dedust/sdk; "
            "the REST API exposes pool data only.",
            provider=self.name,
        )

    async def get_pool_trades(self, pool_address: str) -> list[dict[str, Any]]:
        data = await self.http.get(f"/pools/{pool_address}/trades")
        return data if isinstance(data, list) else []
