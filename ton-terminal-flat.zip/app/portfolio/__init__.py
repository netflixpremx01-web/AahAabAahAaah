"""Portfolio domain.

The implementation lives in :mod:`app.services.portfolio` (holdings, balances,
realised vs unrealised P/L); this package is kept for domain-specific helpers.
"""
from __future__ import annotations

from decimal import Decimal

from app.core.money import d, quantize_ton


def net_pnl(realized: Decimal | str | None, unrealized: Decimal | str | None) -> Decimal:
    """Total P/L = realised (confirmed sales) + unrealised (mark-to-floor)."""
    return quantize_ton(d(realized) + d(unrealized))


def split_pnl(realized: Decimal | str | None, unrealized: Decimal | str | None) -> dict[str, str]:
    """Return realised and unrealised P/L separately - never mixed."""
    return {
        "realized_pnl_ton": str(quantize_ton(d(realized))),
        "unrealized_pnl_ton": str(quantize_ton(d(unrealized))),
        "total_pnl_ton": str(net_pnl(realized, unrealized)),
    }


def mark_to_market(entry: Decimal | str | None, floor: Decimal | str | None) -> Decimal | None:
    """Unrealised P/L for one position (floor - entry), or None without data."""
    if entry is None or floor is None:
        return None
    return quantize_ton(d(floor) - d(entry))
