"""Callback query handlers for inline buttons."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.bot import formatting as fmt
from app.bot.emojis import render
from app.bot.keyboards import main_menu, notification_toggles
from app.core.logging import get_logger
from app.database.session import session_scope
from app.models.enums import NotificationCategory
from app.services import wallets as wallet_service
from app.services.market import MarketService
from app.services.opportunities import OpportunityService
from app.services.paper import PaperTradingService
from app.services.portfolio import PortfolioService
from app.services.trading import TradingService
from app.services.users import update_notification_prefs
from app.services.watchlist import WatchlistService

logger = get_logger(__name__)
router = Router(name="callbacks")


async def edit(callback: CallbackQuery, text: str, **kwargs) -> None:
    rendered = render(text)
    await callback.message.edit_text(
        rendered.text,
        entities=rendered.entities or None,
        parse_mode="HTML",
        disable_web_page_preview=True,
        **kwargs,
    )


@router.callback_query(F.data.startswith("menu:"))
async def on_menu(callback: CallbackQuery) -> None:
    section = callback.data.split(":", 1)[1]
    async with session_scope() as session:
        if section == "radar":
            service = OpportunityService(session)
            rows = await service.list_opportunities(min_score=40, limit=3)
            if not rows:
                await edit(callback, "{radar} No opportunities right now. Try <code>/scan &lt;collection&gt;</code>.")
            else:
                lines = ["{radar} <b>TOP OPPORTUNITIES</b>\n"]
                for row in rows:
                    lines.append(
                        f"\n· score <b>{row.opportunity_score}</b> · "
                        f"{row.listed_price_ton} TON · risk {row.risk_level}"
                    )
                await edit(callback, "\n".join(lines), reply_markup=main_menu())
            return

        if section == "portfolio":
            from app.services.users import get_user_by_telegram_id

            user = await get_user_by_telegram_id(session, callback.from_user.id)
            if user is None:
                await edit(callback, "{error} Send /start first.")
                return
            wallet = await wallet_service.get_primary_wallet(session, user.id)
            summary = await PortfolioService(session).summary(user.id, wallet)
            await edit(callback, fmt.portfolio_card(summary), reply_markup=main_menu())
            return

        if section == "market":
            collections = await MarketService(session).top_collections(limit=5)
            lines = ["{market} <b>MARKET</b>\n"]
            for collection in collections:
                lines.append(
                    f"\n· {collection.name or collection.address[:12]}\n"
                    f"  floor {collection.floor_price_ton or '—'} TON · "
                    f"health {collection.health_score or '—'}/100 · {collection.trend or '—'}"
                )
            if len(lines) == 1:
                lines.append("\nNo collections indexed yet. Use <code>/scan &lt;collection&gt;</code>.")
            await edit(callback, "\n".join(lines), reply_markup=main_menu())
            return

        if section == "settings":
            from app.core.config import get_settings

            settings = get_settings()
            from app.services.users import get_user_by_telegram_id

            user = await get_user_by_telegram_id(session, callback.from_user.id)
            if user:
                await edit(
                    callback,
                    fmt.settings_card(user, settings.ton_network, settings.enable_real_trading),
                    reply_markup=notification_toggles(
                        user.notification_prefs or {}, [c.value for c in NotificationCategory]
                    ),
                )
            return
    await edit(callback, "{error} Unknown section.")


@router.callback_query(F.data.startswith("notify:"))
async def on_notify_toggle(callback: CallbackQuery) -> None:
    category = callback.data.split(":", 1)[1]
    async with session_scope() as session:
        from app.services.users import get_user_by_telegram_id

        user = await get_user_by_telegram_id(session, callback.from_user.id)
        if user is None:
            await callback.answer("Send /start first")
            return
        prefs = dict(user.notification_prefs or {})
        prefs[category] = not prefs.get(category, True)
        await update_notification_prefs(session, user, prefs)
    from app.core.config import get_settings

    settings = get_settings()
    await edit(
        callback,
        fmt.settings_card(user, settings.ton_network, settings.enable_real_trading),
        reply_markup=notification_toggles(prefs, [c.value for c in NotificationCategory]),
    )
    await callback.answer(f"{category}: {'on' if prefs[category] else 'off'}")


@router.callback_query(F.data.startswith("buy:"))
async def on_buy(callback: CallbackQuery) -> None:
    opportunity_id = int(callback.data.split(":", 1)[1])
    async with session_scope() as session:
        from app.models.orm import NFT

        service = OpportunityService(session)
        opportunity = await service.get_opportunity(opportunity_id)
        nft = await session.get(NFT, opportunity.nft_id) if opportunity else None
        payload = (
            await TradingService(session).prepare_buy(nft_address=nft.address) if nft else None
        )
    if payload is None:
        await edit(callback, "{error} Opportunity no longer available.")
        return
    await edit(callback, fmt.buy_confirmation(payload))


@router.callback_query(F.data.startswith("paper:"))
async def on_paper_buy(callback: CallbackQuery) -> None:
    opportunity_id = int(callback.data.split(":", 1)[1])
    async with session_scope() as session:
        from app.services.users import get_user_by_telegram_id

        user = await get_user_by_telegram_id(session, callback.from_user.id)
        if user is None:
            await callback.answer("Send /start first")
            return
        from app.models.orm import NFT

        service = OpportunityService(session)
        opportunity = await service.get_opportunity(opportunity_id)
        nft = await session.get(NFT, opportunity.nft_id) if opportunity else None
        try:
            trade = await PaperTradingService(session).open_position(
                user_id=user.id,
                entry_price=opportunity.listed_price_ton,
                nft_address=nft.address if nft else None,
                notes="opened from radar",
            )
        except Exception as exc:  # noqa: BLE001
            await edit(callback, f"{{error}} {exc}")
            return
    await edit(callback, f"{{paper}} Simulated buy opened at <b>{trade.entry_price_ton}</b> TON.\n\nNo real funds involved.")


@router.callback_query(F.data.startswith("watch:nft:"))
async def on_watch(callback: CallbackQuery) -> None:
    address = callback.data.split(":", 2)[2]
    async with session_scope() as session:
        from app.services.users import get_user_by_telegram_id

        user = await get_user_by_telegram_id(session, callback.from_user.id)
        if user is None:
            await callback.answer("Send /start first")
            return
        await WatchlistService(session).add(
            user_id=user.id, target_type="nft", target_ref=address, condition="price_below"
        )
    await callback.answer("Added to watchlist")
    await edit(callback, f"{{watchlist}} Watching <code>{address[:16]}…</code>\n\nSet an alert threshold in the Mini App.")


@router.callback_query(F.data.startswith("analyze:"))
async def on_analyze(callback: CallbackQuery) -> None:
    address = callback.data.split(":", 1)[1]
    async with session_scope() as session:
        analysis = await OpportunityService(session).analyze_nft(address)
    if analysis is None:
        await edit(callback, "{error} NFT not found.")
        return
    await edit(callback, fmt.analysis_card(analysis.as_dict()))


@router.callback_query(F.data == "cancel")
async def on_cancel(callback: CallbackQuery) -> None:
    await callback.message.delete()
