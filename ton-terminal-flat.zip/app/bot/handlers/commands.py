"""Telegram bot commands.

Every handler is thin: it resolves the user, calls a service and renders a
message. No business logic lives here.
"""
from __future__ import annotations

from aiogram import Router
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

from app.bot import formatting as fmt
from app.bot.emojis import render
from app.bot.keyboards import main_menu, notification_toggles, radar_actions
from app.core.config import get_settings
from app.database.session import session_scope
from app.models.enums import NotificationCategory
from app.services import wallets as wallet_service
from app.services.market import MarketService
from app.services.opportunities import OpportunityService
from app.services.paper import PaperTradingService
from app.services.portfolio import PortfolioService
from app.services.strategies import StrategyService
from app.services.swaps import SwapService
from app.services.trading import TradingService
from app.services.users import get_or_create_user
from app.services.watchlist import WatchlistService

router = Router(name="commands")


async def reply(message: Message, text: str, **kwargs) -> None:
    """Send a message with premium custom emoji entities resolved."""
    rendered = render(text)
    await message.answer(
        rendered.text,
        entities=rendered.entities or None,
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True,
        **kwargs,
    )


def _user_from(message: Message) -> dict:
    user = message.from_user
    return {
        "telegram_id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "language_code": user.language_code,
        "is_premium": bool(getattr(user, "is_premium", False)),
    }


# --------------------------------------------------------------------- basics
@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    async with session_scope() as session:
        await get_or_create_user(session, **_user_from(message))
    await reply(message, fmt.welcome(message.from_user.first_name or "trader"), reply_markup=main_menu())


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    await reply(message, fmt.help_text(), reply_markup=main_menu())


# --------------------------------------------------------------------- wallet
@router.message(Command("wallet"))
async def cmd_wallet(message: Message) -> None:
    async with session_scope() as session:
        user = await get_or_create_user(session, **_user_from(message))
        wallet = await wallet_service.get_primary_wallet(session, user.id)
        balances = await wallet_service.sync_balances(session, wallet) if wallet else None
    text = fmt.wallet_card(balances, wallet.address if wallet else None)
    await reply(message, text, reply_markup=main_menu())


# ---------------------------------------------------------------------- radar
@router.message(Command("radar"))
async def cmd_radar(message: Message) -> None:
    async with session_scope() as session:
        await get_or_create_user(session, **_user_from(message))
        service = OpportunityService(session)
        rows = await service.list_opportunities(min_score=50, limit=5)
        payloads = [
            {
                "id": row.id,
                "name": None,
                "listed_price_ton": row.listed_price_ton,
                "fair_value_low": row.fair_value_low,
                "fair_value_high": row.fair_value_high,
                "discount_pct": row.discount_pct,
                "rarity_score": row.rarity_score,
                "number_score": row.number_score,
                "liquidity_score": row.liquidity_score,
                "estimated_costs_ton": row.estimated_costs_ton,
                "theoretical_profit_ton": row.theoretical_profit_ton,
                "risk_level": row.risk_level,
                "confidence": row.confidence,
                "opportunity_score": row.opportunity_score,
            }
            for row in rows
        ]
    if not payloads:
        await reply(
            message,
            "{radar} <b>NFT RADAR</b>\n\nNo opportunities above the threshold right now.\n"
            "Scan a collection with <code>/scan &lt;collection&gt;</code>.",
        )
        return
    for row in payloads:

        async with session_scope() as session:
            from app.models.orm import NFT

            opportunity = await OpportunityService(session).get_opportunity(row["id"])
            nft = await session.get(NFT, opportunity.nft_id) if opportunity else None
            row["name"] = nft.name if nft else "NFT"
            address = nft.address if nft else None
        await reply(message, fmt.radar_card(row), reply_markup=radar_actions(row["id"], address))


@router.message(Command("scan"))
async def cmd_scan(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await reply(message, "Usage: <code>/scan &lt;collection_address&gt;</code>")
        return
    collection = parts[1].strip()
    status = await reply(message, f"{{radar}} Scanning <code>{collection}</code>…")
    async with session_scope() as session:
        await get_or_create_user(session, **_user_from(message))
        service = OpportunityService(session)
        try:
            opportunities = await service.scan_collection(collection, min_score=40, limit=15)
        except Exception as exc:  # noqa: BLE001 - surfaced to the user
            await reply(message, f"{{error}} Scan failed: {exc}")
            return
        market = MarketService(session)
        health = await market.health(collection)
    _ = status
    if not opportunities:
        await reply(
            message,
            "{radar} Scan complete — no opportunities above the threshold.\n\n"
            + fmt.collection_card({"address": collection}, health.as_dict()),
        )
        return
    await reply(
        message,
        f"{{success}} Scan complete — {len(opportunities)} candidates.\n\n"
        + fmt.collection_card({"address": collection}, health.as_dict()),
    )


@router.message(Command("analyze"))
async def cmd_analyze(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await reply(message, "Usage: <code>/analyze &lt;nft_address_or_url&gt;</code>")
        return
    reference = parts[1].strip().split("/")[-1]
    async with session_scope() as session:
        await get_or_create_user(session, **_user_from(message))
        service = OpportunityService(session)
        try:
            analysis = await service.analyze_nft(reference)
        except Exception as exc:  # noqa: BLE001
            await reply(message, f"{{error}} Analysis failed: {exc}")
            return
    if analysis is None:
        await reply(message, "{error} NFT not found or no collection linked to it.")
        return
    await reply(message, fmt.analysis_card(analysis.as_dict()))


# -------------------------------------------------------------------- trading
@router.message(Command("buy"))
async def cmd_buy(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await reply(message, "Usage: <code>/buy &lt;nft_address&gt;</code>")
        return
    nft_address = parts[1].strip().split("/")[-1]
    async with session_scope() as session:
        await get_or_create_user(session, **_user_from(message))
        service = TradingService(session)
        payload = await service.prepare_buy(nft_address=nft_address)
    await reply(message, fmt.buy_confirmation(payload))


@router.message(Command("sell"))
async def cmd_sell(message: Message) -> None:
    parts = (message.text or "").split()
    if len(parts) < 3:
        await reply(message, "Usage: <code>/sell &lt;nft_address&gt; &lt;price_ton&gt;</code>")
        return
    nft_address, price = parts[1].strip().split("/")[-1], parts[2]
    async with session_scope() as session:
        await get_or_create_user(session, **_user_from(message))
        service = TradingService(session)
        payload = await service.prepare_sell(nft_address=nft_address, price_ton=price)
    floor = payload.get("floor_ton")
    suggested = payload.get("suggested_range") or {}
    text = (
        f"{{sell}} <b>SELL PREVIEW</b>\n\n"
        f"{{nft}} {payload['nft'].get('name') or nft_address}\n"
        f"{{market}} Floor: {floor or '—'} TON\n"
        f"{{analytics}} Suggested range: {suggested.get('low') or '—'}–{suggested.get('high') or '—'} TON\n"
        f"{{ton}} Your price: {payload['price_ton']} TON\n"
        f"{{gas}} Fees: {payload['marketplace_fee_ton']} + royalty {payload['royalty_ton']} TON\n"
        f"{{wallet}} Expected proceeds: <b>{payload['expected_proceeds_ton']} TON</b>"
    )
    if not payload.get("available"):
        text += f"\n\n{{warning}} <b>Listing unavailable</b>\n{payload.get('unavailable_reason', '')}"
    await reply(message, text)


@router.message(Command("swap"))
async def cmd_swap(message: Message) -> None:
    """Usage: /swap 50 TON USDT"""
    parts = (message.text or "").split()
    if len(parts) < 4:
        await reply(message, "Usage: <code>/swap &lt;amount&gt; &lt;FROM&gt; &lt;TO&gt;</code>")
        return
    amount, from_token, to_token = parts[1], parts[2].upper(), parts[3].upper()
    async with session_scope() as session:
        user = await get_or_create_user(session, **_user_from(message))
        service = SwapService(session)
        try:
            quote = await service.quote(
                user=user, from_token=from_token, to_token=to_token, amount=amount
            )
        except Exception as exc:  # noqa: BLE001
            await reply(message, f"{{error}} Quote failed: {exc}")
            return
        card = fmt.swap_quote_card(
            {
                "from_amount": str(quote.from_amount),
                "to_amount": str(quote.to_amount),
                "rate": str(quote.rate),
                "price_impact": str(quote.price_impact),
                "network_fee_ton": quote.network_fee_ton,
                "min_received": str(quote.min_received),
                "expires_at": quote.expires_at.isoformat(),
                "provider": quote.provider,
            }
        )
    await reply(message, card)


# ------------------------------------------------------------------ portfolio
@router.message(Command("portfolio"))
async def cmd_portfolio(message: Message) -> None:
    async with session_scope() as session:
        user = await get_or_create_user(session, **_user_from(message))
        wallet = await wallet_service.get_primary_wallet(session, user.id)
        service = PortfolioService(session)
        summary = await service.summary(user.id, wallet)
    await reply(message, fmt.portfolio_card(summary))


@router.message(Command("history"))
async def cmd_history(message: Message) -> None:
    async with session_scope() as session:
        user = await get_or_create_user(session, **_user_from(message))
        wallet = await wallet_service.get_primary_wallet(session, user.id)
        service = PortfolioService(session)
        history = await service.history(user.id, wallet, limit=5)
        trades = await TradingService(session).list_transactions(user.id, limit=5)
    purchases = history.get("purchases") or []
    sales = history.get("sales") or []
    lines = ["{history} <b>HISTORY</b>\n"]
    lines.append(f"\n{{buy}} Recent purchases: {len(purchases)}")
    for purchase in purchases[:5]:
        lines.append(f"  · {purchase['price_ton']} TON — {purchase['nft'][:10]}…")
    lines.append(f"\n{{sell}} Recent sales: {len(sales)}")
    for sale in sales[:5]:
        lines.append(f"  · {sale['price_ton']} TON — {sale['nft'][:10]}…")
    lines.append(f"\n{{transaction}} Recorded transactions: {len(trades)}")
    await reply(message, "\n".join(lines))


# ------------------------------------------------------------- watch & strategy
@router.message(Command("watchlist"))
async def cmd_watchlist(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    async with session_scope() as session:
        user = await get_or_create_user(session, **_user_from(message))
        service = WatchlistService(session)
        if len(parts) >= 2:
            target = parts[1].strip()
            kind = "collection" if len(target) > 48 else "nft"
            await service.add(
                user_id=user.id,
                target_type=kind,
                target_ref=target,
                condition="price_below" if kind == "nft" else "floor_below",
                threshold=None,
                label=target[:40],
            )
        rows = await service.list(user.id)
    if not rows:
        await reply(message, "{watchlist} Your watchlist is empty. Add one: <code>/watchlist &lt;address&gt;</code>")
        return
    lines = ["{watchlist} <b>WATCHLIST</b>\n"]
    for row in rows:
        threshold = str(row.threshold) if row.threshold is not None else "—"
        lines.append(f"\n· {row.target_type}: <code>{row.target_ref[:16]}…</code>\n  {row.condition} {threshold}")
    await reply(message, "\n".join(lines))


@router.message(Command("strategy"))
async def cmd_strategy(message: Message) -> None:
    async with session_scope() as session:
        user = await get_or_create_user(session, **_user_from(message))
        service = StrategyService(session)
        rows = await service.list(user.id)
        paper = await PaperTradingService(session).stats(user.id)
    lines = ["{strategy} <b>STRATEGIES</b>\n"]
    for row in rows:
        rules = row.rules or {}
        lines.append(
            f"\n· <b>{row.name}</b> ({row.mode}, {'active' if row.is_active else 'paused'})\n"
            f"  ROI &gt; {rules.get('min_roi_pct')}% · rarity &gt; {rules.get('min_rarity')} · "
            f"liquidity &gt; {rules.get('min_liquidity')} · price &lt; {rules.get('max_buy_price_ton')} TON"
        )
    if len(lines) == 1:
        lines.append("\nNo strategies yet — create one in the Mini App (Strategies → New).")
    lines.append("\n\n" + fmt.paper_card(paper))
    await reply(message, "\n".join(lines))


# -------------------------------------------------------------------- settings
@router.message(Command("settings"))
async def cmd_settings(message: Message) -> None:
    settings = get_settings()
    async with session_scope() as session:
        user = await get_or_create_user(session, **_user_from(message))
    await reply(
        message,
        fmt.settings_card(user, settings.ton_network, settings.enable_real_trading),
        reply_markup=notification_toggles(
            user.notification_prefs or {}, [c.value for c in NotificationCategory]
        ),
    )
