"""Message templates.

Templates use ``{name}`` custom-emoji tokens (see :mod:`app.bot.emojis`) and are
rendered through :func:`app.bot.emojis.render` before being sent, so premium
custom emojis appear whenever the ids are configured.

Emojis mark sections and key values - never every word.
"""
from __future__ import annotations

from typing import Any

from app.bot.emojis import e
from app.core.money import d, format_ton

DISCLAIMER = (
    "\n\n<i>Estimates only. Not financial advice. No profit is guaranteed.</i>"
)


def _fmt(value: Any, places: int = 2) -> str:
    if value is None:
        return "—"
    return format_ton(d(value), places)


# ---------------------------------------------------------------------------
# Welcome / help
# ---------------------------------------------------------------------------
def welcome(name: str) -> str:
    return (
        f"{e('ton')} <b>TON NFT TRADING TERMINAL</b>\n\n"
        f"Welcome, {name}.\n"
        f"Discover, analyse and trade TON NFTs — non-custodial.\n\n"
        f"{e('security')} Your keys never leave your wallet.\n"
        f"{e('analytics')} Rarity, fair value, liquidity and radar scoring.\n"
        f"{e('paper')} Practise risk-free in Paper Mode.\n\n"
        "Open the Mini App for the full terminal, or use the commands below."
    )


def help_text() -> str:
    return (
        f"{e('settings')} <b>Commands</b>\n\n"
        "/start — welcome &amp; Mini App\n"
        "/wallet — connect wallet, balances\n"
        "/radar — live opportunities\n"
        "/scan &lt;collection&gt; — scan a collection\n"
        "/analyze &lt;nft|url&gt; — full NFT analysis\n"
        "/buy &lt;nft&gt; — prepare a purchase\n"
        "/sell &lt;nft&gt; &lt;price&gt; — prepare a listing\n"
        "/swap &lt;amount&gt; TON USDT — quote a swap\n"
        "/portfolio — holdings &amp; P/L\n"
        "/watchlist — price &amp; discount alerts\n"
        "/strategy — strategy builder\n"
        "/history — trades &amp; transactions\n"
        "/settings — notifications &amp; risk\n\n"
        f"{e('security')} This bot never asks for a seed phrase or private key."
    )


# ---------------------------------------------------------------------------
# Wallet
# ---------------------------------------------------------------------------
def wallet_card(balances: dict[str, Any] | None, address: str | None) -> str:
    if not balances:
        return (
            f"{e('wallet')} <b>Wallet</b>\n\n"
            "No wallet connected yet.\n"
            "Open the Mini App and connect your TON wallet — the bot only ever "
            "receives your public address."
        )
    return (
        f"{e('wallet')} <b>Wallet</b>\n"
        f"<code>{address}</code>\n\n"
        f"{e('ton')} TON: <b>{_fmt(balances.get('ton'))}</b>\n"
        f"{e('usdt')} USDT: <b>{balances.get('usdt')}</b>"
    )


# ---------------------------------------------------------------------------
# Radar / analysis
# ---------------------------------------------------------------------------
def radar_card(item: dict[str, Any]) -> str:
    score = item.get("opportunity_score", 0)
    return (
        f"{e('radar')} <b>NFT RADAR</b>\n\n"
        f"{e('nft')} <b>{item.get('name') or 'Unknown NFT'}</b>\n\n"
        f"{e('ton')} Listed: <b>{_fmt(item.get('listed_price_ton'))} TON</b>\n"
        f"{e('analytics')} Est. fair value: "
        f"{_fmt(item.get('fair_value_low'))}–{_fmt(item.get('fair_value_high'))} TON\n"
        f"{e('opportunity')} Discount: {_fmt(item.get('discount_pct'))}%\n"
        f"{e('rarity')} Rarity: {item.get('rarity_score') or '—'}/100\n"
        f"{e('nft')} Number: {item.get('number_score') or '—'}/100\n"
        f"{e('market')} Liquidity: {item.get('liquidity_score') or '—'}/100\n"
        f"{e('gas')} Est. costs: {_fmt(item.get('estimated_costs_ton'))} TON\n"
        f"{e('profit')} Theoretical upside: {_fmt(item.get('theoretical_profit_ton'))} TON\n"
        f"{e('warning')} Risk: <b>{str(item.get('risk_level', 'medium')).upper()}</b>\n"
        f"{e('verified')} Confidence: {item.get('confidence') or '—'}/100\n\n"
        f"{e('analytics')} <b>Opportunity score: {score}/100</b>" + DISCLAIMER
    )


def analysis_card(analysis: dict[str, Any]) -> str:
    fair = analysis.get("fair_value") or {}
    liquidity = analysis.get("liquidity") or {}
    rarity = analysis.get("rarity") or {}
    number = analysis.get("number_profile") or {}
    return (
        f"{e('analytics')} <b>ANALYSIS</b>\n\n"
        f"{e('nft')} <b>{analysis.get('name') or 'Unknown'}</b>\n"
        f"{e('collection')} {analysis.get('collection_name') or '—'}\n\n"
        f"{e('ton')} Floor: {_fmt(analysis.get('floor'))} TON\n"
        f"{e('analytics')} Fair value: {fair.get('low', '—')}–{fair.get('high', '—')} TON "
        f"(confidence {fair.get('confidence', '—')}/100)\n"
        f"{e('rarity')} Rarity: {rarity.get('score', '—')}/100"
        f"{' · ' + str(rarity.get('percentile')) + ' percentile' if rarity.get('percentile') else ''}\n"
        f"{e('nft')} Number: {number.get('value', '—')} "
        f"({', '.join(number.get('labels', [])) or 'standard'})\n"
        f"{e('market')} Liquidity: {liquidity.get('score', '—')}/100 "
        f"({liquidity.get('risk', '—')})\n"
        f"{e('ton')} Listing: {_fmt(analysis.get('listing_price'))} TON\n"
        f"{e('profit')} Theoretical upside: {_fmt(analysis.get('theoretical_profit_ton'))} TON"
        + DISCLAIMER
    )


def collection_card(collection: dict[str, Any], health: dict[str, Any] | None = None) -> str:
    health = health or {}
    lines = [
        f"{e('collection')} <b>{collection.get('name') or collection.get('address')}</b>",
        "",
        f"{e('ton')} Floor: {_fmt(collection.get('floor_price_ton'))} TON",
        f"{e('market')} 24h volume: {_fmt(collection.get('volume_24h_ton'))} TON",
        f"{e('market')} 7d volume: {_fmt(collection.get('volume_7d_ton'))} TON",
        f"{e('analytics')} Listings: {collection.get('listings_count', 0)}",
    ]
    if health:
        lines += [
            f"{e('verified')} Health: {health.get('score', '—')}/100",
            f"{e('analytics')} Trend: <b>{str(health.get('trend', '')).upper()}</b>",
        ]
    for note in health.get("notes", [])[:3]:
        lines.append(f"{e('warning')} {note}")
    return "\n".join(lines)


def anomalies_card(anomalies: list[dict[str, Any]]) -> str:
    if not anomalies:
        return f"{e('verified')} No unusual market patterns detected in the observed window."
    lines = [f"{e('warning')} <b>MARKET ANOMALIES</b>\n"]
    for anomaly in anomalies[:5]:
        lines.append(
            f"\n{anomaly['kind'].replace('_', ' ').title()} "
            f"({anomaly['severity']})\n{anomaly['message']}"
        )
    lines.append("\n<i>Pattern observations only — no accusation of wrongdoing.</i>")
    return "\n".join(lines)


def whale_card(report: dict[str, Any]) -> str:
    accumulation = report.get("accumulation", {})
    lines = [
        f"{e('whale')} <b>ACCUMULATION SIGNAL</b>\n",
        f"{e('collection')} Collection: {report.get('collection') or '—'}",
        f"{e('analytics')} Net absorbed: {accumulation.get('net_items_absorbed', 0)} NFTs",
        f"{e('analytics')} Net distributed: {accumulation.get('net_items_distributed', 0)} NFTs",
        f"{e('verified')} Signal: <b>{accumulation.get('signal', 'LOW')}</b>",
    ]
    for signal in report.get("signals", [])[:3]:
        lines.append(f"\n<code>{signal['wallet'][:12]}…</code> {signal['message']}")
    lines.append("\n<i>Analytical signal from public data — not financial advice.</i>")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Trading
# ---------------------------------------------------------------------------
def buy_confirmation(payload: dict[str, Any]) -> str:
    nft = payload.get("nft", {})
    costs = payload.get("costs", {})
    lines = [
        f"{e('buy')} <b>CONFIRM BUY</b>\n",
        f"{e('nft')} {nft.get('name') or nft.get('address')}",
        f"{e('collection')} {payload.get('collection', {}).get('name') or '—'}",
        f"{e('market')} Marketplace: {payload.get('marketplace')}",
        f"{e('ton')} Price: {_fmt(payload.get('price_ton'))} TON",
        f"{e('gas')} Est. fees + royalties: {_fmt(costs.get('total_costs'))} TON",
        f"{e('wallet')} Total: <b>{_fmt(payload.get('total_ton'))} TON</b>",
        f"{e('transaction')} Network: {payload.get('network')}",
    ]
    if not payload.get("available"):
        lines += [
            "",
            f"{e('warning')} <b>Execution unavailable</b>",
            f"{payload.get('unavailable_reason', 'The marketplace provides no public API for this action.')}",
        ]
    else:
        lines += ["", f"{e('security')} Approve the transaction in your wallet."]
    return "\n".join(lines)


def transaction_confirmed(kind: str, amount: str, tx_hash: str | None, explorer: str) -> str:
    link = f"{explorer}/transaction/{tx_hash}" if tx_hash else explorer
    return (
        f"{e('success')} <b>{kind.upper()} CONFIRMED</b>\n\n"
        f"{e('ton')} Amount: {amount} TON\n"
        f"{e('transaction')} <a href=\"{link}\">View on explorer</a>"
    )


def swap_quote_card(quote: dict[str, Any]) -> str:
    return (
        f"{e('swap')} <b>SWAP QUOTE</b>\n\n"
        f"{e('ton')} {quote.get('from_amount')} → {quote.get('to_amount')}\n"
        f"{e('analytics')} Rate: {quote.get('rate')}\n"
        f"{e('warning')} Price impact: {quote.get('price_impact')}\n"
        f"{e('gas')} Network fee: {_fmt(quote.get('network_fee_ton'))} TON\n"
        f"{e('verified')} Minimum received: {quote.get('min_received')}\n"
        f"{e('history')} Expires: {quote.get('expires_at')}\n\n"
        f"Provider: {quote.get('provider')}"
        + ("\n\n<i>Indicative quote.</i>" if quote.get("estimate_only") else "")
    )


def portfolio_card(summary: dict[str, Any]) -> str:
    balances = summary.get("balances") or {}
    return (
        f"{e('portfolio')} <b>PORTFOLIO</b>\n\n"
        f"{e('wallet')} <code>{summary.get('wallet', {}).get('address') or 'no wallet'}</code>\n"
        f"{e('ton')} TON: {_fmt(balances.get('ton'))}\n"
        f"{e('usdt')} USDT: {balances.get('usdt', '—')}\n\n"
        f"{e('nft')} NFTs: {summary.get('holdings_count', 0)}\n"
        f"{e('analytics')} Est. NFT value: {_fmt(summary.get('estimated_nft_value_ton'))} TON\n"
        f"{e('profit')} Unrealised P/L: {_fmt(summary.get('unrealized_pnl_ton'))} TON\n"
        f"{e('verified')} Realised P/L: {_fmt(summary.get('realized_pnl_ton'))} TON\n\n"
        f"<i>{summary.get('note', '')}</i>"
    )


def paper_card(stats: dict[str, Any]) -> str:
    return (
        f"{e('paper')} <b>PAPER TRADING</b>\n\n"
        f"{e('analytics')} Closed trades: {stats.get('trades', 0)}\n"
        f"{e('opportunity')} Open: {stats.get('open', 0)}\n"
        f"{e('verified')} Win rate: {stats.get('win_rate_pct', '0')}%\n"
        f"{e('profit')} Realised P/L: {stats.get('realized_pnl_ton', '0')} TON\n"
        f"{e('loss')} Max drawdown: {stats.get('max_drawdown_ton', '0')} TON\n"
        f"{e('profit')} Best: {stats.get('best_trade_ton', '0')} TON\n"
        f"{e('loss')} Worst: {stats.get('worst_trade_ton', '0')} TON\n\n"
        f"<i>{stats.get('note', 'Simulated only.')}</i>"
    )


def settings_card(user: Any, network: str, real_trading: bool) -> str:
    prefs = user.notification_prefs or {}
    enabled = [name for name, value in prefs.items() if value]
    return (
        f"{e('settings')} <b>SETTINGS</b>\n\n"
        f"{e('market')} Network: <b>{network}</b>\n"
        f"{e('security')} Real trading: <b>{'ENABLED' if real_trading else 'DISABLED (paper mode)'}</b>\n"
        f"{e('notification')} Notifications: {', '.join(sorted(enabled)) or 'none'}\n\n"
        "Toggle notification categories below."
    )
