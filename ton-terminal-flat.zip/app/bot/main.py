"""Telegram bot entrypoint (aiogram 3.x).

Run polling::

    python -m app.bot.main

Or webhook (set ``USE_WEBHOOK=true`` and ``TELEGRAM_WEBHOOK_URL``).
"""
from __future__ import annotations

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand

from app.bot.handlers import callbacks, commands
from app.bot.notifications import TelegramNotifier
from app.core.config import get_settings
from app.core.logging import configure_logging, get_logger

logger = get_logger(__name__)

COMMANDS: list[tuple[str, str]] = [
    ("start", "Welcome and Mini App"),
    ("help", "All commands"),
    ("wallet", "Connect wallet and balances"),
    ("radar", "Live NFT opportunities"),
    ("scan", "Scan a collection"),
    ("analyze", "Full NFT analysis"),
    ("buy", "Prepare an NFT purchase"),
    ("sell", "Prepare an NFT listing"),
    ("swap", "Quote a TON/USDT swap"),
    ("portfolio", "Holdings and P/L"),
    ("watchlist", "Price and discount alerts"),
    ("strategy", "Strategy builder"),
    ("history", "Trades and transactions"),
    ("settings", "Notifications and risk"),
]


def build_dispatcher() -> Dispatcher:
    dispatcher = Dispatcher()
    dispatcher.include_router(commands.router)
    dispatcher.include_router(callbacks.router)
    return dispatcher


def build_bot() -> Bot:
    settings = get_settings()
    if not settings.telegram_bot_token:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN is not set. Add it to .env (see .env.example)."
        )
    return Bot(
        token=settings.telegram_bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


async def run_polling() -> None:
    configure_logging()
    settings = get_settings()
    bot = build_bot()
    dispatcher = build_dispatcher()
    await bot.set_my_commands([BotCommand(command=c, description=d) for c, d in COMMANDS])
    # Make the notifier available to services through the dispatcher context.
    dispatcher["notifier"] = TelegramNotifier(bot)
    logger.info("bot starting (polling)", extra={"extra_fields": {"network": settings.ton_network}})
    try:
        await dispatcher.start_polling(bot, allowed_updates=dispatcher.resolve_used_update_types())
    finally:
        await bot.session.close()


def main() -> None:
    try:
        asyncio.run(run_polling())
    except (KeyboardInterrupt, SystemExit):  # pragma: no cover
        logger.info("bot stopped")


if __name__ == "__main__":  # pragma: no cover
    main()
