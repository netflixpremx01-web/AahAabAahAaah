"""⭐ Premium Telegram custom emoji system (single source of truth).

Telegram custom emojis are **not** plain text: they are attached to a message
as a ``custom_emoji`` entity (Bot API:
https://core.telegram.org/bots/api#messageentity) pointing at a
``custom_emoji_id``. The message text still needs a placeholder glyph, which is
what the entity is rendered over.

Usage::

    from app.bot.emojis import e, render

    text = f"{e('radar')} NFT RADAR"
    rendered = render(text)
    await message.answer(rendered.text, entities=rendered.entities)

If a custom emoji id is missing (or invalid) the Unicode fallback is used - the
interface degrades gracefully rather than breaking.

Adding new ids: edit :data:`CUSTOM_EMOJIS` below - nowhere else.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# The ONE place where custom emoji ids live.
# Empty strings mean "not supplied yet" -> Unicode fallback is used.
# ---------------------------------------------------------------------------
CUSTOM_EMOJIS: dict[str, str] = {
    # --- ids supplied by the owner -----------------------------------------
    "one": "5247133031235329609",
    "two": "5246772116543512028",
    "three": "5249273776079640466",
    "four": "5247176827016847212",
    "five": "5246960163096632543",
    "six": "524720927549",
    # --- ids to be supplied later ------------------------------------------
    "wallet": "",
    "ton": "",
    "usdt": "",
    "nft": "",
    "buy": "",
    "sell": "",
    "swap": "",
    "radar": "",
    "opportunity": "",
    "profit": "",
    "loss": "",
    "warning": "",
    "success": "",
    "analytics": "",
    "rarity": "",
    "collection": "",
    "whale": "",
    "market": "",
    "portfolio": "",
    "strategy": "",
    "settings": "",
    "security": "",
    "verified": "",
    "notification": "",
    "error": "",
    "transaction": "",
    "history": "",
    "watchlist": "",
    "paper": "",
    "gas": "",
}

# Unicode fallbacks (used when no custom id is configured).
FALLBACK_EMOJIS: dict[str, str] = {
    "one": "1️⃣",
    "two": "2️⃣",
    "three": "3️⃣",
    "four": "4️⃣",
    "five": "5️⃣",
    "six": "6️⃣",
    "wallet": "👛",
    "ton": "💎",
    "usdt": "💵",
    "nft": "🖼",
    "buy": "🛒",
    "sell": "🏷",
    "swap": "🔄",
    "radar": "🔥",
    "opportunity": "🎯",
    "profit": "📈",
    "loss": "📉",
    "warning": "⚠️",
    "success": "✅",
    "analytics": "📊",
    "rarity": "🧬",
    "collection": "🗂",
    "whale": "🐋",
    "market": "🏛",
    "portfolio": "💼",
    "strategy": "🧠",
    "settings": "⚙️",
    "security": "🔐",
    "verified": "✔️",
    "notification": "🔔",
    "error": "❌",
    "transaction": "🧾",
    "history": "🕘",
    "watchlist": "👀",
    "paper": "📝",
    "gas": "⛽",
}

MIN_CUSTOM_EMOJI_ID_LENGTH = 15  # real ids are 19-20 digits


def custom_emoji_id(name: str) -> str | None:
    """Return a valid custom emoji id, or ``None`` when unavailable."""
    value = (CUSTOM_EMOJIS.get(name) or "").strip()
    if not value:
        return None
    if not value.isdigit() or len(value) < MIN_CUSTOM_EMOJI_ID_LENGTH:
        logger.debug("custom emoji '%s' has a malformed id - using fallback", name)
        return None
    return value


def fallback(name: str) -> str:
    return FALLBACK_EMOJIS.get(name, "")


def emoji(name: str) -> str:
    """Emoji token for a template: ``{name}``.

    The token is resolved by :func:`render` into either a real Telegram custom
    emoji entity or a Unicode fallback glyph.
    """
    return "{" + name + "}"


# Short alias used across the bot templates.
e = emoji


def utf16_len(text: str) -> int:
    return len(text.encode("utf-16-le")) // 2


@dataclass
class RenderedText:
    text: str
    entities: list[Any] = field(default_factory=list)


_TOKEN = re.compile(r"\{([a-z_]+)\}")


def render(template: str) -> RenderedText:
    """Resolve ``{name}`` tokens into text + Telegram custom emoji entities."""
    out: list[str] = []
    entities: list[Any] = []
    cursor = 0
    offset = 0  # running UTF-16 offset

    for match in _TOKEN.finditer(template):
        name = match.group(1)
        out.append(template[cursor : match.start()])
        offset += utf16_len(template[cursor : match.start()])

        glyph = fallback(name) or ""
        out.append(glyph)
        emoji_id = custom_emoji_id(name)
        if emoji_id and glyph:
            entities.append(_custom_emoji_entity(offset, utf16_len(glyph), emoji_id))
        offset += utf16_len(glyph)
        cursor = match.end()

    out.append(template[cursor:])
    return RenderedText(text="".join(out), entities=entities)


def _custom_emoji_entity(offset: int, length: int, custom_emoji_id_: str) -> Any:
    """Build the aiogram entity lazily (keeps this module import-light)."""
    from aiogram.types import MessageEntity

    return MessageEntity(
        type="custom_emoji",
        offset=offset,
        length=length,
        custom_emoji_id=custom_emoji_id_,
    )


def known_names() -> list[str]:
    return sorted(CUSTOM_EMOJIS)


def validate_ids() -> list[str]:
    """Report configured-but-invalid ids (used by /settings and tests)."""
    problems: list[str] = []
    for name, value in CUSTOM_EMOJIS.items():
        if value and (not value.isdigit() or len(value) < MIN_CUSTOM_EMOJI_ID_LENGTH):
            problems.append(f"{name}={value}")
    return problems
