"""Inline keyboards for the Telegram bot."""
from __future__ import annotations

from collections.abc import Sequence

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from app.core.config import get_settings


def mini_app_button(text: str = "Open Terminal") -> InlineKeyboardButton:
    settings = get_settings()
    url = settings.ton_app_url or "https://example.com"
    return InlineKeyboardButton(text=text, web_app=WebAppInfo(url=url))


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [mini_app_button("🚀 Open Trading Terminal")],
            [
                InlineKeyboardButton(text="🔥 Radar", callback_data="menu:radar"),
                InlineKeyboardButton(text="💼 Portfolio", callback_data="menu:portfolio"),
            ],
            [
                InlineKeyboardButton(text="🐋 Market", callback_data="menu:market"),
                InlineKeyboardButton(text="⚙️ Settings", callback_data="menu:settings"),
            ],
        ]
    )


def radar_actions(opportunity_id: int, nft_address: str | None = None) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="👀 Watch", callback_data=f"watch:nft:{nft_address}"),
            InlineKeyboardButton(text="🛒 Buy", callback_data=f"buy:{opportunity_id}"),
        ],
        [
            InlineKeyboardButton(text="📊 Analyse", callback_data=f"analyze:{nft_address}"),
            InlineKeyboardButton(text="📝 Paper buy", callback_data=f"paper:{opportunity_id}"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def confirm_buy(opportunity_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Confirm in wallet", callback_data=f"confirm:buy:{opportunity_id}")],
            [InlineKeyboardButton(text="❌ Cancel", callback_data="cancel")],
        ]
    )


def notification_toggles(prefs: dict[str, bool], categories: Sequence[str]) -> InlineKeyboardMarkup:
    rows = []
    row: list[InlineKeyboardButton] = []
    for category in categories:
        enabled = bool(prefs.get(category, True))
        row.append(
            InlineKeyboardButton(
                text=f"{'✅' if enabled else '⛔'} {category}",
                callback_data=f"notify:{category}",
            )
        )
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(text="Close", callback_data="cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def simple(rows: Sequence[Sequence[tuple[str, str]]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=t, callback_data=c) for t, c in row] for row in rows]
    )
