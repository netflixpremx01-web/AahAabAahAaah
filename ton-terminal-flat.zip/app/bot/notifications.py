"""Telegram notifier: renders custom-emoji messages and delivers them."""
from __future__ import annotations

from aiogram import Bot
from aiogram.enums import ParseMode

from app.bot.emojis import render
from app.core.logging import get_logger

logger = get_logger(__name__)


class TelegramNotifier:
    """Adapter used by :class:`app.services.notifications.NotificationService`."""

    def __init__(self, bot: Bot) -> None:
        self.bot = bot

    async def send(self, telegram_id: int, title: str, body: str) -> bool:
        text, entities = render(f"{title}\n\n{body}").text, render(f"{title}\n\n{body}").entities
        try:
            await self.bot.send_message(
                chat_id=telegram_id, text=text, entities=entities, parse_mode=ParseMode.HTML
            )
            return True
        except Exception as exc:  # delivery errors are recorded, never fatal
            logger.warning(
                "telegram send failed",
                extra={"extra_fields": {"chat": telegram_id, "error": str(exc)}},
            )
            return False
