"""Validation of Telegram Mini App ``initData``.

Official algorithm (https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app):

1. parse the query string into key/value pairs,
2. remove ``hash`` and sort the remaining pairs,
3. build ``"\\n".join(f"{k}={v}")``,
4. ``secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)``,
5. ``hash = HMAC_SHA256(secret_key, data_check_string)``,
6. compare with a constant-time comparison.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qsl, unquote

from app.core.config import get_settings
from app.core.errors import AuthenticationError


@dataclass(frozen=True)
class InitData:
    raw: str
    query_id: str | None
    user: dict[str, Any] | None
    auth_date: int
    chat: dict[str, Any] | None
    start_param: str | None

    @property
    def telegram_id(self) -> int | None:
        return int(self.user["id"]) if self.user and "id" in self.user else None

    @property
    def display_name(self) -> str:
        if not self.user:
            return "unknown"
        name = self.user.get("first_name") or ""
        if self.user.get("last_name"):
            name = f"{name} {self.user['last_name']}".strip()
        return name or (self.user.get("username") or "unknown")


def parse_init_data(raw: str) -> dict[str, str]:
    return dict(parse_qsl(raw, keep_blank_values=True))


def build_data_check_string(pairs: dict[str, str]) -> str:
    return "\n".join(f"{key}={value}" for key, value in sorted(pairs.items()))


def verify_signature(raw: str, bot_token: str, max_age_seconds: int = 3600) -> InitData:
    pairs = parse_init_data(raw)
    received_hash = pairs.pop("hash", None)
    if not received_hash:
        raise AuthenticationError("initData is missing the hash field")

    data_check_string = build_data_check_string(pairs)
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    computed = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(computed, received_hash):
        raise AuthenticationError("initData signature mismatch")

    auth_date = int(pairs.get("auth_date") or 0)
    if auth_date and (time.time() - auth_date) > max_age_seconds:
        raise AuthenticationError("initData is too old")

    user_raw = pairs.get("user")
    chat_raw = pairs.get("chat")
    return InitData(
        raw=raw,
        query_id=pairs.get("query_id"),
        user=json.loads(unquote(user_raw)) if user_raw else None,
        auth_date=auth_date,
        chat=json.loads(unquote(chat_raw)) if chat_raw else None,
        start_param=pairs.get("start_param"),
    )


def validate_init_data(raw: str | None, *, dev_mode: bool | None = None) -> InitData:
    """Validate ``initData``.

    In development mode (explicit opt-in) an empty/placeholder value is
    accepted so the Mini App can be opened from a plain browser. This is never
    allowed when ``dev_mode`` is disabled.
    """
    settings = get_settings()
    allow_dev = settings.dev_mode if dev_mode is None else dev_mode
    if not raw:
        if allow_dev:
            return InitData(
                raw="",
                query_id=None,
                user={"id": 1, "first_name": "Dev", "username": "dev_user"},
                auth_date=int(time.time()),
                chat=None,
                start_param=None,
            )
        raise AuthenticationError("missing initData")
    if not settings.telegram_bot_token:
        if allow_dev:
            # Cannot verify without a token: fall back to parsing only.
            pairs = parse_init_data(raw)
            user_raw = pairs.get("user")
            return InitData(
                raw=raw,
                query_id=pairs.get("query_id"),
                user=json.loads(unquote(user_raw)) if user_raw else None,
                auth_date=int(pairs.get("auth_date") or time.time()),
                chat=None,
                start_param=pairs.get("start_param"),
            )
        raise AuthenticationError("bot token is not configured")
    return verify_signature(raw, settings.telegram_bot_token)
