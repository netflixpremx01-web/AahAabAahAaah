"""Guards that keep secrets out of API responses, logs and the Mini App."""
from __future__ import annotations

from typing import Any

from app.core.config import get_settings

FORBIDDEN_KEYS = (
    "api_key",
    "apikey",
    "secret",
    "token",
    "password",
    "mnemonic",
    "seed",
    "private_key",
    "database_url",
    "redis_url",
)


def redact_mapping(payload: dict[str, Any]) -> dict[str, Any]:
    """Recursively mask values whose key looks like a credential."""
    clean: dict[str, Any] = {}
    for key, value in payload.items():
        lowered = key.lower()
        if any(hint in lowered for hint in FORBIDDEN_KEYS):
            clean[key] = "***redacted***"
        elif isinstance(value, dict):
            clean[key] = redact_mapping(value)
        elif isinstance(value, list):
            clean[key] = [redact_mapping(v) if isinstance(v, dict) else v for v in value]
        else:
            clean[key] = value
    return clean


def assert_no_secrets(payload: Any) -> Any:
    """Fail fast in development if a real secret value is about to be returned."""
    settings = get_settings()
    if settings.is_production:
        return payload
    text = str(payload)
    for secret in settings.secret_values():
        if secret and len(secret) > 8 and secret in text:
            raise RuntimeError("Attempted to serialise a secret value")
    return payload


SAFE_CONFIG_KEYS = (
    "app_name",
    "env",
    "ton_network",
    "dev_mode",
    "ton_app_url",
    "enable_real_trading",
    "enable_paper_trading",
    "default_marketplace_fee_bps",
    "default_royalty_bps",
    "network_fee_estimate_ton",
    "default_slippage",
    "max_slippage",
    "quote_ttl_seconds",
)


def public_config() -> dict[str, Any]:
    """The only configuration the Mini App is ever allowed to see."""
    data = get_settings().model_dump()
    return {key: data[key] for key in SAFE_CONFIG_KEYS if key in data}
