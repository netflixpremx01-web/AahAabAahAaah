"""Security helpers: Telegram WebApp auth, TON Connect proof, secret hygiene."""
