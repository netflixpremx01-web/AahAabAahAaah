"""Opportunity scoring, cost model and risk evaluation.

The score is a transparent 0-100 composite - every point is traceable to a
component so the UI can always explain *why* something scored the way it did.

Never guarantees profit: outputs are labelled "theoretical" everywhere.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from app.core.config import get_settings
from app.core.money import apply_bps, d, quantize_ton
from app.models.enums import RiskLevel


@dataclass
class CostBreakdown:
    price: Any
    marketplace_fee: Any
    royalty: Any
    network_fee: Any
    total_costs: Any
    total_outflow: Any

    def as_dict(self) -> dict[str, str]:
        return {k: str(v) for k, v in self.__dict__.items()}


def compute_costs(
    price: Any,
    *,
    marketplace_fee_bps: int | None = None,
    royalty_bps: int | None = None,
    network_fee_ton: Any | None = None,
) -> dict[str, Any]:
    """Costs for a *round trip*: buy now, sell later at the same price.

    Marketplace fees and royalties are charged on the sale, so the buy side is
    only price + network fee.
    """
    settings = get_settings()
    fee_bps = settings.default_marketplace_fee_bps if marketplace_fee_bps is None else marketplace_fee_bps
    royalty = settings.default_royalty_bps if royalty_bps is None else royalty_bps
    network = d(settings.network_fee_estimate_ton if network_fee_ton is None else network_fee_ton)

    price_v = quantize_ton(d(price))
    sale_fee = apply_bps(price_v, fee_bps)
    royalty_fee = apply_bps(price_v, royalty)
    total_costs = quantize_ton(sale_fee + royalty_fee + network)
    return {
        "price": str(price_v),
        "marketplace_fee": str(sale_fee),
        "royalty": str(royalty_fee),
        "network_fee": str(network),
        "total_costs": str(total_costs),
        "total_outflow": str(quantize_ton(price_v + network)),
    }


@dataclass
class OpportunityScore:
    score: int
    components: dict[str, int] = field(default_factory=dict)
    reasons: list[str] = field(default_factory=list)
    label: str = "neutral"

    def as_dict(self) -> dict[str, Any]:
        return {
            "score": self.score,
            "components": self.components,
            "reasons": self.reasons,
            "label": self.label,
        }


def _component_discount(discount: Any | None) -> int:
    """0-30 points: bigger discount to estimated fair value scores higher."""
    value = float(d(discount))
    if value <= 0:
        return 0
    return int(min(30, round(value * 0.9)))


def _component_rarity(rarity_score: int | None) -> int:
    if rarity_score is None:
        return 0
    return int(round(min(20, rarity_score / 100 * 20)))


def _component_number(number_score: int) -> int:
    return int(round(min(10, max(0, number_score) / 100 * 10)))


def _component_liquidity(liquidity_score: int) -> int:
    return int(round(min(15, max(0, liquidity_score) / 100 * 15)))


def _component_confidence(confidence: int) -> int:
    return int(round(min(15, max(0, confidence) / 100 * 15)))


def _component_roi(roi_pct: Any | None) -> int:
    """0-10 points: theoretical ROI after all costs."""
    value = float(d(roi_pct))
    if value <= 0:
        return 0
    return int(min(10, round(value / 5)))


def _risk_penalty(risk: RiskLevel) -> int:
    return {
        RiskLevel.LOW: 0,
        RiskLevel.MEDIUM: 3,
        RiskLevel.HIGH: 7,
        RiskLevel.EXTREME: 10,
    }[risk]


def compute_opportunity_score(
    *,
    discount: Any | None,
    rarity_score: int | None,
    number_score: int,
    liquidity_score: int,
    confidence: int,
    roi_pct: Any | None,
    price_ton: Any | None = None,
    floor: Any | None = None,
) -> OpportunityScore:
    """Composite 0-100 opportunity score with a full explanation."""
    discount_c = _component_discount(discount)
    rarity_c = _component_rarity(rarity_score)
    number_c = _component_number(number_score)
    liquidity_c = _component_liquidity(liquidity_score)
    confidence_c = _component_confidence(confidence)
    roi_c = _component_roi(roi_pct)

    risk = evaluate_risk(
        liquidity_score=liquidity_score,
        confidence=confidence,
        price_ton=price_ton,
        floor=floor,
        discount=discount,
    )
    penalty = _risk_penalty(risk)

    total = int(max(0, min(100, discount_c + rarity_c + number_c + liquidity_c + confidence_c + roi_c - penalty)))

    reasons: list[str] = []
    if discount_c:
        reasons.append(f"Trading {d(discount)}% below estimated fair value.")
    else:
        reasons.append("No measurable discount to estimated fair value.")
    if rarity_c:
        reasons.append(f"Rarity score {rarity_score}/100.")
    if number_c:
        reasons.append(f"Collector number score {number_score}/100.")
    if liquidity_c >= 12:
        reasons.append(f"Healthy liquidity ({liquidity_score}/100).")
    elif liquidity_c <= 6:
        reasons.append(f"Thin liquidity ({liquidity_score}/100) - exit risk.")
    if roi_c:
        reasons.append(f"Theoretical ROI after costs: {d(roi_pct)}%.")
    if penalty:
        reasons.append(f"Risk adjustment: -{penalty} points ({risk.value}).")

    label = "strong" if total >= 75 else "good" if total >= 60 else "moderate" if total >= 40 else "weak"
    return OpportunityScore(
        score=total,
        components={
            "discount": discount_c,
            "rarity": rarity_c,
            "number": number_c,
            "liquidity": liquidity_c,
            "confidence": confidence_c,
            "roi": roi_c,
            "risk_penalty": -penalty,
        },
        reasons=reasons,
        label=label,
    )


def evaluate_risk(
    *,
    liquidity_score: int,
    confidence: int,
    price_ton: Any | None = None,
    floor: Any | None = None,
    discount: Any | None = None,
) -> RiskLevel:
    """Explainable risk classification. No profit implication involved."""
    points = 0
    price_v, floor_v = d(price_ton), d(floor)
    if liquidity_score < 25:
        points += 2
    elif liquidity_score < 45:
        points += 1
    if confidence < 40:
        points += 2
    elif confidence < 60:
        points += 1
    if floor_v > 0 and price_v > 0:
        ratio = price_v / floor_v
        if ratio > 3:
            points += 2
        elif ratio > 1.75:
            points += 1
    if d(discount) > 70:
        # unusually large discounts usually mean the data is wrong
        points += 2
    if points >= 5:
        return RiskLevel.EXTREME
    if points >= 3:
        return RiskLevel.HIGH
    if points >= 1:
        return RiskLevel.MEDIUM
    return RiskLevel.LOW


def theoretical_upside(price: Any, fair_value: Any, costs: dict[str, Any]) -> dict[str, Any]:
    """Theoretical result of buying at ``price`` and selling at ``fair_value``."""
    price_v, fair_v = d(price), d(fair_value)
    exit_costs = d(costs.get("marketplace_fee", 0)) + d(costs.get("royalty", 0)) + d(
        costs.get("network_fee", 0)
    )
    gross = quantize_ton(fair_v - price_v)
    net = quantize_ton(fair_v - price_v - exit_costs - d(costs.get("network_fee", 0)))
    roi = ((net / price_v) * 100).quantize(Decimal("0.01")) if price_v > 0 else d("0")
    return {
        "gross": str(gross),
        "net": str(net),
        "roi_pct": str(roi),
        "break_even_price": str(quantize_ton(price_v + exit_costs)),
    }
