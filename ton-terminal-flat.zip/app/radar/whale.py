"""Whale activity analyser over publicly observable blockchain data.

Signals are analytical only: "a wallet accumulated N items" is a fact derived
from public sales/transfers; what it *means* is left to the user.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from app.core.money import d, median
from app.models.enums import RiskLevel


@dataclass
class WhaleSignal:
    wallet: str
    bought: int = 0
    sold: int = 0
    net_items: int = 0
    bought_volume_ton: Any = 0
    sold_volume_ton: Any = 0
    avg_price_ton: Any | None = None
    signal: RiskLevel = RiskLevel.LOW
    message: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "wallet": self.wallet,
            "bought": self.bought,
            "sold": self.sold,
            "net_items": self.net_items,
            "bought_volume_ton": str(self.bought_volume_ton),
            "sold_volume_ton": str(self.sold_volume_ton),
            "avg_price_ton": str(self.avg_price_ton) if self.avg_price_ton else None,
            "signal": self.signal.value,
            "message": self.message,
        }


@dataclass
class WhaleReport:
    collection: str | None
    signals: list[WhaleSignal] = field(default_factory=list)
    accumulation: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "collection": self.collection,
            "signals": [s.as_dict() for s in self.signals[:10]],
            "accumulation": {k: str(v) for k, v in self.accumulation.items()},
        }


def _signal_level(net_items: int, volume: Any, median_price: Any | None) -> RiskLevel:
    relative = (d(volume) / median_price) if (median_price and d(median_price) > 0) else d("0")
    if net_items >= 10 or relative >= 8:
        return RiskLevel.HIGH
    if net_items >= 5 or relative >= 3:
        return RiskLevel.MEDIUM
    return RiskLevel.LOW


def analyse_whales(
    sales: Sequence[dict[str, Any]],
    *,
    collection: str | None = None,
    window_hours: int = 72,
    now: datetime | None = None,
    min_items: int = 3,
) -> WhaleReport:
    """Aggregate buy/sell activity per wallet from public sales data.

    ``sales`` items: ``{buyer, seller, price, ts}``.
    """
    cutoff = now
    if cutoff is not None and window_hours:
        from datetime import timedelta

        cutoff = cutoff - timedelta(hours=window_hours)

    stats: dict[str, dict[str, Any]] = {}
    prices: list[Any] = []
    for sale in sales:
        ts = sale.get("ts")
        if cutoff and ts and ts < cutoff:
            continue
        price = d(sale.get("price") or 0)
        prices.append(price)
        for role, field_name in (("buyer", "bought"), ("seller", "sold")):
            wallet = sale.get(role)
            if not wallet:
                continue
            entry = stats.setdefault(
                wallet,
                {
                    "bought": 0,
                    "sold": 0,
                    "bought_volume": d("0"),
                    "sold_volume": d("0"),
                    "prices": [],
                },
            )
            entry[field_name] += 1
            if role == "buyer":
                entry["bought_volume"] += price
                entry["prices"].append(price)

    median_price = median(prices)
    signals: list[WhaleSignal] = []
    for wallet, entry in stats.items():
        net_items = entry["bought"] - entry["sold"]
        if entry["bought"] < min_items and abs(net_items) < min_items:
            continue
        level = _signal_level(net_items, entry["bought_volume"], median_price)
        direction = "accumulating" if net_items > 0 else "distributing" if net_items < 0 else "churning"
        signals.append(
            WhaleSignal(
                wallet=wallet,
                bought=entry["bought"],
                sold=entry["sold"],
                net_items=net_items,
                bought_volume_ton=entry["bought_volume"],
                sold_volume_ton=entry["sold_volume"],
                avg_price_ton=median(entry["prices"]) if entry["prices"] else None,
                signal=level,
                message=(
                    f"{direction.title()} {abs(net_items)} NFTs "
                    f"(bought {entry['bought']}, sold {entry['sold']}) "
                    f"for {entry['bought_volume']} TON."
                ),
            )
        )

    signals.sort(key=lambda s: (s.signal != RiskLevel.HIGH, -abs(s.net_items)))

    net_absorption = sum((s.net_items for s in signals if s.net_items > 0), 0)
    net_distribution = sum((-s.net_items for s in signals if s.net_items < 0), 0)
    accumulation = {
        "wallets_analysed": len(stats),
        "accumulating_wallets": sum(1 for s in signals if s.net_items > 0),
        "distributing_wallets": sum(1 for s in signals if s.net_items < 0),
        "net_items_absorbed": net_absorption,
        "net_items_distributed": net_distribution,
        "signal": (
            "HIGH"
            if net_absorption - net_distribution >= 10
            else "MEDIUM"
            if net_absorption - net_distribution >= 4
            else "LOW"
        ),
        "note": "Analytical signal derived from public sales - not financial advice.",
    }
    return WhaleReport(collection=collection, signals=signals, accumulation=accumulation)
