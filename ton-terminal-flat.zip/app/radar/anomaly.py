"""Market anomaly detector over public market data.

Detects unusual *patterns* and always explains which observation triggered the
flag. It never accuses anyone of manipulation or fraud: the wording stays
descriptive ("pattern observed", "unverified", "possible").
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from app.core.money import d, mean, median, pct
from app.models.enums import RiskLevel

Point = tuple[datetime, Any]  # (timestamp, value)


@dataclass
class Anomaly:
    kind: str
    severity: RiskLevel
    message: str
    evidence: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "severity": self.severity.value,
            "message": self.message,
            "evidence": {k: str(v) for k, v in self.evidence.items()},
        }


def _pct_change(before: Any, after: Any) -> Any:
    before_v, after_v = d(before), d(after)
    if before_v <= 0:
        return d("0")
    return pct(after_v - before_v, before_v)


def detect_anomalies(
    *,
    floor_series: Sequence[Point],
    volume_series: Sequence[Point],
    recent_sales: Sequence[dict[str, Any]] | None = None,
    listing_prices: Sequence[Any] | None = None,
    floor: Any | None = None,
    collection_size: int | None = None,
    lookback_points: int = 24,
) -> list[Anomaly]:
    """Detect anomalies in floor/volume/sales/listing observations."""
    anomalies: list[Anomaly] = []
    floors = list(floor_series or [])[-lookback_points:]
    volumes = list(volume_series or [])[-lookback_points:]

    # ------------------------------------------------------- floor movement
    if len(floors) >= 2:
        change = _pct_change(floors[0][1], floors[-1][1])
        baseline = [d(v) for _, v in floors]
        typical = median([abs(_pct_change(baseline[i], baseline[i + 1])) for i in range(len(baseline) - 1)])
        threshold = max(d("15"), (typical or d("10")) * d("3"))
        if d(change) <= -threshold:
            anomalies.append(
                Anomaly(
                    kind="floor_crash",
                    severity=RiskLevel.HIGH if d(change) <= -35 else RiskLevel.MEDIUM,
                    message=(
                        f"Floor moved {change}% between the first and last sample "
                        f"({len(floors)} observations), which is {change / (typical or d(1)):.1f}x "
                        "the typical move in this window."
                    ),
                    evidence={"change_pct": str(change), "typical_move_pct": str(typical or 0)},
                )
            )
        elif d(change) >= threshold:
            anomalies.append(
                Anomaly(
                    kind="floor_spike",
                    severity=RiskLevel.MEDIUM,
                    message=f"Floor moved +{change}% in the observed window.",
                    evidence={"change_pct": str(change)},
                )
            )

    # -------------------------------------------------------- volume spike
    if len(volumes) >= 4:
        values = [d(v) for _, v in volumes]
        recent = values[-1]
        baseline = mean(values[:-1]) or d("0")
        if baseline > 0 and recent > baseline * d("4"):
            anomalies.append(
                Anomaly(
                    kind="volume_spike",
                    severity=RiskLevel.MEDIUM,
                    message=(
                        f"Latest volume ({recent}) is {recent / baseline:.1f}x the window average "
                        f"({baseline}). Unverified - could be a genuine event or a single actor."
                    ),
                    evidence={"recent": str(recent), "average": str(baseline)},
                )
            )

    # ------------------------------------------------- extreme price gaps
    prices = sorted(d(p) for p in (listing_prices or []) if d(p) > 0)
    if floor and prices:
        floor_v = d(floor)
        outliers = [p for p in prices if p > floor_v * d("5")]
        if len(outliers) >= max(3, len(prices) // 10):
            anomalies.append(
                Anomaly(
                    kind="extreme_price_gap",
                    severity=RiskLevel.LOW,
                    message=(
                        f"{len(outliers)} listings are priced above 5x the current floor "
                        f"({floor_v}). Wide gaps often mean thin price discovery."
                    ),
                    evidence={"outliers": len(outliers), "floor": str(floor_v)},
                )
            )

    # --------------------------------------------- listing concentration
    if collection_size and listing_prices:
        ratio = len(listing_prices) / max(1, collection_size)
        if ratio > 0.25:
            anomalies.append(
                Anomaly(
                    kind="listing_concentration",
                    severity=RiskLevel.MEDIUM if ratio > 0.4 else RiskLevel.LOW,
                    message=(
                        f"{len(listing_prices)} of {collection_size} items "
                        f"({ratio * 100:.1f}%) are listed simultaneously."
                    ),
                    evidence={"listed_ratio": f"{ratio:.3f}"},
                )
            )

    # ------------------------------------------------ rapid undercutting
    sales = sorted(
        (s for s in (recent_sales or []) if s.get("ts") and s.get("price")),
        key=lambda s: s["ts"],
    )
    if len(sales) >= 3:
        drops = 0
        for previous, current in zip(sales, sales[1:], strict=False):
            if d(current["price"]) < d(previous["price"]) * d("0.9"):
                drops += 1
        if drops >= 3:
            anomalies.append(
                Anomaly(
                    kind="rapid_undercutting",
                    severity=RiskLevel.MEDIUM,
                    message=(
                        f"{drops} consecutive sales closed at least 10% below the "
                        "previous sale - sellers are competing the price down."
                    ),
                    evidence={"consecutive_drops": drops},
                )
            )

    # ------------------------------------------- unusual sales activity
    if len(sales) >= 2:
        wallets: dict[str, int] = {}
        for sale in sales:
            buyer = sale.get("buyer")
            if buyer:
                wallets[buyer] = wallets.get(buyer, 0) + 1
        top_wallet, top_count = (max(wallets.items(), key=lambda kv: kv[1]) if wallets else (None, 0))
        if top_wallet and top_count >= max(3, len(sales) // 3):
            anomalies.append(
                Anomaly(
                    kind="unusual_sales_activity",
                    severity=RiskLevel.MEDIUM,
                    message=(
                        f"One wallet accounts for {top_count} of the last {len(sales)} sales. "
                        "This is an observation, not an accusation."
                    ),
                    evidence={"wallet": top_wallet, "sales": top_count},
                )
            )
    return anomalies
