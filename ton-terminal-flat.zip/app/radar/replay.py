"""Opportunity replay: what actually happened after a detection.

Compares the detection price with later observations at 24h / 48h / 72h and
records both the *theoretical* result (what the model projected) and the
*actual* outcome. Historical performance is reported as-is with an explicit
"past performance does not imply future results" note.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.core.money import d, pct, quantize_ton

HORIZONS = (24, 48, 72)
DISCLAIMER = (
    "Historical observation only. Past detections do not imply future results."
)


@dataclass
class ReplayResult:
    horizon_hours: int
    detection_price: Any
    observed_price: Any | None
    observed_floor: Any | None
    theoretical_result: Any | None
    actual_result: Any | None
    outcome: str
    computed_at: datetime | None = None
    note: str = DISCLAIMER

    def as_dict(self) -> dict[str, Any]:
        return {
            "horizon_hours": self.horizon_hours,
            "detection_price": str(self.detection_price),
            "observed_price": str(self.observed_price) if self.observed_price is not None else None,
            "observed_floor": str(self.observed_floor) if self.observed_floor is not None else None,
            "theoretical_result": str(self.theoretical_result)
            if self.theoretical_result is not None
            else None,
            "actual_result": str(self.actual_result) if self.actual_result is not None else None,
            "outcome": self.outcome,
            "note": self.note,
        }


def replay_opportunity(
    *,
    detection_price: Any,
    horizon_hours: int,
    observed_price: Any | None = None,
    observed_floor: Any | None = None,
    projected_price: Any | None = None,
    sold: bool = False,
    costs: Any | None = None,
    computed_at: datetime | None = None,
) -> ReplayResult:
    """Compare detection vs. later observation for one horizon."""
    detection = d(detection_price)
    observed = d(observed_price) if observed_price is not None else None
    floor = d(observed_floor) if observed_floor is not None else None
    reference = observed if observed is not None else floor

    theoretical = None
    if projected_price is not None and costs is not None:
        theoretical = quantize_ton(d(projected_price) - detection - d(costs))

    actual = quantize_ton(reference - detection - d(costs or 0)) if reference is not None else None

    if reference is None:
        outcome = "unknown"
    elif sold:
        outcome = "sold"
    elif observed is not None:
        outcome = "relisted" if observed != detection else "unchanged"
    else:
        outcome = "floor-reference"

    return ReplayResult(
        horizon_hours=horizon_hours,
        detection_price=quantize_ton(detection),
        observed_price=quantize_ton(observed) if observed is not None else None,
        observed_floor=quantize_ton(floor) if floor is not None else None,
        theoretical_result=theoretical,
        actual_result=actual,
        outcome=outcome,
        computed_at=computed_at,
    )


def replay_summary(results: list[ReplayResult]) -> dict[str, Any]:
    """Aggregate replay outcomes across opportunities (honest, no promises)."""
    completed = [r for r in results if r.actual_result is not None]
    if not completed:
        return {"samples": 0, "note": DISCLAIMER}
    wins = [r for r in completed if d(r.actual_result) > 0]
    losses = [r for r in completed if d(r.actual_result) <= 0]
    totals = [d(r.actual_result) for r in completed]
    return {
        "samples": len(completed),
        "positive": len(wins),
        "negative": len(losses),
        "hit_rate_pct": pct(len(wins), len(completed)),
        "avg_result_ton": quantize_ton(sum(totals, d("0")) / len(totals)),
        "best_ton": quantize_ton(max(totals)),
        "worst_ton": quantize_ton(min(totals)),
        "note": DISCLAIMER,
    }


def _unused(*_: Any) -> None:  # pragma: no cover
    return None
