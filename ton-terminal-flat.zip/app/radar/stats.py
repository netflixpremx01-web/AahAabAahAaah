"""Collection health and trend detection.

Health is a 0-100 composite over floor movement, sales activity, traded volume,
buyer/seller balance and listing pressure. It is descriptive statistics over
public on-chain/market data - never a recommendation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from app.core.money import d, pct
from app.models.enums import Trend


@dataclass
class CollectionHealthInput:
    floor_now: Any | None = None
    floor_24h_ago: Any | None = None
    floor_7d_ago: Any | None = None
    volume_24h_ton: Any = 0
    volume_7d_ton: Any = 0
    sales_24h: int = 0
    sales_7d: int = 0
    buyers_24h: int = 0
    sellers_24h: int = 0
    listings_count: int = 0
    collection_size: int | None = None


@dataclass
class CollectionHealth:
    score: int
    trend: Trend
    metrics: dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "score": self.score,
            "trend": self.trend.value,
            "metrics": {k: str(v) for k, v in self.metrics.items()},
            "notes": self.notes,
        }


def compute_trend(
    floor_now: Any | None, floor_24h_ago: Any | None, floor_7d_ago: Any | None = None
) -> Trend:
    """Classify the floor trend; volatile wins over directional moves."""
    now, day, week = d(floor_now), d(floor_24h_ago), d(floor_7d_ago)
    change_24h = pct(now - day, day) if day > 0 else d("0")
    change_7d = pct(now - week, week) if week > 0 else d("0")

    if abs(change_24h) >= 10:
        return Trend.VOLATILE
    if change_7d >= 5:
        return Trend.BULLISH
    if change_7d <= -5:
        return Trend.BEARISH
    if abs(change_7d) < 2:
        return Trend.FLAT
    return Trend.BULLISH if change_7d > 0 else Trend.BEARISH


def _score_floor_movement(change_7d: Any) -> int:
    """0-25: map -30%..+30% onto 0..25."""
    value = float(d(change_7d))
    return int(max(0, min(25, round((value + 30) / 60 * 25))))


def _score_sales_activity(sales_7d: int, collection_size: int | None) -> int:
    if sales_7d <= 0:
        return 0
    base = math.log1p(sales_7d) / math.log1p(50)
    score = base * 25
    if collection_size:
        turnover = sales_7d / max(1, collection_size)
        score *= min(1.5, 0.5 + turnover * 10)
    return int(max(0, min(25, round(score))))


def _score_volume(volume_7d: Any) -> int:
    value = float(d(volume_7d))
    if value <= 0:
        return 0
    return int(max(0, min(20, round(math.log1p(value) / math.log1p(2000) * 20))))


def _score_balance(buyers: int, sellers: int) -> int:
    total = buyers + sellers
    if total == 0:
        return 5
    return int(round((buyers / total) * 15))


def _score_listing_pressure(listings: int, collection_size: int | None) -> int:
    if not collection_size:
        return 7
    ratio = listings / max(1, collection_size)
    if ratio <= 0.02:
        return 15
    if ratio >= 0.2:
        return 0
    return int(round(15 * (1 - (ratio - 0.02) / 0.18)))


def compute_collection_health(data: CollectionHealthInput) -> CollectionHealth:
    notes: list[str] = []
    now = d(data.floor_now)
    week = d(data.floor_7d_ago)
    change_7d = pct(now - week, week) if week > 0 else d("0")
    change_24h = pct(now - d(data.floor_24h_ago), d(data.floor_24h_ago)) if d(data.floor_24h_ago) > 0 else d("0")

    movement = _score_floor_movement(change_7d)
    activity = _score_sales_activity(data.sales_7d, data.collection_size)
    volume = _score_volume(data.volume_7d_ton)
    balance = _score_balance(data.buyers_24h, data.sellers_24h)
    pressure = _score_listing_pressure(data.listings_count, data.collection_size)
    score = int(max(0, min(100, movement + activity + volume + balance + pressure)))
    trend = compute_trend(data.floor_now, data.floor_24h_ago, data.floor_7d_ago)

    if data.sales_7d == 0:
        notes.append("No sales in the last 7 days.")
    if d(change_24h) <= -15:
        notes.append(f"Floor dropped {change_24h}% in 24h.")
    if d(change_24h) >= 15:
        notes.append(f"Floor rose {change_24h}% in 24h.")
    if data.collection_size and data.listings_count / max(1, data.collection_size) > 0.15:
        notes.append("More than 15% of the collection is listed for sale.")
    if trend is Trend.VOLATILE:
        notes.append("Price action is volatile - widen your assumptions.")

    return CollectionHealth(
        score=score,
        trend=trend,
        metrics={
            "floor_change_24h_pct": str(change_24h),
            "floor_change_7d_pct": str(change_7d),
            "floor_movement": movement,
            "sales_activity": activity,
            "volume": volume,
            "buyer_seller_balance": balance,
            "listing_pressure": pressure,
            "sales_7d": data.sales_7d,
            "listings": data.listings_count,
        },
        notes=notes,
    )
