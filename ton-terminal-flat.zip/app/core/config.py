"""Central application configuration.

Every secret is read from the environment (or a local, git-ignored ``.env``).
Nothing here is ever sent to the Mini App: the frontend only ever receives
values explicitly returned by API endpoints.
"""
from __future__ import annotations

from decimal import Decimal
from functools import lru_cache
from typing import Any, Literal

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.core.constants import (
    DEFAULT_MARKETPLACE_FEE_BPS,
    DEFAULT_NETWORK_FEE_TON,
    DEFAULT_ROYALTY_BPS,
    DEFAULT_SLIPPAGE,
    EXPLORERS,
    MAINNET,
    TESTNET,
    TONCENTER_BASE_URLS,
)

SECRET_FIELD_HINTS = (
    "token",
    "key",
    "secret",
    "password",
    "database_url",
    "redis_url",
    "dsn",
)


def _normalise_database_url(url: str) -> str:
    """Accept the URL formats PaaS providers hand out.

    Railway/Heroku give ``postgres://`` / ``postgresql://``; SQLAlchemy needs an
    explicit async driver, so we upgrade the scheme instead of failing at boot.
    """
    url = (url or "").strip()
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://") :]
    if url.startswith("postgresql://") and "+asyncpg" not in url:
        return "postgresql+asyncpg://" + url[len("postgresql://") :]
    if url.startswith("sqlite://") and "+aiosqlite" not in url:
        return "sqlite+aiosqlite://" + url[len("sqlite://") :]
    return url


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # -------------------------------------------------------------- general
    app_name: str = "TON NFT Trading Terminal"
    env: Literal["development", "staging", "production"] = "development"
    debug: bool = False
    log_level: str = "INFO"
    json_logs: bool = False
    # Dev mode relaxes Telegram WebApp authentication so the Mini App can be
    # opened from a normal browser. NEVER enable in production.
    dev_mode: bool = True

    # ------------------------------------------------------------- telegram
    telegram_bot_token: str | None = None
    use_webhook: bool = False
    telegram_webhook_url: str | None = None
    telegram_webhook_secret: str | None = None

    # ------------------------------------------------------------------ TON
    ton_network: Literal["mainnet", "testnet"] = TESTNET
    toncenter_api_key: str | None = None
    toncenter_base_url: str | None = None  # advanced override / self-hosted indexer
    ton_app_url: str | None = None  # public HTTPS URL of the Mini App

    # ------------------------------------------------------------- database
    # Postgres in production: postgresql+asyncpg://user:pass@host:5432/tonterminal
    # SQLite is supported for local development.
    database_url: str = "sqlite+aiosqlite:///./data/terminal.db"
    redis_url: str | None = None
    db_echo: bool = False

    # ------------------------------------------------------------- providers
    # Only providers that actually require a key declare one here.
    ston_api_key: str | None = None        # STON.fi DEX API: public, no key required
    dedust_api_key: str | None = None      # DeDust REST API: public, no key required
    marketplace_api_key: str | None = None  # reserved for official marketplace API access
    ton_api_key: str | None = None         # TonAPI (tonconsole.com) - optional, raises limits

    # Portals has no documented public API. Point this at an officially
    # provided endpoint once access is granted; until then the adapter reports
    # itself as unavailable instead of faking data.
    portals_api_base_url: str | None = None
    portals_endpoint_map: str | None = None  # JSON: {"listings":"/v1/listings", ...}

    # --------------------------------------------------------------- trading
    enable_real_trading: bool = False  # real-money execution kill switch
    enable_paper_trading: bool = True
    max_buy_price_ton: Decimal = Decimal("1000")
    default_slippage: Decimal = DEFAULT_SLIPPAGE
    max_slippage: Decimal = Decimal("0.05")
    quote_ttl_seconds: int = 30

    default_marketplace_fee_bps: int = DEFAULT_MARKETPLACE_FEE_BPS
    default_royalty_bps: int = DEFAULT_ROYALTY_BPS
    network_fee_estimate_ton: Decimal = DEFAULT_NETWORK_FEE_TON

    # --------------------------------------------------------------- scanner
    scanner_enabled: bool = False
    scanner_interval_seconds: int = 300
    scanner_batch_size: int = 50
    metadata_worker_enabled: bool = False
    portfolio_sync_interval_seconds: int = 600
    opportunity_replay_enabled: bool = True

    # ------------------------------------------------------------------ http
    http_timeout_seconds: float = 20.0
    http_max_retries: int = 3
    provider_cache_ttl_seconds: int = 60
    metadata_cache_ttl_seconds: int = 3600

    @field_validator("database_url", mode="before")
    @classmethod
    def _fix_database_url(cls, value: str) -> str:
        return _normalise_database_url(value) if isinstance(value, str) else value

    @model_validator(mode="after")
    def _apply_network_defaults(self) -> Settings:
        if not self.toncenter_base_url:
            self.toncenter_base_url = TONCENTER_BASE_URLS[self.ton_network]
        return self

    # ------------------------------------------------------------- helpers
    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @property
    def is_mainnet(self) -> bool:
        return self.ton_network == MAINNET

    @property
    def explorer_base(self) -> str:
        return EXPLORERS[self.ton_network]

    def explorer_tx_url(self, tx_hash: str) -> str:
        return f"{self.explorer_base}/transaction/{tx_hash}"

    def explorer_address_url(self, address: str) -> str:
        return f"{self.explorer_base}/{address}"

    def safe_dict(self) -> dict[str, Any]:
        """Settings with every secret redacted - safe for logs and /health."""
        out: dict[str, Any] = {}
        for name, value in self.model_dump().items():
            if value is None:
                out[name] = None
                continue
            if any(hint in name.lower() for hint in SECRET_FIELD_HINTS):
                out[name] = "***redacted***"
            else:
                out[name] = value
        return out

    def secret_values(self) -> list[str]:
        values: list[str] = []
        for name, value in self:
            if isinstance(value, str) and value and any(
                hint in name.lower() for hint in SECRET_FIELD_HINTS
            ):
                values.append(value)
        return values


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
