"""Structured logging with secret redaction.

Invariants:
* secrets (bot token, API keys, DSNs) never reach a log sink;
* upstream response bodies are logged at DEBUG and truncated.
"""
from __future__ import annotations

import json
import logging
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from typing import Any

from app.core.config import get_settings

_REDACTED = "***redacted***"
_TRUNCATE = 2000


class SecretRedactingFilter(logging.Filter):
    """Replaces known secret values in the formatted message with a mask."""

    def __init__(self, secrets: list[str] | None = None) -> None:
        super().__init__()
        self._secrets = [s for s in (secrets or []) if s and len(s) > 6]

    def add_secret(self, value: str | None) -> None:
        if value and len(value) > 6 and value not in self._secrets:
            self._secrets.append(value)

    def filter(self, record: logging.LogRecord) -> bool:
        if not self._secrets:
            return True
        try:
            message = record.getMessage()
        except Exception:  # pragma: no cover - defensive
            return True
        original = message
        for secret in self._secrets:
            if secret in message:
                message = message.replace(secret, _REDACTED)
        if message != original:
            record.msg = message
            record.args = ()
        return True


_REDACTOR = SecretRedactingFilter()


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key, value in getattr(record, "extra_fields", {}).items():
            payload[key] = value
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)[:_TRUNCATE]


class ConsoleFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        stamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
        extra = getattr(record, "extra_fields", {})
        suffix = " " + json.dumps(extra, default=str)[:500] if extra else ""
        base = f"{stamp} {record.levelname:<7} {record.name}: {record.getMessage()}{suffix}"
        if record.exc_info:
            base += "\n" + self.formatException(record.exc_info)
        return base


def configure_logging(level: str | None = None, json_logs: bool | None = None) -> None:
    cfg = get_settings()
    root = logging.getLogger()
    root.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter() if (json_logs or cfg.json_logs) else ConsoleFormatter())
    handler.addFilter(_REDACTOR)
    root.addHandler(handler)
    root.setLevel((level or cfg.log_level).upper())
    for noisy in ("httpx", "httpcore", "aiogram.event", "apscheduler.executors.default"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    register_secrets(cfg.secret_values())


def register_secrets(values: list[str] | None) -> None:
    for value in values or []:
        _REDACTOR.add_secret(value)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


@contextmanager
def log_context(**fields: Any) -> Iterator[None]:
    """Attach structured fields to every log record emitted in the block."""
    logger = logging.getLogger()
    old = getattr(logger, "_ctx_fields", {})
    logger._ctx_fields = {**old, **fields}  # type: ignore[attr-defined]
    try:
        yield
    finally:
        logger._ctx_fields = old  # type: ignore[attr-defined]


def truncate(value: str, size: int = _TRUNCATE) -> str:
    return value if len(value) <= size else value[:size] + "…[truncated]"
