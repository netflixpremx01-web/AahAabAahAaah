"""Rate limiting for outbound provider calls and inbound user actions."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field

from app.core.cache import get_cache
from app.core.errors import RateLimitExceeded
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class TokenBucket:
    """Simple asyncio token bucket (per process)."""

    rate: float  # tokens per second
    capacity: int
    tokens: float = field(init=False)
    updated: float = field(init=False)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)

    def __post_init__(self) -> None:
        self.tokens = float(self.capacity)
        self.updated = time.monotonic()

    async def acquire(self, tokens: float = 1.0) -> None:
        async with self.lock:
            while True:
                now = time.monotonic()
                self.tokens = min(
                    float(self.capacity), self.tokens + (now - self.updated) * self.rate
                )
                self.updated = now
                if self.tokens >= tokens:
                    self.tokens -= tokens
                    return
                await asyncio.sleep(max(0.01, (tokens - self.tokens) / self.rate))


class RateLimiter:
    """Named token-bucket limiter. Redis-backed counting when available."""

    def __init__(self, name: str, rate: float, capacity: int | None = None) -> None:
        self.name = name
        self.rate = rate
        self.capacity = capacity or max(1, int(rate))
        self._bucket = TokenBucket(rate=rate, capacity=self.capacity)

    async def acquire(self, tokens: float = 1.0) -> None:
        await self._bucket.acquire(tokens)

    async def check_user(self, key: str, limit: int, window: int) -> None:
        """Fixed-window user quota, raises :class:`RateLimitExceeded`."""
        cache = await get_cache()
        bucket_key = f"rl:{self.name}:{key}:{int(time.time()) // window}"
        count = await cache.incr(bucket_key, ttl=window)
        if count > limit:
            raise RateLimitExceeded(
                f"rate limit exceeded for {self.name}",
                key=key,
                limit=limit,
                window=window,
            )


# Provider limits. TON Center v3 allows 1 rps without an API key; with a key the
# tier is higher, so we stay conservative and configurable.
PROVIDER_LIMITS: dict[str, RateLimiter] = {
    "toncenter": RateLimiter("toncenter", rate=1.0 if True else 1.0, capacity=2),
    "stonfi": RateLimiter("stonfi", rate=4.0, capacity=8),
    "dedust": RateLimiter("dedust", rate=2.0, capacity=4),
    "tonapi": RateLimiter("tonapi", rate=0.2, capacity=1),
    "metadata": RateLimiter("metadata", rate=5.0, capacity=10),
}


def get_limiter(name: str) -> RateLimiter:
    return PROVIDER_LIMITS.setdefault(name, RateLimiter(name, rate=1.0, capacity=1))


async def respect_retry_after(retry_after: float | None) -> None:
    if retry_after and retry_after > 0:
        await asyncio.sleep(min(retry_after, 30))
