"""Money helpers used across every financial calculation.

Rules enforced here:

* all TON amounts are :class:`decimal.Decimal` (never float) internally;
* percentage points are expressed in *basis points* (1 bps = 0.01%);
* rounding is always explicit.
"""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from app.core.constants import NANO_PER_TON

TON_QUANTUM = Decimal("0.000000001")  # 1 nanoTON
CENT_QUANTUM = Decimal("0.01")


def to_decimal(value: Decimal | int | str | float | None, default: Decimal | None = None) -> Decimal | None:
    """Best effort conversion to Decimal. Returns ``default`` on bad input."""
    if value is None:
        return default
    if isinstance(value, Decimal):
        return value
    try:
        if isinstance(value, float):
            return Decimal(str(value))
        return Decimal(value)
    except (InvalidOperation, TypeError, ValueError):
        return default


def d(value: Decimal | int | str | float | None, default: Decimal = Decimal("0")) -> Decimal:
    """Convert to Decimal, falling back to ``default`` (never ``None``)."""
    return to_decimal(value, default) or default


def ton_from_nano(nano: int | str | None) -> Decimal:
    if nano is None:
        return Decimal("0")
    return (Decimal(str(nano)) / Decimal(NANO_PER_TON)).quantize(TON_QUANTUM)


def nano_from_ton(amount: Decimal | int | str | float | None) -> int:
    value = d(amount)
    return int((value * Decimal(NANO_PER_TON)).to_integral_value(rounding=ROUND_HALF_UP))


def quantize_ton(amount: Decimal | None) -> Decimal:
    return d(amount).quantize(TON_QUANTUM, rounding=ROUND_HALF_UP)


def apply_bps(amount: Decimal, bps: int | float | Decimal) -> Decimal:
    """Return ``amount`` after applying a fee expressed in basis points."""
    value = d(amount)
    return (value * d(bps) / Decimal(10_000)).quantize(TON_QUANTUM, rounding=ROUND_HALF_UP)


def add_bps(amount: Decimal, bps: int) -> Decimal:
    return quantize_ton(d(amount) + apply_bps(amount, bps))


def subtract_bps(amount: Decimal, bps: int) -> Decimal:
    return quantize_ton(d(amount) - apply_bps(amount, bps))


def pct(numerator: Decimal | None, denominator: Decimal | None) -> Decimal:
    """Percentage of ``numerator`` relative to ``denominator`` (0 when undefined)."""
    num, den = d(numerator), d(denominator)
    if den == 0:
        return Decimal("0")
    return ((num / den) * Decimal(100)).quantize(CENT_QUANTUM, rounding=ROUND_HALF_UP)


def clamp(value: Decimal, low: Decimal, high: Decimal) -> Decimal:
    return max(low, min(high, value))


def safe_div(numerator: Decimal, denominator: Decimal, default: Decimal = Decimal("0")) -> Decimal:
    if denominator == 0:
        return default
    return numerator / denominator


def median(values: list[Decimal]) -> Decimal | None:
    if not values:
        return None
    ordered = sorted(values)
    size = len(ordered)
    mid = size // 2
    if size % 2 == 1:
        return ordered[mid]
    return ((ordered[mid - 1] + ordered[mid]) / Decimal(2)).quantize(TON_QUANTUM)


def mean(values: list[Decimal]) -> Decimal | None:
    if not values:
        return None
    total = sum(values, Decimal("0"))
    return (total / Decimal(len(values))).quantize(TON_QUANTUM)


def positive(value: Decimal | None) -> Decimal | None:
    """Return the value when strictly positive, otherwise ``None``."""
    if value is None or value <= 0:
        return None
    return value


def format_ton(amount: Decimal | None, places: int = 2) -> str:
    if amount is None:
        return "—"
    q = Decimal(1).scaleb(-places)
    return f"{d(amount).quantize(q, rounding=ROUND_HALF_UP):,}"
