"""Shared HTTP client with retries, backoff, rate limiting and redaction.

No secret is ever logged: headers are filtered before a request is traced.
"""
from __future__ import annotations

import asyncio
import random
from collections.abc import Mapping
from typing import Any

import httpx

from app.core.config import get_settings
from app.core.errors import (
    NotFoundError,
    ProviderError,
    UpstreamRateLimited,
    UpstreamTimeout,
)
from app.core.logging import get_logger, truncate
from app.core.ratelimit import get_limiter

logger = get_logger(__name__)

SENSITIVE_HEADERS = {"x-api-key", "authorization", "api-key", "x-auth-token"}


def sanitize_headers(headers: Mapping[str, str] | None) -> dict[str, str]:
    if not headers:
        return {}
    return {
        key: ("***redacted***" if key.lower() in SENSITIVE_HEADERS else value)
        for key, value in headers.items()
    }


class HttpClient:
    """Thin, opinionated wrapper around :class:`httpx.AsyncClient`."""

    def __init__(
        self,
        base_url: str = "",
        *,
        headers: Mapping[str, str] | None = None,
        limiter_name: str | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
    ) -> None:
        settings = get_settings()
        self.base_url = base_url.rstrip("/")
        self.headers = dict(headers or {})
        self.limiter_name = limiter_name
        self.timeout = timeout or settings.http_timeout_seconds
        self.max_retries = max_retries if max_retries is not None else settings.http_max_retries
        self._client: httpx.AsyncClient | None = None

    # ------------------------------------------------------------ lifecycle
    async def _ensure(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self.headers,
                timeout=self.timeout,
                follow_redirects=True,
                limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
            )
        return self._client

    async def aclose(self) -> None:
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()

    # --------------------------------------------------------------- helpers
    async def _before(self) -> None:
        if self.limiter_name:
            await get_limiter(self.limiter_name).acquire()

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json_body: Any | None = None,
        data: Any | None = None,
        headers: Mapping[str, str] | None = None,
        retry_on_status: tuple[int, ...] = (429, 500, 502, 503, 504),
        raw: bool = False,
    ) -> Any:
        client = await self._ensure()
        last_error: Exception | None = None
        for attempt in range(self.max_retries + 1):
            await self._before()
            try:
                response = await client.request(
                    method,
                    path,
                    params={k: v for k, v in (params or {}).items() if v is not None},
                    json=json_body,
                    data=data,
                    headers=headers,
                )
            except httpx.TimeoutException as exc:
                last_error = exc
                logger.warning(
                    "http timeout",
                    extra={"extra_fields": {"url": path, "attempt": attempt}},
                )
                if attempt >= self.max_retries:
                    raise UpstreamTimeout(f"timeout calling {path}") from exc
                await asyncio.sleep(self._backoff(attempt))
                continue
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    raise ProviderError(f"network error calling {path}: {exc}") from exc
                await asyncio.sleep(self._backoff(attempt))
                continue

            if response.status_code in retry_on_status and attempt < self.max_retries:
                delay = float(response.headers.get("retry-after") or self._backoff(attempt))
                logger.warning(
                    "http retry",
                    extra={
                        "extra_fields": {
                            "url": path,
                            "status": response.status_code,
                            "attempt": attempt,
                        }
                    },
                )
                await asyncio.sleep(min(delay, 30))
                continue

            logger.debug(
                "http response",
                extra={
                    "extra_fields": {
                        "url": path,
                        "status": response.status_code,
                        "headers": sanitize_headers(dict(response.headers)),
                        "body": truncate(response.text),
                    }
                },
            )

            if response.status_code == 404:
                raise NotFoundError(f"{path} not found")
            if response.status_code == 429:
                raise UpstreamRateLimited(f"rate limited by {path}")
            if response.status_code >= 500:
                raise ProviderError(
                    f"upstream {response.status_code} on {path}: {truncate(response.text, 300)}"
                )
            if response.status_code >= 400:
                raise ProviderError(
                    f"upstream {response.status_code} on {path}: {truncate(response.text, 300)}"
                )
            if raw:
                return response
            if not response.content:
                return {}
            try:
                return response.json()
            except ValueError:
                return response.text

        raise ProviderError(f"request to {path} failed: {last_error}")

    @staticmethod
    def _backoff(attempt: int, base: float = 0.5, cap: float = 8.0) -> float:
        """Exponential backoff with full jitter."""
        return random.uniform(0, min(cap, base * (2**attempt)))

    async def get(self, path: str, **kwargs: Any) -> Any:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> Any:
        return await self.request("POST", path, **kwargs)
