"""Cache abstraction: Redis in production, in-process memory as fallback.

Redis is used for *ephemeral* data only (API responses, quotes, locks,
dedupe keys). PostgreSQL remains the permanent financial database.
"""
from __future__ import annotations

import json
import time
from typing import Any, Protocol

from app.core.config import get_settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class CacheBackend(Protocol):
    async def get(self, key: str) -> Any | None: ...
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None: ...
    async def delete(self, key: str) -> None: ...
    async def incr(self, key: str, ttl: int | None = None) -> int: ...
    async def close(self) -> None: ...
    async def lock(self, key: str, ttl: int = 60) -> bool:
        """Best-effort distributed lock. Returns True when acquired."""


class MemoryCache:
    """Single-process TTL cache. Used for tests and local development."""

    def __init__(self) -> None:
        self._data: dict[str, tuple[float, str]] = {}

    async def get(self, key: str) -> Any | None:
        item = self._data.get(key)
        if not item:
            return None
        expires_at, raw = item
        if expires_at and expires_at < time.time():
            self._data.pop(key, None)
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        expires = time.time() + ttl if ttl else 0
        self._data[key] = (expires, json.dumps(value, default=str))

    async def delete(self, key: str) -> None:
        self._data.pop(key, None)

    async def incr(self, key: str, ttl: int | None = None) -> int:
        current = int(await self.get(key) or 0) + 1
        await self.set(key, current, ttl)
        return current

    async def close(self) -> None:
        self._data.clear()

    async def lock(self, key: str, ttl: int = 60) -> bool:
        # Atomicity is not required for the single-process fallback.
        if await self.get(f"lock:{key}"):
            return False
        await self.set(f"lock:{key}", int(time.time()), ttl)
        return True


class RedisCache:
    """Redis-backed cache. Falls back to a no-op on connection failures."""

    def __init__(self, url: str) -> None:
        self.url = url
        self._client: Any = None
        self._available = True

    def _redis(self) -> Any:
        if self._client is None:
            import redis.asyncio as aioredis  # imported lazily: optional dependency

            self._client = aioredis.from_url(self.url, decode_responses=True)
        return self._client

    async def get(self, key: str) -> Any | None:
        try:
            raw = await self._redis().get(key)
        except Exception as exc:  # pragma: no cover - network dependent
            self._available = False
            logger.warning("redis.get failed", extra={"extra_fields": {"error": str(exc)}})
            return None
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return raw

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        try:
            await self._redis().set(key, json.dumps(value, default=str), ex=ttl)
        except Exception as exc:  # pragma: no cover
            self._available = False
            logger.warning("redis.set failed", extra={"extra_fields": {"error": str(exc)}})

    async def delete(self, key: str) -> None:
        try:
            await self._redis().delete(key)
        except Exception:  # pragma: no cover
            pass

    async def incr(self, key: str, ttl: int | None = None) -> int:
        try:
            pipe = self._redis().pipeline()
            pipe.incr(key)
            if ttl:
                pipe.expire(key, ttl)
            result = await pipe.execute()
            return int(result[0])
        except Exception:  # pragma: no cover
            return 1

    async def close(self) -> None:
        if self._client is not None:
            try:
                await self._client.aclose()
            except Exception:  # pragma: no cover
                pass

    async def lock(self, key: str, ttl: int = 60) -> bool:
        try:
            return bool(await self._redis().set(f"lock:{key}", "1", nx=True, ex=ttl))
        except Exception:  # pragma: no cover
            return True


_backend: CacheBackend | None = None


async def get_cache() -> CacheBackend:
    global _backend
    if _backend is None:
        settings = get_settings()
        if settings.redis_url:
            candidate = RedisCache(settings.redis_url)
            try:
                await candidate.get("__probe__")
                _backend = candidate
            except Exception:  # pragma: no cover
                logger.warning("Redis unreachable, using in-memory cache")
                _backend = MemoryCache()
        else:
            _backend = MemoryCache()
    return _backend


async def cached(key: str, ttl: int, producer) -> Any:
    """Return a cached value or compute+store it (cache-aside)."""
    cache = await get_cache()
    hit = await cache.get(key)
    if hit is not None:
        return hit
    value = await producer() if callable(producer) else await producer
    if value is not None:
        await cache.set(key, value, ttl)
    return value
