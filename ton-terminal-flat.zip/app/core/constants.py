"""Constants that are safe to hardcode: public network addresses and URLs.

Only *public* values live here. Secrets are never hardcoded - they are loaded
from the environment (see :mod:`app.core.config`).
"""
from __future__ import annotations

from decimal import Decimal

# ---------------------------------------------------------------------------
# Networks
# ---------------------------------------------------------------------------
MAINNET = "mainnet"
TESTNET = "testnet"

TONCENTER_BASE_URLS: dict[str, str] = {
    MAINNET: "https://toncenter.com/api/v3",
    TESTNET: "https://testnet.toncenter.com/api/v3",
}

EXPLORERS: dict[str, str] = {
    MAINNET: "https://tonviewer.com",
    TESTNET: "https://testnet.tonviewer.com",
}

# ---------------------------------------------------------------------------
# Well known assets (public contract addresses)
# ---------------------------------------------------------------------------
# STON.fi uses a dedicated pseudo-address to represent native TON in its API.
STONFI_NATIVE_TON = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"

USDT_MASTER: dict[str, str] = {
    # Tether USD (jetton master) - public, well known addresses.
    MAINNET: "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs",
    TESTNET: "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs",  # not deployed on testnet
}

# Marketplace addresses observed in indexed ``nft_purchase`` actions. Used only
# to label provenance of a sale; the raw address is always stored alongside.
KNOWN_MARKETPLACES: dict[str, str] = {
    "0:584ee61b2dff0837116d0fcb5078d93964bcbe9c05fd6a141b1bfca5d6a43e18": "getgems",
}

# ---------------------------------------------------------------------------
# Units / economics
# ---------------------------------------------------------------------------
NANO_PER_TON = 1_000_000_000
BPS_DENOM = Decimal(10_000)

# Conservative defaults. Real values are always fetched from the provider when
# available (marketplace fee %, royalties, gas estimation).
DEFAULT_MARKETPLACE_FEE_BPS = 500          # 5.00%
DEFAULT_ROYALTY_BPS = 500                  # 5.00%
DEFAULT_NETWORK_FEE_TON = Decimal("0.05")  # gas + storage, indicative only
DEFAULT_SLIPPAGE = Decimal("0.01")         # 1%
QUOTE_TTL_SECONDS = 30

# ---------------------------------------------------------------------------
# Scanner defaults
# ---------------------------------------------------------------------------
DEFAULT_SCAN_LIMIT = 50
MAX_SCAN_LIMIT = 1000
