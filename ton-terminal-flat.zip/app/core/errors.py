"""Application error hierarchy.

Errors are grouped so that the API layer can translate them into stable HTTP
status codes and the bot layer can translate them into user friendly messages.
"""
from __future__ import annotations

from typing import Any


class AppError(Exception):
    """Base class for every expected application error."""

    http_status = 400
    user_message = "Something went wrong. Please try again."

    def __init__(self, message: str | None = None, **context: Any) -> None:
        self.message = message or self.user_message
        self.context = context
        super().__init__(self.message)


class ValidationError(AppError):
    http_status = 422
    user_message = "The request is not valid."


class NotFoundError(AppError):
    http_status = 404
    user_message = "Not found."


class AuthenticationError(AppError):
    http_status = 401
    user_message = "Authentication failed."


class PermissionDenied(AppError):
    http_status = 403
    user_message = "You are not allowed to do this."


class RateLimitExceeded(AppError):
    http_status = 429
    user_message = "Too many requests, please slow down."


# ---------------------------------------------------------------------------
# Provider / integration errors
# ---------------------------------------------------------------------------
class ProviderError(AppError):
    """Base class for failures coming from an external data provider."""

    http_status = 502
    user_message = "An external data provider failed. Please retry shortly."


class ProviderNotConfigured(ProviderError):
    """The provider is not configured (missing API key/base URL)."""

    http_status = 503
    user_message = (
        "This feature is not configured yet. "
        "An API key from the provider is required."
    )


class ProviderUnavailable(ProviderError):
    """The provider exists but has no public API for the requested capability."""

    http_status = 501
    user_message = (
        "This feature is not available: the provider does not expose a public API "
        "for it. The adapter is in place and activates once official access exists."
    )


class CapabilityNotSupported(ProviderUnavailable):
    """Raised by an adapter method that the provider cannot serve."""


class UpstreamRateLimited(ProviderError):
    http_status = 429
    user_message = "The data provider rate limited us. Please retry in a moment."


class UpstreamTimeout(ProviderError):
    http_status = 504
    user_message = "The data provider timed out."


# ---------------------------------------------------------------------------
# Domain errors
# ---------------------------------------------------------------------------
class TradingDisabled(AppError):
    http_status = 403
    user_message = (
        "Real trading is disabled on this deployment. "
        "Use Paper Mode or enable real trading in the configuration."
    )


class QuoteExpired(AppError):
    http_status = 409
    user_message = "The quote expired. Please request a fresh quote."


class QuoteNotFound(AppError):
    http_status = 404
    user_message = "Quote not found or expired."


class WalletNotConnected(AppError):
    http_status = 409
    user_message = "Connect a wallet first."


class TransactionNotFound(AppError):
    http_status = 404
    user_message = "Transaction not found on chain yet."
