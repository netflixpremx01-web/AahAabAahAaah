"""SQLAlchemy ORM models.

Tables: users, wallets, collections, nfts, nft_traits, marketplace_listings,
sales, transactions, watchlists, strategies, opportunities, opportunity_history,
paper_trades, portfolio_positions, swap_quotes, swap_transactions,
notifications, api_cache.

Amounts are stored as ``Numeric(30, 9)`` (TON) and ``BigInteger`` (nanoTON) to
avoid floating point drift in financial calculations.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin, utcnow
from app.models.enums import (
    DexProvider,
    Marketplace,
    MetadataStatus,
    Network,
    NotificationCategory,
    NotificationStatus,
    OpportunityStatus,
    PortfolioSource,
    RiskLevel,
    StrategyMode,
    TradeSide,
    TxStatus,
    WatchCondition,
    WatchTarget,
)

AMOUNT = Numeric(30, 9)


class User(TimestampMixin, Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True, nullable=False)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    last_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    language_code: Mapped[str | None] = mapped_column(String(8), nullable=True)
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    photo_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    paper_balance_ton: Mapped[object] = mapped_column(AMOUNT, default=100, nullable=False)
    notification_prefs: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    ui_prefs: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    wallets: Mapped[list[Wallet]] = relationship(back_populates="user", cascade="all,delete-orphan")


class Wallet(Base):
    __tablename__ = "wallets"
    __table_args__ = (UniqueConstraint("user_id", "address", name="uq_wallets_user_address"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    address: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    network: Mapped[str] = mapped_column(String(16), default=Network.TESTNET.value, nullable=False)
    wallet_app: Mapped[str | None] = mapped_column(String(64), nullable=True)
    public_key: Mapped[str | None] = mapped_column(String(128), nullable=True)
    is_primary: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    balance_ton: Mapped[object] = mapped_column(AMOUNT, default=0, nullable=False)
    last_synced_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)

    user: Mapped[User] = relationship(back_populates="wallets")


class Collection(TimestampMixin, Base):
    __tablename__ = "collections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    address: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    network: Mapped[str] = mapped_column(String(16), default=Network.TESTNET.value, nullable=False)
    name: Mapped[str | None] = mapped_column(String(256), nullable=True)
    symbol: Mapped[str | None] = mapped_column(String(64), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    image_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    item_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    floor_price_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    floor_updated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    volume_24h_ton: Mapped[object] = mapped_column(AMOUNT, default=0, nullable=False)
    volume_7d_ton: Mapped[object] = mapped_column(AMOUNT, default=0, nullable=False)
    sales_24h: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    listings_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    unique_buyers_24h: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    health_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    trend: Mapped[str | None] = mapped_column(String(16), nullable=True)
    liquidity_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    monitored: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    stats: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    metadata_status: Mapped[str] = mapped_column(
        String(16), default=MetadataStatus.PENDING.value, nullable=False
    )


class NFT(TimestampMixin, Base):
    __tablename__ = "nfts"
    __table_args__ = (Index("ix_nfts_collection_index", "collection_id", "index"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    address: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    network: Mapped[str] = mapped_column(String(16), default=Network.TESTNET.value, nullable=False)
    collection_id: Mapped[int | None] = mapped_column(
        ForeignKey("collections.id", ondelete="SET NULL"), index=True
    )
    index: Mapped[str | None] = mapped_column(String(64), nullable=True)
    name: Mapped[str | None] = mapped_column(String(256), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    image_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    attributes: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    number_value: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    rarity_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    rarity_rank: Mapped[int | None] = mapped_column(Integer, nullable=True)
    rarity_percentile: Mapped[object | None] = mapped_column(Numeric(8, 4), nullable=True)
    owner_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    last_sale_price_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    last_sale_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    metadata_status: Mapped[str] = mapped_column(
        String(16), default=MetadataStatus.PENDING.value, nullable=False
    )
    metadata_fetched_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    metadata_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    collection: Mapped[Collection | None] = relationship(back_populates="nfts")
    traits: Mapped[list[NFTTrait]] = relationship(
        back_populates="nft", cascade="all,delete-orphan"
    )


Collection.nfts = relationship("NFT", back_populates="collection", cascade="all,delete-orphan")


class NFTTrait(Base):
    __tablename__ = "nft_traits"
    __table_args__ = (UniqueConstraint("nft_id", "trait_type", name="uq_nft_traits_nft_type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    nft_id: Mapped[int] = mapped_column(ForeignKey("nfts.id", ondelete="CASCADE"), index=True)
    trait_type: Mapped[str] = mapped_column(String(128), nullable=False)
    trait_value: Mapped[str | None] = mapped_column(String(512), nullable=True)
    rarity_pct: Mapped[object | None] = mapped_column(Numeric(8, 4), nullable=True)
    trait_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    numeric_value: Mapped[object | None] = mapped_column(Numeric(30, 9), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)

    nft: Mapped[NFT] = relationship(back_populates="traits")


class MarketplaceListing(TimestampMixin, Base):
    __tablename__ = "marketplace_listings"
    __table_args__ = (
        UniqueConstraint("marketplace", "listing_id", name="uq_listings_marketplace_id"),
        Index("ix_listings_collection_active", "collection_id", "is_active"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    marketplace: Mapped[str] = mapped_column(String(32), default=Marketplace.UNKNOWN.value)
    listing_id: Mapped[str] = mapped_column(String(128), nullable=False)
    nft_id: Mapped[int | None] = mapped_column(ForeignKey("nfts.id", ondelete="CASCADE"), index=True)
    collection_id: Mapped[int | None] = mapped_column(
        ForeignKey("collections.id", ondelete="SET NULL"), index=True
    )
    seller_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    price_ton: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    price_nano: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    currency: Mapped[str] = mapped_column(String(16), default="TON", nullable=False)
    marketplace_fee_bps: Mapped[int] = mapped_column(Integer, default=500, nullable=False)
    royalty_bps: Mapped[int] = mapped_column(Integer, default=500, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    raw: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)

    nft: Mapped[NFT | None] = relationship()
    collection: Mapped[Collection | None] = relationship()


class Sale(TimestampMixin, Base):
    __tablename__ = "sales"
    __table_args__ = (
        UniqueConstraint("marketplace", "sale_id", name="uq_sales_marketplace_id"),
        Index("ix_sales_collection_time", "collection_id", "sold_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    marketplace: Mapped[str] = mapped_column(String(32), default=Marketplace.UNKNOWN.value)
    sale_id: Mapped[str] = mapped_column(String(128), nullable=False)
    nft_id: Mapped[int | None] = mapped_column(ForeignKey("nfts.id", ondelete="CASCADE"), index=True)
    collection_id: Mapped[int | None] = mapped_column(
        ForeignKey("collections.id", ondelete="SET NULL"), index=True
    )
    seller_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    buyer_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    price_ton: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    price_nano: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    currency: Mapped[str] = mapped_column(String(16), default="TON", nullable=False)
    sold_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False, index=True)
    tx_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    raw: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)

    nft: Mapped[NFT | None] = relationship()
    collection: Mapped[Collection | None] = relationship()


class Transaction(TimestampMixin, Base):
    __tablename__ = "transactions"
    __table_args__ = (Index("ix_transactions_user_kind", "user_id", "kind"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    wallet_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    network: Mapped[str] = mapped_column(String(16), default=Network.TESTNET.value, nullable=False)
    kind: Mapped[str] = mapped_column(String(24), nullable=False)
    status: Mapped[str] = mapped_column(String(16), default=TxStatus.PENDING.value, nullable=False)
    provider: Mapped[str | None] = mapped_column(String(32), nullable=True)
    subject_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    tx_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    trace_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    lt: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    amount_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    fee_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)


class Watchlist(TimestampMixin, Base):
    __tablename__ = "watchlists"
    __table_args__ = (Index("ix_watchlists_user_active", "user_id", "is_active"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    target_type: Mapped[str] = mapped_column(String(16), default=WatchTarget.NFT.value, nullable=False)
    target_ref: Mapped[str] = mapped_column(String(128), nullable=False)
    label: Mapped[str | None] = mapped_column(String(256), nullable=True)
    condition: Mapped[str] = mapped_column(
        String(24), default=WatchCondition.PRICE_BELOW.value, nullable=False
    )
    threshold: Mapped[object | None] = mapped_column(Numeric(30, 9), nullable=True)
    extra: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    trigger_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_triggered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class Strategy(TimestampMixin, Base):
    __tablename__ = "strategies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    mode: Mapped[str] = mapped_column(String(16), default=StrategyMode.ALERT.value, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    rules: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    stats: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)


class Opportunity(TimestampMixin, Base):
    __tablename__ = "opportunities"
    __table_args__ = (Index("ix_opportunities_score", "opportunity_score", "detected_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    nft_id: Mapped[int | None] = mapped_column(ForeignKey("nfts.id", ondelete="CASCADE"), index=True)
    collection_id: Mapped[int | None] = mapped_column(
        ForeignKey("collections.id", ondelete="SET NULL"), index=True
    )
    marketplace: Mapped[str] = mapped_column(String(32), default=Marketplace.UNKNOWN.value)
    listing_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    listed_price_ton: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    fair_value_low: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    fair_value_high: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    discount_pct: Mapped[object | None] = mapped_column(Numeric(8, 2), nullable=True)
    rarity_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    number_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    liquidity_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    confidence: Mapped[int | None] = mapped_column(Integer, nullable=True)
    roi_pct: Mapped[object | None] = mapped_column(Numeric(8, 2), nullable=True)
    estimated_costs_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    theoretical_profit_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    risk_level: Mapped[str] = mapped_column(String(16), default=RiskLevel.MEDIUM.value)
    opportunity_score: Mapped[int] = mapped_column(Integer, default=0, nullable=False, index=True)
    reasons: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    status: Mapped[str] = mapped_column(
        String(16), default=OpportunityStatus.OPEN.value, nullable=False
    )
    detected_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False, index=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    nft: Mapped[NFT | None] = relationship()
    collection: Mapped[Collection | None] = relationship()


class OpportunityHistory(Base):
    __tablename__ = "opportunity_history"
    __table_args__ = (
        UniqueConstraint("opportunity_id", "horizon_hours", name="uq_opp_history_horizon"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    opportunity_id: Mapped[int] = mapped_column(
        ForeignKey("opportunities.id", ondelete="CASCADE"), index=True
    )
    horizon_hours: Mapped[int] = mapped_column(Integer, nullable=False)
    observed_price_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    observed_floor_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    theoretical_result_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    actual_outcome: Mapped[str | None] = mapped_column(String(32), nullable=True)
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class PaperTrade(TimestampMixin, Base):
    __tablename__ = "paper_trades"
    __table_args__ = (Index("ix_paper_trades_user_status", "user_id", "status"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    strategy_id: Mapped[int | None] = mapped_column(
        ForeignKey("strategies.id", ondelete="SET NULL"), index=True
    )
    nft_id: Mapped[int | None] = mapped_column(ForeignKey("nfts.id", ondelete="SET NULL"), index=True)
    collection_id: Mapped[int | None] = mapped_column(
        ForeignKey("collections.id", ondelete="SET NULL"), index=True
    )
    side: Mapped[str] = mapped_column(String(8), default=TradeSide.BUY.value, nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="open", nullable=False)
    entry_price_ton: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    exit_price_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    quantity: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    fees_ton: Mapped[object] = mapped_column(AMOUNT, default=0, nullable=False)
    pnl_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    pnl_pct: Mapped[object | None] = mapped_column(Numeric(8, 2), nullable=True)
    opened_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    nft: Mapped[NFT | None] = relationship()
    collection: Mapped[Collection | None] = relationship()
    strategy: Mapped[Strategy | None] = relationship()


class PortfolioPosition(TimestampMixin, Base):
    __tablename__ = "portfolio_positions"
    __table_args__ = (UniqueConstraint("user_id", "nft_id", name="uq_positions_user_nft"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    wallet_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    nft_id: Mapped[int | None] = mapped_column(ForeignKey("nfts.id", ondelete="CASCADE"), index=True)
    collection_id: Mapped[int | None] = mapped_column(
        ForeignKey("collections.id", ondelete="SET NULL"), index=True
    )
    quantity: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    avg_entry_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    last_price_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    floor_ton: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    unrealized_pnl_ton: Mapped[object] = mapped_column(AMOUNT, default=0, nullable=False)
    realized_pnl_ton: Mapped[object] = mapped_column(AMOUNT, default=0, nullable=False)
    source: Mapped[str] = mapped_column(
        String(16), default=PortfolioSource.CHAIN.value, nullable=False
    )
    acquired_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_updated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    nft: Mapped[NFT | None] = relationship()
    collection: Mapped[Collection | None] = relationship()


class SwapQuote(TimestampMixin, Base):
    __tablename__ = "swap_quotes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    provider: Mapped[str] = mapped_column(String(16), default=DexProvider.STONFI.value, nullable=False)
    from_token: Mapped[str] = mapped_column(String(64), nullable=False)
    to_token: Mapped[str] = mapped_column(String(64), nullable=False)
    from_amount: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    to_amount: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    min_received: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    rate: Mapped[object] = mapped_column(Numeric(30, 9), nullable=False)
    price_impact: Mapped[object] = mapped_column(Numeric(12, 8), default=0, nullable=False)
    network_fee_ton: Mapped[object] = mapped_column(AMOUNT, default=0, nullable=False)
    route: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    slippage: Mapped[object] = mapped_column(Numeric(8, 6), default=0.01, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="active", nullable=False)


class SwapTransaction(TimestampMixin, Base):
    __tablename__ = "swap_transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    quote_id: Mapped[int | None] = mapped_column(
        ForeignKey("swap_quotes.id", ondelete="SET NULL"), index=True
    )
    wallet_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    tx_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(16), default=TxStatus.PENDING.value, nullable=False)
    provider: Mapped[str] = mapped_column(String(16), default=DexProvider.STONFI.value, nullable=False)
    from_token: Mapped[str] = mapped_column(String(64), nullable=False)
    to_token: Mapped[str] = mapped_column(String(64), nullable=False)
    from_amount: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    expected_amount: Mapped[object] = mapped_column(AMOUNT, nullable=False)
    actual_amount: Mapped[object | None] = mapped_column(AMOUNT, nullable=True)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)


class Notification(TimestampMixin, Base):
    __tablename__ = "notifications"
    __table_args__ = (Index("ix_notifications_dedupe", "dedupe_key"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    category: Mapped[str] = mapped_column(
        String(24), default=NotificationCategory.SYSTEM.value, nullable=False
    )
    title: Mapped[str] = mapped_column(String(256), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    dedupe_key: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    status: Mapped[str] = mapped_column(
        String(16), default=NotificationStatus.PENDING.value, nullable=False
    )
    sent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    read_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)


class ApiCache(Base):
    __tablename__ = "api_cache"

    key: Mapped[str] = mapped_column(String(256), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    provider: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
