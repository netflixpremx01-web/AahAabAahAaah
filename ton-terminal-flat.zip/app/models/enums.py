"""Enumerations shared by the ORM, services and API schemas."""
from __future__ import annotations

from enum import StrEnum as _NativeStrEnum


# Python 3.11+ native StrEnum already stringifies to its value.
class StrEnum(_NativeStrEnum):  # type: ignore[no-redef]
    pass


class Network(StrEnum):
    MAINNET = "mainnet"
    TESTNET = "testnet"


class RiskLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    EXTREME = "extreme"


class Trend(StrEnum):
    BULLISH = "bullish"
    BEARISH = "bearish"
    FLAT = "flat"
    VOLATILE = "volatile"


class TxKind(StrEnum):
    BUY = "buy"
    SELL = "sell"
    LISTING = "listing"
    CANCEL_LISTING = "cancel_listing"
    SWAP = "swap"
    TRANSFER = "transfer"


class TxStatus(StrEnum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    FAILED = "failed"
    EXPIRED = "expired"


class Marketplace(StrEnum):
    GETGEMS = "getgems"
    PORTALS = "portals"
    TONAPI = "tonapi"      # read-only indexer adapter
    UNKNOWN = "unknown"


class DexProvider(StrEnum):
    STONFI = "stonfi"
    DEDUST = "dedust"


class WatchTarget(StrEnum):
    COLLECTION = "collection"
    NFT = "nft"
    TRAIT = "trait"
    NUMBER = "number"
    PRICE = "price"


class WatchCondition(StrEnum):
    PRICE_BELOW = "price_below"
    PRICE_ABOVE = "price_above"
    DISCOUNT_ABOVE = "discount_above"
    FLOOR_BELOW = "floor_below"
    FLOOR_ABOVE = "floor_above"


class StrategyMode(StrEnum):
    ALERT = "alert"       # notify only
    PAPER = "paper"       # simulate fills
    ASSISTED = "assisted"  # build tx, always requires wallet approval


class NotificationCategory(StrEnum):
    OPPORTUNITY = "opportunity"
    PURCHASE = "purchase"
    SALE = "sale"
    LISTING = "listing"
    SWAP = "swap"
    FLOOR = "floor"
    WHALE = "whale"
    ANOMALY = "anomaly"
    WATCHLIST = "watchlist"
    PORTFOLIO = "portfolio"
    SYSTEM = "system"


class NotificationStatus(StrEnum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    SKIPPED = "skipped"


class MetadataStatus(StrEnum):
    PENDING = "pending"
    OK = "ok"
    PARTIAL = "partial"
    FAILED = "failed"


class OpportunityStatus(StrEnum):
    OPEN = "open"
    EXPIRED = "expired"
    TAKEN = "taken"
    RESOLVED = "resolved"


class TradeSide(StrEnum):
    BUY = "buy"
    SELL = "sell"


class PortfolioSource(StrEnum):
    CHAIN = "chain"
    DERIVED = "derived"
    MANUAL = "manual"
