"""NFT Market Radar: scan, score and persist opportunities.

Pipeline::

    listings -> metadata -> rarity/number -> fair value -> liquidity
             -> costs -> opportunity score -> persist -> notify

Everything labelled "theoretical" is a model output, never a promise.
"""
from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.core.money import d
from app.models.enums import MetadataStatus, OpportunityStatus
from app.models.orm import NFT, Collection, MarketplaceListing, Opportunity, OpportunityHistory
from app.nft.analyzer import MarketSnapshot, analyse_nft, finalise_analysis
from app.nft.metadata import NFTMetadataService, ResolvedMetadata
from app.radar.replay import HORIZONS, replay_opportunity, replay_summary
from app.services.market import MarketService

logger = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class OpportunityService:
    def __init__(
        self,
        session: AsyncSession,
        *,
        market: MarketService | None = None,
        metadata: NFTMetadataService | None = None,
    ) -> None:
        self.session = session
        self.market = market or MarketService(session)
        self.metadata = metadata or self.market.metadata

    # ------------------------------------------------------------- scanning
    async def scan_collection(
        self, collection_address: str, *, min_score: int = 0, limit: int = 25
    ) -> list[Opportunity]:
        await self.market.sync_listings(collection_address)
        await self.market.sync_sales(collection_address)
        await self.market.refresh_collection_stats(collection_address)
        snapshot = await self.market.build_snapshot(collection_address)
        traits = await self.market.collection_traits(collection_address)

        listings = await self.market.active_listings(collection_address, limit=limit)
        opportunities: list[Opportunity] = []
        for listing in listings:
            try:
                opportunity = await self._evaluate_listing(listing, snapshot, traits)
            except Exception as exc:  # one bad NFT must not break the scan
                logger.warning(
                    "listing evaluation failed",
                    extra={"extra_fields": {"listing": listing.listing_id, "error": str(exc)}},
                )
                continue
            if opportunity and opportunity.opportunity_score >= min_score:
                opportunities.append(opportunity)
        opportunities.sort(key=lambda o: o.opportunity_score, reverse=True)
        return opportunities

    async def _evaluate_listing(
        self,
        listing: MarketplaceListing,
        snapshot: MarketSnapshot,
        traits: list[dict],
    ) -> Opportunity | None:
        if not listing.nft_id:
            return None
        if listing.price_ton is None or d(listing.price_ton) <= 0:
            # A listing without a positive price cannot be scored meaningfully.
            return None
        nft = await self.session.get(NFT, listing.nft_id)
        if nft is None:
            return None
        metadata = await self._metadata_for(nft)
        snapshot.collection_size = snapshot.collection_size or 0
        analysis = analyse_nft(metadata, snapshot, collection_traits=traits)
        finalise_analysis(analysis, listing_price=listing.price_ton)
        return await self._persist(analysis, listing, nft)

    async def _metadata_for(self, nft: NFT) -> ResolvedMetadata:
        if nft.metadata_status == MetadataStatus.OK.value and nft.name:
            return ResolvedMetadata(
                address=nft.address,
                index=nft.index,
                name=nft.name,
                description=nft.description,
                image_url=nft.image_url,
                metadata_url=nft.metadata_url,
                attributes=dict(nft.attributes or {}),
                number=nft.number_value,
                collection_address=(await self.session.get(Collection, nft.collection_id)).address
                if nft.collection_id
                else None,
            )
        resolved = await self.metadata.resolve(nft.address)
        nft.name = resolved.name
        nft.description = resolved.description
        nft.image_url = resolved.image_url
        nft.attributes = resolved.attributes or {}
        nft.number_value = resolved.number
        nft.metadata_status = resolved.status.value
        nft.metadata_fetched_at = _now()
        await self.session.flush()
        return resolved

    async def _persist(self, analysis, listing: MarketplaceListing, nft: NFT) -> Opportunity:
        fair = analysis.fair_value
        score = analysis.score
        opportunity = Opportunity(
            nft_id=nft.id,
            collection_id=nft.collection_id,
            marketplace=listing.marketplace,
            listing_id=listing.listing_id,
            listed_price_ton=d(listing.price_ton),
            fair_value_low=fair.low if fair else None,
            fair_value_high=fair.high if fair else None,
            discount_pct=analysis.discount,
            rarity_score=analysis.rarity.score if analysis.rarity else None,
            number_score=analysis.number_profile.base_score if analysis.number_profile else None,
            liquidity_score=analysis.liquidity.score if analysis.liquidity else None,
            confidence=fair.confidence if fair else None,
            roi_pct=analysis.roi_pct,
            estimated_costs_ton=d(analysis.costs.get("total_costs", 0)),
            theoretical_profit_ton=analysis.theoretical_profit,
            risk_level=analysis.risk.value,
            opportunity_score=score.score if score else 0,
            reasons=score.reasons if score else [],
            detected_at=_now(),
            expires_at=_now() + timedelta(hours=24),
        )
        self.session.add(opportunity)
        await self.session.flush()
        return opportunity

    async def analyze_nft(self, nft_address: str, *, with_listing: bool = True):
        """Analyse a single NFT (metadata + fair value + liquidity + score)."""
        from sqlalchemy import select

        result = await self.session.execute(select(NFT).where(NFT.address == nft_address))
        nft = result.scalar_one_or_none()
        if nft is None:
            # Unknown to us: index it on the fly from the chain.
            items = await self.market.toncenter.get_nft_items(nft_address)
            item = items[0] if items else None
            if item is None:
                return None
            collection_address = item.get("collection_address") or (
                (item.get("collection") or {}).get("address")
            )
            collection = (
                await self.market.ensure_collection(collection_address)
                if collection_address
                else None
            )
            nft = await self.market._upsert_nft(item, collection=collection)  # noqa: SLF001
            await self.session.flush()

        metadata = await self._metadata_for(nft)
        collection_address = None
        if nft.collection_id:
            collection = await self.session.get(Collection, nft.collection_id)
            collection_address = collection.address if collection else None
        if not collection_address:
            return None

        snapshot = await self.market.build_snapshot(collection_address)
        traits = await self.market.collection_traits(collection_address)
        analysis = analyse_nft(metadata, snapshot, collection_traits=traits)

        if with_listing:
            listing = (
                await self.session.execute(
                    select(MarketplaceListing)
                    .where(
                        MarketplaceListing.nft_id == nft.id,
                        MarketplaceListing.is_active.is_(True),
                    )
                    .order_by(MarketplaceListing.price_ton.asc())
                    .limit(1)
                )
            ).scalar_one_or_none()
            if listing is not None:
                finalise_analysis(analysis, listing_price=listing.price_ton)
        return analysis

    # -------------------------------------------------------------- queries
    async def list_opportunities(
        self,
        *,
        collection_address: str | None = None,
        min_score: int = 0,
        status: str | None = OpportunityStatus.OPEN.value,
        limit: int = 20,
    ) -> Sequence[Opportunity]:
        query = select(Opportunity)
        if collection_address:
            collection = await self.market.ensure_collection(collection_address)
            query = query.where(Opportunity.collection_id == collection.id)
        if status:
            query = query.where(Opportunity.status == status)
        query = query.where(Opportunity.opportunity_score >= min_score)
        query = query.order_by(Opportunity.opportunity_score.desc(), Opportunity.detected_at.desc())
        result = await self.session.execute(query.limit(limit))
        return list(result.scalars().all())

    async def get_opportunity(self, opportunity_id: int) -> Opportunity | None:
        return await self.session.get(Opportunity, opportunity_id)

    async def latest_for_nft(self, nft_address: str) -> Opportunity | None:
        result = await self.session.execute(
            select(Opportunity)
            .join(NFT, NFT.id == Opportunity.nft_id)
            .where(NFT.address == nft_address)
            .order_by(Opportunity.detected_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    # --------------------------------------------------------------- replay
    async def replay(self, opportunity_id: int) -> list[dict[str, Any]]:
        """Compare the detection price with later observations (24/48/72h)."""
        opportunity = await self.get_opportunity(opportunity_id)
        if opportunity is None:
            return []
        results: list[dict[str, Any]] = []
        for horizon in HORIZONS:
            existing = (
                await self.session.execute(
                    select(OpportunityHistory).where(
                        OpportunityHistory.opportunity_id == opportunity.id,
                        OpportunityHistory.horizon_hours == horizon,
                    )
                )
            ).scalar_one_or_none()
            if existing:
                results.append(
                    replay_opportunity(
                        detection_price=opportunity.listed_price_ton,
                        horizon_hours=horizon,
                        observed_price=existing.observed_price_ton,
                        observed_floor=existing.observed_floor_ton,
                        projected_price=opportunity.fair_value_high,
                        costs=opportunity.estimated_costs_ton,
                        computed_at=existing.computed_at,
                    ).as_dict()
                )
                continue

            target = opportunity.detected_at + timedelta(hours=horizon)
            if _now() < target:
                continue

            observed_price, observed_floor, sold = await self._observe_at(opportunity, target)
            history = OpportunityHistory(
                opportunity_id=opportunity.id,
                horizon_hours=horizon,
                observed_price_ton=observed_price,
                observed_floor_ton=observed_floor,
                theoretical_result_ton=None,
                actual_outcome="sold" if sold else "observed",
                computed_at=_now(),
            )
            self.session.add(history)
            results.append(
                replay_opportunity(
                    detection_price=opportunity.listed_price_ton,
                    horizon_hours=horizon,
                    observed_price=observed_price,
                    observed_floor=observed_floor,
                    projected_price=opportunity.fair_value_high,
                    costs=opportunity.estimated_costs_ton,
                    sold=sold,
                    computed_at=_now(),
                ).as_dict()
            )
        await self.session.flush()
        return results

    async def _observe_at(
        self, opportunity: Opportunity, moment: datetime
    ) -> tuple[Any | None, Any | None, bool]:
        """Observed listing price / collection floor around ``moment``."""
        listing = (
            await self.session.execute(
                select(MarketplaceListing)
                .where(MarketplaceListing.listing_id == opportunity.listing_id)
                .limit(1)
            )
        ).scalar_one_or_none()
        observed_price = listing.price_ton if listing else None
        sold = bool(listing is None or not listing.is_active)

        floor = (
            await self.session.execute(
                select(func.min(MarketplaceListing.price_ton)).where(
                    MarketplaceListing.collection_id == opportunity.collection_id,
                    MarketplaceListing.is_active.is_(True),
                )
            )
        ).scalar_one_or_none()
        return observed_price, floor, sold

    async def replay_summary(self, *, collection_address: str | None = None) -> dict[str, Any]:
        query = select(OpportunityHistory)
        if collection_address:
            collection = await self.market.ensure_collection(collection_address)
            query = query.join(Opportunity).where(Opportunity.collection_id == collection.id)
        rows = (await self.session.execute(query)).scalars().all()
        results = [
            replay_opportunity(
                detection_price=d("0"),
                horizon_hours=row.horizon_hours,
                observed_price=row.observed_price_ton,
                observed_floor=row.observed_floor_ton,
                costs=d("0"),
            )
            for row in rows
        ]
        return replay_summary(results)
