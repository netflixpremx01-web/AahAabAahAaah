"""Swap service: quotes, persistence and on-chain verification.

Flow: QUOTE -> user confirms -> TON Connect -> wallet approval -> chain
-> backend verification. Exchange rates are always fetched live; nothing is
hardcoded.
"""
from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.constants import STONFI_NATIVE_TON, USDT_MASTER
from app.core.errors import (
    ProviderError,
    QuoteExpired,
    QuoteNotFound,
    TradingDisabled,
    ValidationError,
)
from app.core.logging import get_logger
from app.core.money import d, quantize_ton
from app.integrations.dex.base import SwapQuoteRequest
from app.integrations.dex.registry import describe_all, get_adapter, get_adapters
from app.integrations.toncenter.client import TonCenterClient
from app.integrations.tonconnect.transactions import TransactionVerifier
from app.models.enums import TxStatus
from app.models.orm import SwapQuote, SwapTransaction, User

logger = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def _to_naive(moment: datetime) -> datetime:
    return moment.replace(tzinfo=None) if moment.tzinfo else moment


class SwapService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.settings = get_settings()
        self.toncenter = TonCenterClient()

    @staticmethod
    def token_aliases(token: str) -> str:
        """Resolve a friendly symbol ("TON", "USDT") to a contract address.

        Values that already look like an address are passed through untouched.
        """
        from app.core.constants import USDT_MASTER

        token = (token or "").strip()
        upper = token.upper()
        if upper in {"TON", "NATIVE"}:
            return STONFI_NATIVE_TON
        if upper == "USDT":
            return USDT_MASTER[get_settings().ton_network]
        if token.startswith(("EQ", "UQ", "0:", "-1:", "kQ")) and len(token) > 20:
            return token
        return token

    async def quote(
        self,
        *,
        user: User,
        from_token: str,
        to_token: str,
        amount: Any,
        slippage: Any | None = None,
        provider: str | None = None,
    ) -> SwapQuote:
        from_token_resolved = self.token_aliases(from_token)
        to_token_resolved = self.token_aliases(to_token)
        request = SwapQuoteRequest(
            from_token=from_token_resolved,
            to_token=to_token_resolved,
            amount=amount,
            slippage=slippage,
        )

        if provider:
            adapters = [get_adapter(provider)]
        else:
            adapters = list(get_adapters().values())

        last_error: Exception | None = None
        best = None
        for adapter in adapters:
            try:
                quote = await adapter.get_quote(request)
            except (ProviderError, ValidationError) as exc:
                last_error = exc
                continue
            if best is None or d(quote.to_amount) > d(best.to_amount):
                best = quote
        if best is None:
            raise ProviderError(f"no provider could quote this swap: {last_error}")

        row = SwapQuote(
            user_id=user.id,
            provider=best.provider,
            from_token=from_token_resolved,
            to_token=to_token_resolved,
            from_amount=quantize_ton(d(best.from_amount)),
            to_amount=quantize_ton(d(best.to_amount)),
            min_received=quantize_ton(d(best.min_received)),
            rate=d(best.rate),
            price_impact=d(best.price_impact),
            network_fee_ton=quantize_ton(d(best.network_fee_ton)),
            route=[hop.__dict__ for hop in best.route],
            slippage=d(best.slippage),
            expires_at=_to_naive(best.expires_at or (_now() + timedelta(seconds=30))),
        )
        self.session.add(row)
        await self.session.flush()
        row.payload_notes = best.notes  # type: ignore[attr-defined]
        return row

    async def get_quote(self, quote_id: int) -> SwapQuote:
        quote = await self.session.get(SwapQuote, quote_id)
        if quote is None:
            raise QuoteNotFound()
        return quote

    async def submit(
        self,
        *,
        user: User,
        quote_id: int,
        wallet_address: str,
        tx_hash: str | None = None,
    ) -> SwapTransaction:
        """Record a user-approved swap and verify it on chain."""
        quote = await self.get_quote(quote_id)
        if quote.user_id != user.id:
            raise QuoteNotFound()
        if quote.expires_at < _now():
            quote.status = "expired"
            await self.session.flush()
            raise QuoteExpired()
        if not self.settings.enable_real_trading:
            raise TradingDisabled(
                "Live swaps are disabled. Enable ENABLE_REAL_TRADING to record them."
            )

        swap = SwapTransaction(
            user_id=user.id,
            quote_id=quote.id,
            wallet_address=wallet_address,
            tx_hash=tx_hash,
            status=TxStatus.PENDING.value,
            provider=quote.provider,
            from_token=quote.from_token,
            to_token=quote.to_token,
            from_amount=quote.from_amount,
            expected_amount=quote.to_amount,
            submitted_at=_now(),
        )
        self.session.add(swap)
        await self.session.flush()

        if tx_hash:
            result = await TransactionVerifier(self.toncenter).verify_by_hash(tx_hash)
            if result.confirmed and result.success:
                swap.status = TxStatus.CONFIRMED.value
                swap.confirmed_at = _now()
                swap.actual_amount = quote.to_amount
            elif result.confirmed:
                swap.status = TxStatus.FAILED.value
                swap.error = "swap transaction failed on chain"
            else:
                swap.error = result.reason
        await self.session.flush()
        return swap

    async def list_swaps(self, user_id: int, *, limit: int = 25) -> Sequence[SwapTransaction]:
        result = await self.session.execute(
            select(SwapTransaction)
            .where(SwapTransaction.user_id == user_id)
            .order_by(SwapTransaction.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    @staticmethod
    def providers() -> list[dict[str, Any]]:
        return describe_all()

    @staticmethod
    def known_tokens() -> dict[str, str]:
        settings = get_settings()
        return {"TON": STONFI_NATIVE_TON, "USDT": USDT_MASTER[settings.ton_network]}
