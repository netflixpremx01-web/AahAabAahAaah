"""Notification queue with deduplication and category preferences."""
from __future__ import annotations

import hashlib
from collections.abc import Awaitable, Callable, Sequence
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.cache import get_cache
from app.core.logging import get_logger
from app.models.enums import NotificationCategory, NotificationStatus
from app.models.orm import Notification, User
from app.services.users import notification_enabled

logger = get_logger(__name__)

Sender = Callable[[int, str, str], Awaitable[bool]]


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def make_dedupe_key(*parts: Any) -> str:
    raw = ":".join(str(part) for part in parts)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


class NotificationService:
    """Queues notifications and (optionally) delivers them via a sender."""

    def __init__(self, session: AsyncSession, sender: Sender | None = None) -> None:
        self.session = session
        self.sender = sender

    async def notify(
        self,
        *,
        user: User,
        category: NotificationCategory | str,
        title: str,
        body: str,
        payload: dict | None = None,
        dedupe_key: str | None = None,
        dedupe_seconds: int = 3600,
    ) -> Notification | None:
        category = NotificationCategory(str(category))
        if not notification_enabled(user, category):
            return None
        if dedupe_key:
            cache = await get_cache()
            if await cache.get(f"notif:{dedupe_key}"):
                return None
            await cache.set(f"notif:{dedupe_key}", _now().isoformat(), dedupe_seconds)

        notification = Notification(
            user_id=user.id,
            category=category.value,
            title=title,
            body=body,
            payload=payload or {},
            dedupe_key=dedupe_key,
            status=NotificationStatus.PENDING.value,
        )
        self.session.add(notification)
        await self.session.flush()

        if self.sender:
            try:
                delivered = await self.sender(user.telegram_id, title, body)
                notification.status = (
                    NotificationStatus.SENT.value if delivered else NotificationStatus.FAILED.value
                )
                notification.sent_at = _now()
            except Exception as exc:  # delivery must never break the caller
                logger.warning(
                    "notification delivery failed",
                    extra={"extra_fields": {"user": user.telegram_id, "error": str(exc)}},
                )
                notification.status = NotificationStatus.FAILED.value
                notification.error = str(exc)
            await self.session.flush()
        return notification

    async def list(self, user_id: int, *, limit: int = 30) -> Sequence[Notification]:
        result = await self.session.execute(
            select(Notification)
            .where(Notification.user_id == user_id)
            .order_by(Notification.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def mark_read(self, user_id: int, notification_id: int | None = None) -> int:
        query = select(Notification).where(
            Notification.user_id == user_id, Notification.read_at.is_(None)
        )
        if notification_id:
            query = query.where(Notification.id == notification_id)
        rows = (await self.session.execute(query)).scalars().all()
        for row in rows:
            row.read_at = _now()
        await self.session.flush()
        return len(rows)
