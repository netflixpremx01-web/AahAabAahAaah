"""Market data service: collections, listings, sales and analysis snapshots.

All data originates from documented providers (TON Center API v3, TonAPI).
This service owns *our* indexed view of that data (PostgreSQL) so the radar,
portfolio and analytics engines can work offline from local state.
"""
from __future__ import annotations

import time
from collections.abc import Sequence
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.constants import KNOWN_MARKETPLACES
from app.core.errors import CapabilityNotSupported, ProviderError
from app.core.logging import get_logger
from app.core.money import d, nano_from_ton, ton_from_nano
from app.integrations.marketplaces.registry import get_read_adapters
from app.integrations.toncenter.client import TonCenterClient
from app.models.enums import MetadataStatus
from app.models.orm import NFT, Collection, MarketplaceListing, NFTTrait, Sale
from app.nft.analyzer import MarketSnapshot
from app.nft.metadata import NFTMetadataService
from app.nft.numbers import classify
from app.radar.anomaly import detect_anomalies
from app.radar.stats import CollectionHealthInput, compute_collection_health
from app.radar.whale import analyse_whales

logger = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def _norm(address: str | None) -> str:
    return (address or "").strip().lower()


def _to_user_friendly(raw: str) -> str:
    """Return the raw form; TON Center accepts raw, hex and base64 forms."""
    return raw


class MarketService:
    def __init__(
        self,
        session: AsyncSession,
        *,
        toncenter: TonCenterClient | None = None,
        metadata: NFTMetadataService | None = None,
    ) -> None:
        self.session = session
        self.toncenter = toncenter or TonCenterClient()
        self.metadata = metadata or NFTMetadataService(self.toncenter)
        self.settings = get_settings()

    # --------------------------------------------------------- collections
    async def ensure_collection(self, address: str) -> Collection:
        result = await self.session.execute(
            select(Collection).where(Collection.address == address)
        )
        collection = result.scalar_one_or_none()
        if collection:
            return collection

        collection = Collection(address=address, network=self.settings.ton_network)
        self.session.add(collection)
        await self.session.flush()

        try:
            records = await self.toncenter.get_nft_collections(address)
            record = records[0] if records else {}
            content = record.get("collection_content") or {}
            collection.name = content.get("name") if isinstance(content, dict) else None
            collection.owner_address = record.get("owner_address")
            next_index = record.get("next_item_index")
            if next_index is not None:
                try:
                    parsed = int(next_index)
                    # 0 / negative values mean "unknown" for some collections
                    # (large or lazily minted ones); leave the size unset rather
                    # than reporting a wrong number.
                    collection.item_count = parsed if parsed > 0 else None
                except (TypeError, ValueError):
                    collection.item_count = None
            metadata = await self.toncenter.get_metadata(address)
            info = ((metadata or {}).get(address) or {}).get("token_info") or []
            if info:
                collection.name = collection.name or info[0].get("name")
                collection.description = info[0].get("description")
                collection.image_url = info[0].get("image")
                collection.metadata_status = MetadataStatus.OK.value
            else:
                collection.metadata_status = MetadataStatus.PARTIAL.value
        except ProviderError as exc:
            logger.warning("collection lookup failed", extra={"extra_fields": {"error": str(exc)}})
            collection.metadata_status = MetadataStatus.FAILED.value
        await self.session.flush()
        return collection

    async def sync_collection(
        self, address: str, *, item_limit: int = 200, resolve_metadata: bool = True
    ) -> Collection:
        """Index a collection: items, metadata, traits, listings and sales."""
        collection = await self.ensure_collection(address)
        items = await self.toncenter.get_nft_items(collection_address=address, limit=item_limit)
        for item in items:
            await self._upsert_nft(item, collection=collection)
        # ``len(items)`` is a sample size, NOT the collection size - never
        # overwrite a real item count with it.
        await self.session.flush()

        if resolve_metadata:
            await self.resolve_pending_metadata(limit=item_limit)

        await self.sync_listings(address)
        await self.sync_sales(address)
        await self.refresh_collection_stats(address)
        return collection

    async def _upsert_nft(self, item: dict[str, Any], *, collection: Collection) -> NFT:
        address = item.get("address")
        result = await self.session.execute(select(NFT).where(NFT.address == address))
        nft = result.scalar_one_or_none()
        if nft is None:
            nft = NFT(address=address, network=self.settings.ton_network)
            self.session.add(nft)
        nft.collection_id = collection.id
        nft.index = str(item.get("index")) if item.get("index") is not None else None
        nft.owner_address = item.get("owner_address")
        content = item.get("content") if isinstance(item.get("content"), dict) else {}
        nft.metadata_url = content.get("uri")
        await self.session.flush()
        return nft

    async def resolve_pending_metadata(self, *, limit: int = 50) -> int:
        """Resolve metadata for NFTs that have not been fetched yet."""
        result = await self.session.execute(
            select(NFT)
            .where(NFT.metadata_status == MetadataStatus.PENDING.value)
            .order_by(NFT.updated_at.desc())
            .limit(limit)
        )
        nfts = list(result.scalars().all())
        for nft in nfts:
            resolved = await self.metadata.resolve(nft.address)
            nft.name = resolved.name
            nft.description = resolved.description
            nft.image_url = resolved.image_url
            nft.metadata_url = resolved.metadata_url or nft.metadata_url
            nft.attributes = resolved.attributes or {}
            nft.number_value = resolved.number
            nft.metadata_status = resolved.status.value
            nft.metadata_error = resolved.error
            nft.metadata_fetched_at = _now()
            await self._sync_traits(nft)
        if nfts:
            await self.session.flush()
        return len(nfts)

    async def _sync_traits(self, nft: NFT) -> None:
        await self.session.execute(delete(NFTTrait).where(NFTTrait.nft_id == nft.id))
        for trait_type, value in (nft.attributes or {}).items():
            self.session.add(
                NFTTrait(nft_id=nft.id, trait_type=str(trait_type), trait_value=str(value))
            )

    # ------------------------------------------------------------ listings
    async def sync_listings(self, collection_address: str, *, limit: int = 200) -> int:
        """Refresh active listings from every read-capable marketplace adapter."""
        collection = await self.ensure_collection(collection_address)
        upserted = 0
        for adapter in get_read_adapters():
            try:
                listings = await adapter.get_listings(collection_address, limit=limit)
            except (CapabilityNotSupported, ProviderError) as exc:
                logger.info(
                    "listing sync skipped",
                    extra={"extra_fields": {"adapter": adapter.name, "error": str(exc)}},
                )
                continue
            for listing in listings:
                await self._upsert_listing(listing, collection=collection)
                upserted += 1
        await self.session.flush()
        return upserted

    async def _upsert_listing(self, listing, *, collection: Collection) -> None:
        if d(listing.price_ton) <= 0:
            # Listings without a usable price are not indexable (bad provider
            # data or a listing awaiting a price update).
            return
        result = await self.session.execute(
            select(MarketplaceListing).where(
                MarketplaceListing.marketplace == listing.marketplace,
                MarketplaceListing.listing_id == listing.listing_id,
            )
        )
        row = result.scalar_one_or_none()
        if row is None:
            row = MarketplaceListing(
                marketplace=listing.marketplace,
                listing_id=listing.listing_id,
                price_ton=d("0"),
            )
            self.session.add(row)

        nft = None
        if listing.nft_address:
            nft_result = await self.session.execute(
                select(NFT).where(NFT.address == listing.nft_address)
            )
            nft = nft_result.scalar_one_or_none()
            if nft is None:
                nft = NFT(address=listing.nft_address, network=self.settings.ton_network)
                self.session.add(nft)
                await self.session.flush()

        row.nft_id = nft.id if nft else None
        row.collection_id = collection.id
        row.seller_address = listing.seller_address
        row.price_ton = d(listing.price_ton)
        row.price_nano = nano_from_ton(listing.price_ton)
        row.currency = listing.currency
        row.marketplace_fee_bps = listing.marketplace_fee_bps
        row.royalty_bps = listing.royalty_bps
        row.is_active = True
        row.last_seen_at = _now()
        row.raw = listing.raw or {}
        await self.session.flush()

    # --------------------------------------------------------------- sales
    async def sync_sales(self, collection_address: str, *, limit: int = 200, days: int = 60) -> int:
        """Index sales from TON Center ``nft_purchase`` actions."""
        collection = await self.ensure_collection(collection_address)
        start = int(time.time()) - days * 86400
        try:
            actions = await self.toncenter.get_nft_purchases(
                collection_address=collection_address,
                start_utime=start,
                limit=min(limit, 100),
                pages=3,
            )
        except ProviderError as exc:  # the indexer is the only price source here
            logger.warning(
                "sales history unavailable",
                extra={"extra_fields": {"collection": collection_address, "error": str(exc)}},
            )
            return 0
        count = 0
        for action in actions:
            details = action.get("details") or {}
            nft_address = details.get("nft_item")
            if not nft_address or d(details.get("price") or 0) <= 0:
                continue
            sale_id = action.get("trace_id") or action.get("action_id")
            if not sale_id:
                continue
            result = await self.session.execute(
                select(Sale).where(Sale.sale_id == sale_id, Sale.marketplace != "")
            )
            existing = result.scalar_one_or_none()
            if existing:
                continue

            nft_result = await self.session.execute(
                select(NFT).where(NFT.address == nft_address)
            )
            nft = nft_result.scalar_one_or_none()
            if nft is None:
                nft = NFT(address=nft_address, network=self.settings.ton_network)
                self.session.add(nft)
                await self.session.flush()
                nft.collection_id = collection.id

            marketplace_address = _norm(details.get("marketplace_address"))
            price = ton_from_nano(details.get("price"))
            self.session.add(
                Sale(
                    marketplace=KNOWN_MARKETPLACES.get(marketplace_address, "unknown"),
                    sale_id=sale_id,
                    nft_id=nft.id,
                    collection_id=collection.id,
                    seller_address=details.get("old_owner"),
                    buyer_address=details.get("new_owner"),
                    price_ton=price,
                    price_nano=int(details.get("price") or 0),
                    sold_at=datetime.fromtimestamp(
                        int(action.get("end_utime") or action.get("start_utime") or time.time()),
                        tz=UTC,
                    ).replace(tzinfo=None),
                    tx_hash=action.get("trace_id"),
                    raw={"marketplace_address": details.get("marketplace_address")},
                )
            )
            count += 1
        await self.session.flush()
        return count

    # --------------------------------------------------------------- stats
    async def refresh_collection_stats(self, collection_address: str) -> Collection:
        collection = await self.ensure_collection(collection_address)
        now = _now()

        floor_result = await self.session.execute(
            select(func.min(MarketplaceListing.price_ton)).where(
                MarketplaceListing.collection_id == collection.id,
                MarketplaceListing.is_active.is_(True),
            )
        )
        floor = floor_result.scalar_one_or_none()
        if floor is not None:
            collection.floor_price_ton = d(floor)
            collection.floor_updated_at = now

        listings_count = await self.session.scalar(
            select(func.count(MarketplaceListing.id)).where(
                MarketplaceListing.collection_id == collection.id,
                MarketplaceListing.is_active.is_(True),
            )
        )
        collection.listings_count = int(listings_count or 0)

        for days, field in ((1, "volume_24h_ton"), (7, "volume_7d_ton")):
            since = now - timedelta(days=days)
            volume = await self.session.scalar(
                select(func.coalesce(func.sum(Sale.price_ton), 0)).where(
                    Sale.collection_id == collection.id, Sale.sold_at >= since
                )
            )
            setattr(collection, field, d(volume))

        sales_24h = await self.session.scalar(
            select(func.count(Sale.id)).where(
                Sale.collection_id == collection.id, Sale.sold_at >= now - timedelta(days=1)
            )
        )
        collection.sales_24h = int(sales_24h or 0)

        buyers = await self.session.scalar(
            select(func.count(func.distinct(Sale.buyer_address))).where(
                Sale.collection_id == collection.id, Sale.sold_at >= now - timedelta(days=1)
            )
        )
        collection.unique_buyers_24h = int(buyers or 0)

        health = await self.health(collection_address)
        collection.health_score = health.score
        collection.trend = health.trend.value
        await self.session.flush()
        return collection

    # ------------------------------------------------------------ snapshot
    async def collection_traits(self, collection_address: str, *, sample: int = 500) -> list[dict]:
        """Trait maps for a sample of the collection (used for rarity)."""
        result = await self.session.execute(
            select(NFT.attributes)
            .join(Collection, Collection.id == NFT.collection_id)
            .where(Collection.address == collection_address, NFT.attributes != {})
            .limit(sample)
        )
        return [row[0] for row in result.all() if row[0]]

    async def build_snapshot(self, collection_address: str) -> MarketSnapshot:
        """Assemble everything the analyser needs for one collection."""
        collection = await self.ensure_collection(collection_address)
        now = _now()

        since_7d, since_30d = now - timedelta(days=7), now - timedelta(days=30)
        floor = d(collection.floor_price_ton) if collection.floor_price_ton else None
        floor_age_hours = None
        if collection.floor_updated_at:
            floor_age_hours = (now - collection.floor_updated_at).total_seconds() / 3600

        sales_30d = list(
            (
                await self.session.execute(
                    select(Sale.price_ton, Sale.nft_id, Sale.buyer_address, Sale.seller_address)
                    .where(Sale.collection_id == collection.id, Sale.sold_at >= since_30d)
                )
            ).all()
        )
        prices_30d = [d(row[0]) for row in sales_30d]
        sales_7d_count = sum(
            1
            for row in (
                await self.session.execute(
                    select(Sale.sold_at).where(
                        Sale.collection_id == collection.id, Sale.sold_at >= since_7d
                    )
                )
            ).all()
        )
        volume_7d = await self.session.scalar(
            select(func.coalesce(func.sum(Sale.price_ton), 0)).where(
                Sale.collection_id == collection.id, Sale.sold_at >= since_7d
            )
        )
        buyers = await self.session.scalar(
            select(func.count(func.distinct(Sale.buyer_address))).where(
                Sale.collection_id == collection.id, Sale.sold_at >= since_7d
            )
        )
        sellers = await self.session.scalar(
            select(func.count(func.distinct(Sale.seller_address))).where(
                Sale.collection_id == collection.id, Sale.sold_at >= since_7d
            )
        )

        # Rare-number vs baseline sales (comparable premium derivation).
        rare_sales: list = []
        baseline_sales: list = []
        nft_ids = {row[1] for row in sales_30d if row[1]}
        if nft_ids:
            numbers = dict(
                (
                    await self.session.execute(
                        select(NFT.id, NFT.number_value).where(NFT.id.in_(list(nft_ids)))
                    )
                ).all()
            )
            for row in sales_30d:
                number = numbers.get(row[1])
                (rare_sales if classify(number).is_rare else baseline_sales).append(d(row[0]))

        health = await self.health(collection_address)

        return MarketSnapshot(
            floor=floor,
            floor_age_hours=floor_age_hours,
            comparable_sales=prices_30d,
            collection_sales=prices_30d,
            rare_number_sales=rare_sales,
            baseline_sales=baseline_sales,
            listings_count=int(collection.listings_count or 0),
            sales_7d=int(sales_7d_count or 0),
            sales_30d=len(prices_30d),
            unique_buyers_7d=int(buyers or 0),
            unique_sellers_7d=int(sellers or 0),
            volume_7d_ton=d(volume_7d or 0),
            collection_size=collection.item_count,
            trend=health.trend.value,
            collection_health=health.score,
        )

    async def health(self, collection_address: str):
        collection = await self.ensure_collection(collection_address)
        now = _now()
        floor_24h = await self._floor_at(collection, now - timedelta(days=1))
        floor_7d = await self._floor_at(collection, now - timedelta(days=7))
        volume_24h = await self.session.scalar(
            select(func.coalesce(func.sum(Sale.price_ton), 0)).where(
                Sale.collection_id == collection.id, Sale.sold_at >= now - timedelta(days=1)
            )
        )
        volume_7d = await self.session.scalar(
            select(func.coalesce(func.sum(Sale.price_ton), 0)).where(
                Sale.collection_id == collection.id, Sale.sold_at >= now - timedelta(days=7)
            )
        )
        sales_7d = await self.session.scalar(
            select(func.count(Sale.id)).where(
                Sale.collection_id == collection.id, Sale.sold_at >= now - timedelta(days=7)
            )
        )
        buyers, sellers = await self._buyers_sellers(collection.id, now - timedelta(days=1))
        return compute_collection_health(
            CollectionHealthInput(
                floor_now=collection.floor_price_ton,
                floor_24h_ago=floor_24h,
                floor_7d_ago=floor_7d,
                volume_24h_ton=d(volume_24h or 0),
                volume_7d_ton=d(volume_7d or 0),
                sales_24h=int(collection.sales_24h or 0),
                sales_7d=int(sales_7d or 0),
                buyers_24h=buyers,
                sellers_24h=sellers,
                listings_count=int(collection.listings_count or 0),
                collection_size=collection.item_count,
            )
        )

    async def _floor_at(self, collection: Collection, moment: datetime):
        """Floor price closest to (but not after) ``moment``."""
        row = (
            await self.session.execute(
                select(Sale.price_ton)
                .where(Sale.collection_id == collection.id, Sale.sold_at <= moment)
                .order_by(Sale.sold_at.desc())
                .limit(5)
            )
        ).all()
        prices = [d(r[0]) for r in row]
        return min(prices) if prices else None

    async def _buyers_sellers(self, collection_id: int, since: datetime) -> tuple[int, int]:
        buyers = await self.session.scalar(
            select(func.count(func.distinct(Sale.buyer_address))).where(
                Sale.collection_id == collection_id, Sale.sold_at >= since
            )
        )
        sellers = await self.session.scalar(
            select(func.count(func.distinct(Sale.seller_address))).where(
                Sale.collection_id == collection_id, Sale.sold_at >= since
            )
        )
        return int(buyers or 0), int(sellers or 0)

    # ------------------------------------------------------ market intel
    async def anomalies(self, collection_address: str) -> list[dict[str, Any]]:
        collection = await self.ensure_collection(collection_address)
        since = _now() - timedelta(days=14)
        sales = (
            await self.session.execute(
                select(Sale.price_ton, Sale.sold_at, Sale.buyer_address, Sale.seller_address)
                .where(Sale.collection_id == collection.id, Sale.sold_at >= since)
                .order_by(Sale.sold_at.asc())
            )
        ).all()

        floor_series = [(row[1], row[0]) for row in sales]
        volume_by_day: dict[datetime, Any] = {}
        for price, sold_at, *_ in sales:
            day = sold_at.replace(hour=0, minute=0, second=0, microsecond=0)
            volume_by_day[day] = d(volume_by_day.get(day, 0)) + d(price)
        volume_series = sorted(volume_by_day.items())

        listings = (
            await self.session.execute(
                select(MarketplaceListing.price_ton).where(
                    MarketplaceListing.collection_id == collection.id,
                    MarketplaceListing.is_active.is_(True),
                )
            )
        ).all()

        return [
            anomaly.as_dict()
            for anomaly in detect_anomalies(
                floor_series=floor_series,
                volume_series=volume_series,
                recent_sales=[
                    {"price": row[0], "ts": row[1], "buyer": row[2], "seller": row[3]}
                    for row in sales
                ],
                listing_prices=[row[0] for row in listings],
                floor=collection.floor_price_ton,
                collection_size=collection.item_count,
            )
        ]

    async def whales(self, collection_address: str, *, hours: int = 72) -> dict[str, Any]:
        collection = await self.ensure_collection(collection_address)
        since = _now() - timedelta(hours=hours)
        sales = (
            await self.session.execute(
                select(Sale.price_ton, Sale.sold_at, Sale.buyer_address, Sale.seller_address)
                .where(Sale.collection_id == collection.id, Sale.sold_at >= since)
            )
        ).all()
        report = analyse_whales(
            [
                {"price": row[0], "ts": row[1], "buyer": row[2], "seller": row[3]}
                for row in sales
            ],
            collection=collection_address,
            window_hours=hours,
            now=_now(),
        )
        return report.as_dict()

    async def top_collections(self, limit: int = 20) -> list[Collection]:
        result = await self.session.execute(
            select(Collection).order_by(Collection.volume_7d_ton.desc()).limit(limit)
        )
        return list(result.scalars().all())

    async def active_listings(
        self, collection_address: str | None = None, *, limit: int = 50
    ) -> Sequence[MarketplaceListing]:
        query = select(MarketplaceListing).where(MarketplaceListing.is_active.is_(True))
        if collection_address:
            collection = await self.ensure_collection(collection_address)
            query = query.where(MarketplaceListing.collection_id == collection.id)
        query = query.order_by(MarketplaceListing.price_ton.asc()).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all())
