"""Buy / sell flows.

Non-custodial by construction:

* the backend only *prepares* transaction intents;
* the user approves every transaction inside their own wallet (TON Connect);
* after broadcast the backend re-reads the transaction from the blockchain
  before marking anything as confirmed;
* real-money execution can be disabled entirely (``ENABLE_REAL_TRADING``).

If the configured marketplace cannot build a transaction (no public API), the
service reports that honestly instead of fabricating a payload.
"""
from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.errors import (
    CapabilityNotSupported,
    NotFoundError,
    ProviderError,
    ProviderUnavailable,
    TradingDisabled,
    WalletNotConnected,
)
from app.core.logging import get_logger
from app.core.money import d, nano_from_ton, quantize_ton
from app.integrations.marketplaces.base import Listing
from app.integrations.marketplaces.registry import get_adapter, get_adapters
from app.integrations.tonconnect.transactions import TransactionVerifier
from app.models.enums import Marketplace, TxKind, TxStatus
from app.models.orm import NFT, Collection, MarketplaceListing, Transaction, User
from app.radar.scoring import compute_costs
from app.services.market import MarketService

logger = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class TradingService:
    def __init__(self, session: AsyncSession, market: MarketService | None = None) -> None:
        self.session = session
        self.market = market or MarketService(session)
        self.settings = get_settings()

    # ------------------------------------------------------------------ buy
    async def prepare_buy(
        self,
        *,
        nft_address: str | None = None,
        listing_id: str | None = None,
        marketplace: str | None = None,
    ) -> dict[str, Any]:
        """Build the confirmation screen for a purchase (no signing)."""
        listing = await self._find_listing(nft_address=nft_address, listing_id=listing_id)
        if listing is None:
            raise NotFoundError("No active listing found for this NFT")

        nft = await self.session.get(NFT, listing.nft_id) if listing.nft_id else None
        collection = (
            await self.session.get(Collection, listing.collection_id)
            if listing.collection_id
            else None
        )
        costs = compute_costs(
            listing.price_ton,
            marketplace_fee_bps=listing.marketplace_fee_bps,
            royalty_bps=listing.royalty_bps,
        )

        payload: dict[str, Any] = {
            "available": False,
            "nft": {
                "address": nft.address if nft else None,
                "name": nft.name if nft else None,
                "image_url": nft.image_url if nft else None,
                "number": nft.number_value if nft else None,
            },
            "collection": {
                "address": collection.address if collection else None,
                "name": collection.name if collection else None,
            },
            "marketplace": listing.marketplace,
            "listing_id": listing.listing_id,
            "price_ton": str(listing.price_ton),
            "costs": costs,
            "total_ton": costs["total_outflow"],
            "network": self.settings.ton_network,
            "explorer": self.settings.explorer_base,
            "requires_wallet_approval": True,
            "disclaimer": (
                "Estimated costs only. The final amount is determined by the "
                "marketplace contract and the wallet. No profit is guaranteed."
            ),
        }

        adapter = self._adapter(listing.marketplace if not marketplace else marketplace)
        try:
            prepared = await adapter.prepare_buy_transaction(
                Listing(
                    marketplace=listing.marketplace,
                    listing_id=listing.listing_id,
                    nft_address=nft.address if nft else "",
                    price_ton=listing.price_ton,
                ),
                buyer_address="",
            )
            payload.update(
                {
                    "available": True,
                    "transaction": {
                        "to_address": prepared.to_address,
                        "amount_nano": prepared.amount_nano,
                        "payload_boc": prepared.payload_boc,
                        "valid_until": prepared.valid_until,
                        "requires_client_sdk": prepared.requires_client_sdk,
                        "notes": prepared.notes,
                    },
                }
            )
        except (CapabilityNotSupported, ProviderUnavailable, ProviderError) as exc:
            payload["unavailable_reason"] = str(exc)
            payload["alternatives"] = [
                adapter.describe() for adapter in get_adapters().values()
            ]
        return payload

    async def prepare_sell(
        self, *, nft_address: str, price_ton: Any, marketplace: str | None = None
    ) -> dict[str, Any]:
        """Build the listing confirmation screen."""
        result = await self.session.execute(select(NFT).where(NFT.address == nft_address))
        nft = result.scalar_one_or_none()
        if nft is None:
            raise NotFoundError("NFT not found in the local index")

        collection = (
            await self.session.get(Collection, nft.collection_id) if nft.collection_id else None
        )
        floor = collection.floor_price_ton if collection else None
        price = quantize_ton(d(price_ton))
        costs = compute_costs(price)
        proceeds = quantize_ton(
            price
            - d(costs["marketplace_fee"])
            - d(costs["royalty"])
            - d(costs["network_fee"])
        )

        payload: dict[str, Any] = {
            "available": False,
            "nft": {
                "address": nft.address,
                "name": nft.name,
                "image_url": nft.image_url,
                "number": nft.number_value,
            },
            "collection": {
                "address": collection.address if collection else None,
                "name": collection.name if collection else None,
            },
            "floor_ton": str(floor) if floor else None,
            "suggested_range": {
                "low": str(quantize_ton(d(floor) * d("0.95"))) if floor else None,
                "high": str(quantize_ton(d(floor) * d("1.35"))) if floor else None,
            },
            "price_ton": str(price),
            "marketplace_fee_ton": costs["marketplace_fee"],
            "royalty_ton": costs["royalty"],
            "network_fee_ton": costs["network_fee"],
            "expected_proceeds_ton": str(proceeds),
            "network": self.settings.ton_network,
            "requires_wallet_approval": True,
            "disclaimer": "Listing does not guarantee a sale.",
        }

        adapter = self._adapter(marketplace)
        try:
            prepared = await adapter.prepare_sell_transaction(nft.address, price, seller_address="")
            payload.update(
                {
                    "available": True,
                    "transaction": {
                        "to_address": prepared.to_address,
                        "amount_nano": prepared.amount_nano,
                        "payload_boc": prepared.payload_boc,
                        "requires_client_sdk": prepared.requires_client_sdk,
                        "notes": prepared.notes,
                    },
                }
            )
        except (CapabilityNotSupported, ProviderUnavailable, ProviderError) as exc:
            payload["unavailable_reason"] = str(exc)
            payload["alternatives"] = [a.describe() for a in get_adapters().values()]
        return payload

    # ---------------------------------------------------------- submission
    async def submit_transaction(
        self,
        *,
        user: User,
        kind: TxKind | str,
        wallet_address: str,
        tx_hash: str | None = None,
        subject_address: str | None = None,
        provider: str | None = None,
        amount_ton: Any | None = None,
        payload: dict | None = None,
    ) -> Transaction:
        """Record a user-broadcast transaction (never signed by the backend)."""
        if not self.settings.enable_real_trading:
            raise TradingDisabled(
                "Real trading is disabled. Enable ENABLE_REAL_TRADING to record "
                "live transactions, or use Paper Mode."
            )
        if not wallet_address:
            raise WalletNotConnected()

        transaction = Transaction(
            user_id=user.id,
            wallet_address=wallet_address,
            network=self.settings.ton_network,
            kind=TxKind(str(kind)).value,
            status=TxStatus.PENDING.value,
            provider=provider,
            subject_address=subject_address,
            tx_hash=tx_hash,
            amount_ton=quantize_ton(d(amount_ton)) if amount_ton is not None else None,
            payload=payload or {},
            submitted_at=_now(),
        )
        self.session.add(transaction)
        await self.session.flush()
        return transaction

    async def verify_transaction(
        self, transaction: Transaction, *, to_address: str | None = None
    ) -> Transaction:
        """Confirm (or reject) a transaction using indexed blockchain data."""
        verifier = TransactionVerifier(self.market.toncenter)
        if transaction.tx_hash:
            result = await verifier.verify_by_hash(transaction.tx_hash)
        else:
            result = await verifier.find_transaction(
                transaction.wallet_address or "",
                to_address=to_address,
                min_amount_nano=(
                    nano_from_ton(transaction.amount_ton) if transaction.amount_ton else None
                ),
            )

        if result.confirmed and result.success:
            transaction.status = TxStatus.CONFIRMED.value
            transaction.tx_hash = result.tx_hash or transaction.tx_hash
            transaction.lt = result.lt
            transaction.confirmed_at = _now()
            transaction.payload = {
                **(transaction.payload or {}),
                "verification": {"lt": result.lt, "utime": result.utime},
            }
        elif result.confirmed:
            transaction.status = TxStatus.FAILED.value
            transaction.error = "transaction found on chain but execution failed"
        else:
            transaction.error = result.reason or "not found yet"
        await self.session.flush()
        return transaction

    async def list_transactions(self, user_id: int, *, limit: int = 25) -> Sequence[Transaction]:
        result = await self.session.execute(
            select(Transaction)
            .where(Transaction.user_id == user_id)
            .order_by(Transaction.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    # -------------------------------------------------------------- helpers
    def _adapter(self, marketplace: str | None = None):
        name = marketplace or Marketplace.PORTALS.value
        try:
            return get_adapter(name)
        except KeyError:
            return get_adapter(Marketplace.PORTALS.value)

    async def _find_listing(
        self, *, nft_address: str | None, listing_id: str | None
    ) -> MarketplaceListing | None:
        if listing_id:
            result = await self.session.execute(
                select(MarketplaceListing).where(
                    MarketplaceListing.listing_id == listing_id,
                    MarketplaceListing.is_active.is_(True),
                )
            )
            return result.scalar_one_or_none()
        if nft_address:
            result = await self.session.execute(
                select(MarketplaceListing)
                .join(NFT, NFT.id == MarketplaceListing.nft_id)
                .where(NFT.address == nft_address, MarketplaceListing.is_active.is_(True))
                .order_by(MarketplaceListing.price_ton.asc())
                .limit(1)
            )
            return result.scalar_one_or_none()
        return None
