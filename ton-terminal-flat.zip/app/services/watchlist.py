"""Watchlist: collections, NFTs, traits, numbers and price levels."""
from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import ValidationError
from app.core.money import d
from app.models.enums import WatchCondition, WatchTarget
from app.models.orm import NFT, MarketplaceListing, Watchlist
from app.services.market import MarketService


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class WatchlistService:
    def __init__(self, session: AsyncSession, market: MarketService | None = None) -> None:
        self.session = session
        self.market = market or MarketService(session)

    async def add(
        self,
        *,
        user_id: int,
        target_type: WatchTarget | str,
        target_ref: str,
        condition: WatchCondition | str = WatchCondition.PRICE_BELOW,
        threshold: Any | None = None,
        label: str | None = None,
        extra: dict | None = None,
    ) -> Watchlist:
        target_type = WatchTarget(str(target_type))
        condition = WatchCondition(str(condition))
        if condition in {
            WatchCondition.PRICE_BELOW,
            WatchCondition.PRICE_ABOVE,
            WatchCondition.FLOOR_BELOW,
            WatchCondition.FLOOR_ABOVE,
            WatchCondition.DISCOUNT_ABOVE,
        } and threshold is None:
            raise ValidationError("This condition requires a threshold value")

        watch = Watchlist(
            user_id=user_id,
            target_type=target_type.value,
            target_ref=target_ref,
            label=label,
            condition=condition.value,
            threshold=d(threshold) if threshold is not None else None,
            extra=extra or {},
        )
        self.session.add(watch)
        await self.session.flush()
        return watch

    async def list(self, user_id: int, *, active_only: bool = True) -> Sequence[Watchlist]:
        query = select(Watchlist).where(Watchlist.user_id == user_id)
        if active_only:
            query = query.where(Watchlist.is_active.is_(True))
        result = await self.session.execute(query.order_by(Watchlist.created_at.desc()))
        return list(result.scalars().all())

    async def remove(self, user_id: int, watch_id: int) -> bool:
        watch = await self.session.get(Watchlist, watch_id)
        if watch is None or watch.user_id != user_id:
            return False
        await self.session.delete(watch)
        await self.session.flush()
        return True

    async def toggle(self, user_id: int, watch_id: int, active: bool) -> Watchlist | None:
        watch = await self.session.get(Watchlist, watch_id)
        if watch is None or watch.user_id != user_id:
            return None
        watch.is_active = active
        await self.session.flush()
        return watch

    # ------------------------------------------------------------ triggers
    async def current_value(self, watch: Watchlist) -> tuple[Any | None, str]:
        """Resolve the observable value behind a watch: (value, description)."""
        if watch.target_type in {WatchTarget.NFT.value, WatchTarget.PRICE.value}:
            listing = (
                await self.session.execute(
                    select(MarketplaceListing)
                    .join(NFT, NFT.id == MarketplaceListing.nft_id)
                    .where(
                        NFT.address == watch.target_ref,
                        MarketplaceListing.is_active.is_(True),
                    )
                    .order_by(MarketplaceListing.price_ton.asc())
                    .limit(1)
                )
            ).scalar_one_or_none()
            return (listing.price_ton if listing else None, "listing price")
        if watch.target_type == WatchTarget.COLLECTION.value:
            collection = await self.market.ensure_collection(watch.target_ref)
            return (collection.floor_price_ton, "collection floor")
        return (None, "unsupported target")

    async def evaluate(self, watch: Watchlist) -> tuple[bool, dict[str, Any]]:
        value, description = await self.current_value(watch)
        threshold = d(watch.threshold) if watch.threshold is not None else None
        triggered = False
        if value is not None and threshold is not None:
            value_v = d(value)
            condition = WatchCondition(watch.condition)
            triggered = {
                WatchCondition.PRICE_BELOW: value_v <= threshold,
                WatchCondition.PRICE_ABOVE: value_v >= threshold,
                WatchCondition.FLOOR_BELOW: value_v <= threshold,
                WatchCondition.FLOOR_ABOVE: value_v >= threshold,
                WatchCondition.DISCOUNT_ABOVE: False,  # needs a fair-value context
            }[condition]
        return triggered, {
            "watch_id": watch.id,
            "target": watch.target_ref,
            "target_type": watch.target_type,
            "condition": watch.condition,
            "threshold": str(threshold) if threshold is not None else None,
            "observed": str(value) if value is not None else None,
            "observed_metric": description,
        }

    async def check_all(self, user_id: int) -> list[dict[str, Any]]:
        triggered: list[dict[str, Any]] = []
        for watch in await self.list(user_id):
            hit, payload = await self.evaluate(watch)
            if hit:
                watch.trigger_count += 1
                watch.last_triggered_at = _now()
                triggered.append(payload)
        await self.session.flush()
        return triggered
