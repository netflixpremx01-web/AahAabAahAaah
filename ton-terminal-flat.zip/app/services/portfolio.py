"""Portfolio tracking: holdings, balances, realised/unrealised P/L.

Every number is derived from indexed blockchain data (TON Center API v3):
ownership from ``GET /nft/items?owner_address=``, balances from
``GET /accountStates`` / ``GET /jetton/wallets`` and trade history from
``GET /actions?action_type=nft_purchase``.

Theoretical (mark-to-floor) and realised P/L are always reported separately.
"""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import get_settings
from app.core.constants import USDT_MASTER
from app.core.logging import get_logger
from app.core.money import d, quantize_ton, ton_from_nano
from app.integrations.toncenter.client import TonCenterClient
from app.models.enums import PortfolioSource
from app.models.orm import NFT, MarketplaceListing, PortfolioPosition, Wallet
from app.services.market import MarketService

logger = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def _norm(address: str | None) -> str:
    return (address or "").strip().lower().replace("-1:", "0:")


class PortfolioService:
    def __init__(
        self,
        session: AsyncSession,
        *,
        toncenter: TonCenterClient | None = None,
        market: MarketService | None = None,
    ) -> None:
        self.session = session
        self.toncenter = toncenter or TonCenterClient()
        self.market = market or MarketService(session, toncenter=self.toncenter)
        self.settings = get_settings()

    # ------------------------------------------------------------ balances
    async def balances(self, wallet: Wallet) -> dict[str, Any]:
        ton_nano = await self.toncenter.get_balance_ton(wallet.address)
        usdt_raw = await self.toncenter.get_jetton_balance(
            wallet.address, USDT_MASTER[self.settings.ton_network]
        )
        usdt_decimals = 6
        return {
            "address": wallet.address,
            "network": wallet.network,
            "ton": str(ton_from_nano(ton_nano)),
            "ton_nano": ton_nano,
            "usdt": str((d(usdt_raw) / (10**usdt_decimals)).quantize(d("0.000001"))),
        }

    # -------------------------------------------------------------- syncing
    async def sync_wallet(self, wallet: Wallet, *, item_limit: int = 200) -> dict[str, Any]:
        """Sync owned NFTs, entry prices and realised sales for a wallet."""
        owned: list[NFT] = []
        async for item in self.toncenter.iter_owner_nft_items(
            wallet.address, page_size=100, max_items=item_limit
        ):
            nft = await self._upsert_owned_nft(item, wallet)
            owned.append(nft)
        await self.session.flush()

        entry_prices = await self._entry_prices(wallet.address)
        realized = await self._sync_sold_positions(wallet)

        for nft in owned:
            position = await self._ensure_position(wallet, nft)
            entry = entry_prices.get(_norm(nft.address))
            if entry is not None:
                position.avg_entry_ton = entry
            floor = await self._collection_floor(nft.collection_id)
            position.floor_ton = floor
            position.last_price_ton = floor
            if position.avg_entry_ton and floor:
                position.unrealized_pnl_ton = quantize_ton(d(floor) - d(position.avg_entry_ton))
            position.last_updated_at = _now()
        await self.session.flush()

        wallet.last_synced_at = _now()
        await self.session.flush()
        return {
            "wallet": wallet.address,
            "nfts_synced": len(owned),
            "realized_trades": realized,
        }

    async def _upsert_owned_nft(self, item: dict[str, Any], wallet: Wallet) -> NFT:
        address = item.get("address")
        result = await self.session.execute(select(NFT).where(NFT.address == address))
        nft = result.scalar_one_or_none()
        if nft is None:
            nft = NFT(address=address, network=wallet.network)
            self.session.add(nft)
            await self.session.flush()
        nft.owner_address = item.get("owner_address") or wallet.address
        nft.index = str(item.get("index")) if item.get("index") is not None else nft.index
        collection_address = item.get("collection_address") or (
            (item.get("collection") or {}).get("address")
        )
        if collection_address and not nft.collection_id:
            collection = await self.market.ensure_collection(collection_address)
            nft.collection_id = collection.id
        await self.session.flush()
        return nft

    async def _ensure_position(self, wallet: Wallet, nft: NFT) -> PortfolioPosition:
        result = await self.session.execute(
            select(PortfolioPosition).where(
                PortfolioPosition.user_id == wallet.user_id, PortfolioPosition.nft_id == nft.id
            )
        )
        position = result.scalar_one_or_none()
        if position is None:
            position = PortfolioPosition(
                user_id=wallet.user_id,
                wallet_address=wallet.address,
                nft_id=nft.id,
                collection_id=nft.collection_id,
                quantity=1,
                source=PortfolioSource.CHAIN.value,
            )
            self.session.add(position)
            await self.session.flush()
        return position

    async def _entry_prices(self, address: str) -> dict[str, Any]:
        """Average acquisition price per NFT from ``nft_purchase`` actions."""
        actions = await self.toncenter.get_nft_purchases(owner_address=address, limit=200)
        totals: dict[str, list] = {}
        for action in actions:
            details = action.get("details") or {}
            if _norm(details.get("new_owner")) != _norm(address):
                continue
            nft_address = _norm(details.get("nft_item"))
            price = ton_from_nano(details.get("price"))
            if price <= 0:
                continue
            totals.setdefault(nft_address, []).append(price)
        return {
            key: quantize_ton(sum(values, d("0")) / len(values)) for key, values in totals.items()
        }

    async def _sync_sold_positions(self, wallet: Wallet) -> int:
        actions = await self.toncenter.get_nft_purchases(
            owner_address=wallet.address, limit=200
        )
        count = 0
        for action in actions:
            details = action.get("details") or {}
            if _norm(details.get("old_owner")) != _norm(wallet.address):
                continue
            nft_address = details.get("nft_item")
            if not nft_address:
                continue
            result = await self.session.execute(select(NFT).where(NFT.address == nft_address))
            nft = result.scalar_one_or_none()
            if nft is None:
                continue
            sale_price = ton_from_nano(details.get("price"))
            position_result = await self.session.execute(
                select(PortfolioPosition).where(
                    PortfolioPosition.user_id == wallet.user_id,
                    PortfolioPosition.nft_id == nft.id,
                )
            )
            position = position_result.scalar_one_or_none()
            if position is None:
                continue
            entry = d(position.avg_entry_ton) if position.avg_entry_ton else d("0")
            position.realized_pnl_ton = quantize_ton(
                d(position.realized_pnl_ton) + (sale_price - entry)
            )
            position.avg_entry_ton = None
            position.last_updated_at = _now()
            count += 1
        await self.session.flush()
        return count

    async def _collection_floor(self, collection_id: int | None):
        if not collection_id:
            return None
        return await self.session.scalar(
            select(func.min(MarketplaceListing.price_ton)).where(
                MarketplaceListing.collection_id == collection_id,
                MarketplaceListing.is_active.is_(True),
            )
        )

    # ------------------------------------------------------------- summary
    async def summary(self, user_id: int, wallet: Wallet | None = None) -> dict[str, Any]:
        positions = (
            await self.session.execute(
                select(PortfolioPosition)
                .where(PortfolioPosition.user_id == user_id)
                .options(selectinload(PortfolioPosition.nft))
            )
        ).scalars().all()

        estimated_value = d("0")
        unrealized = d("0")
        realized = d("0")
        holdings: list[dict[str, Any]] = []
        for position in positions:
            floor = d(position.floor_ton) if position.floor_ton else d("0")
            estimated_value += floor
            unrealized += d(position.unrealized_pnl_ton)
            realized += d(position.realized_pnl_ton)
            nft = position.nft
            holdings.append(
                {
                    "nft_address": nft.address if nft else None,
                    "name": nft.name if nft else None,
                    "image_url": nft.image_url if nft else None,
                    "number": nft.number_value if nft else None,
                    "collection_address": None,
                    "avg_entry_ton": str(position.avg_entry_ton)
                    if position.avg_entry_ton
                    else None,
                    "floor_ton": str(position.floor_ton) if position.floor_ton else None,
                    "unrealized_pnl_ton": str(position.unrealized_pnl_ton),
                    "realized_pnl_ton": str(position.realized_pnl_ton),
                }
            )

        balances = await self.balances(wallet) if wallet else None
        return {
            "wallet": {
                "address": wallet.address if wallet else None,
                "verified": wallet.verified if wallet else False,
                "network": wallet.network if wallet else self.settings.ton_network,
            },
            "balances": balances,
            "holdings_count": len(holdings),
            "holdings": holdings,
            "estimated_nft_value_ton": str(quantize_ton(estimated_value)),
            "unrealized_pnl_ton": str(quantize_ton(unrealized)),
            "realized_pnl_ton": str(quantize_ton(realized)),
            "note": (
                "Unrealised P/L is mark-to-floor (theoretical). Realised P/L comes "
                "from confirmed on-chain sales."
            ),
        }

    async def history(self, user_id: int, wallet: Wallet | None, *, limit: int = 50) -> dict[str, Any]:
        """Purchase and sale history derived from indexed actions."""
        purchases: list[dict[str, Any]] = []
        sales: list[dict[str, Any]] = []
        if wallet:
            actions = await self.toncenter.get_nft_purchases(
                owner_address=wallet.address, limit=limit
            )
            for action in actions:
                details = action.get("details") or {}
                record = {
                    "nft": details.get("nft_item"),
                    "collection": details.get("nft_collection"),
                    "price_ton": str(ton_from_nano(details.get("price"))),
                    "ts": datetime.fromtimestamp(
                        int(action.get("end_utime") or 0), tz=UTC
                    )
                    .replace(tzinfo=None)
                    .isoformat(),
                    "tx": action.get("trace_id"),
                }
                if _norm(details.get("new_owner")) == _norm(wallet.address):
                    purchases.append(record)
                elif _norm(details.get("old_owner")) == _norm(wallet.address):
                    sales.append(record)
        return {"purchases": purchases, "sales": sales}

    async def clear_positions(self, user_id: int, wallet_address: str | None = None) -> int:
        query = delete(PortfolioPosition).where(PortfolioPosition.user_id == user_id)
        if wallet_address:
            query = query.where(PortfolioPosition.wallet_address == wallet_address)
        result = await self.session.execute(query)
        await self.session.flush()
        return int(result.rowcount or 0)
