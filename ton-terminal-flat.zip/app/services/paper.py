"""Paper trading: fully simulated positions, no funds involved.

Tracks ROI, P/L, win rate, drawdown, best and worst trade so users can validate
a strategy before risking anything.
"""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.errors import TradingDisabled, ValidationError
from app.core.money import apply_bps, d, quantize_ton
from app.models.enums import TradeSide
from app.models.orm import NFT, Collection, PaperTrade
from app.radar.scoring import compute_costs


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class PaperTradingService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.settings = get_settings()

    async def _resolve_nft(self, nft_address: str | None) -> NFT | None:
        if not nft_address:
            return None
        result = await self.session.execute(select(NFT).where(NFT.address == nft_address))
        return result.scalar_one_or_none()

    async def open_position(
        self,
        *,
        user_id: int,
        entry_price: Any,
        nft_address: str | None = None,
        collection_address: str | None = None,
        strategy_id: int | None = None,
        notes: str | None = None,
    ) -> PaperTrade:
        if not self.settings.enable_paper_trading:
            raise TradingDisabled("Paper trading is disabled on this deployment")
        nft = await self._resolve_nft(nft_address)
        collection = None
        if collection_address:
            result = await self.session.execute(
                select(Collection).where(Collection.address == collection_address)
            )
            collection = result.scalar_one_or_none()

        price = quantize_ton(d(entry_price))
        costs = compute_costs(price)
        trade = PaperTrade(
            user_id=user_id,
            strategy_id=strategy_id,
            nft_id=nft.id if nft else None,
            collection_id=collection.id if collection else None,
            side=TradeSide.BUY.value,
            status="open",
            entry_price_ton=price,
            fees_ton=d(costs["network_fee"]),
            opened_at=_now(),
            notes=notes,
        )
        self.session.add(trade)
        await self.session.flush()
        return trade

    async def close_position(
        self,
        *,
        user_id: int,
        trade_id: int,
        exit_price: Any,
        quantity: int = 1,
    ) -> PaperTrade:
        trade = await self.session.get(PaperTrade, trade_id)
        if trade is None or trade.user_id != user_id:
            raise ValidationError("paper trade not found")
        if trade.status != "open":
            raise ValidationError("paper trade is already closed")

        entry = d(trade.entry_price_ton)
        exit_v = quantize_ton(d(exit_price))
        exit_costs = apply_bps(exit_v, self.settings.default_marketplace_fee_bps) + apply_bps(
            exit_v, self.settings.default_royalty_bps
        )
        pnl = quantize_ton((exit_v - entry) * quantity - exit_costs - d(trade.fees_ton))
        invested = entry * quantity
        trade.exit_price_ton = exit_v
        trade.quantity = quantity
        trade.pnl_ton = pnl
        trade.pnl_pct = ((pnl / invested) * 100).quantize(d("0.01")) if invested > 0 else d("0")
        trade.status = "closed"
        trade.closed_at = _now()
        trade.fees_ton = quantize_ton(d(trade.fees_ton) + exit_costs)
        await self.session.flush()
        return trade

    async def open_positions(self, user_id: int) -> list[PaperTrade]:
        result = await self.session.execute(
            select(PaperTrade)
            .where(PaperTrade.user_id == user_id, PaperTrade.status == "open")
            .order_by(PaperTrade.opened_at.desc())
        )
        return list(result.scalars().all())

    async def closed_positions(self, user_id: int, *, limit: int = 100) -> list[PaperTrade]:
        result = await self.session.execute(
            select(PaperTrade)
            .where(PaperTrade.user_id == user_id, PaperTrade.status == "closed")
            .order_by(PaperTrade.closed_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def stats(self, user_id: int) -> dict[str, Any]:
        closed = await self.closed_positions(user_id, limit=1000)
        open_trades = await self.open_positions(user_id)
        if not closed:
            return {
                "trades": 0,
                "open": len(open_trades),
                "win_rate_pct": "0",
                "realized_pnl_ton": "0",
                "avg_roi_pct": "0",
                "max_drawdown_ton": "0",
                "best_trade_ton": "0",
                "worst_trade_ton": "0",
                "note": "Simulated trading only - no funds are involved.",
            }

        pnls = [d(trade.pnl_ton or 0) for trade in closed]
        wins = [p for p in pnls if p > 0]
        equity, peak, max_drawdown = d("0"), d("0"), d("0")
        for pnl in pnls:
            equity += pnl
            peak = max(peak, equity)
            max_drawdown = max(max_drawdown, peak - equity)

        return {
            "trades": len(closed),
            "open": len(open_trades),
            "win_rate_pct": str((d(len(wins)) / d(len(pnls)) * 100).quantize(d("0.01"))),
            "realized_pnl_ton": str(quantize_ton(sum(pnls, d("0")))),
            "avg_roi_pct": str(
                (sum((d(t.pnl_pct or 0) for t in closed), d("0")) / len(closed)).quantize(d("0.01"))
            ),
            "max_drawdown_ton": str(quantize_ton(max_drawdown)),
            "best_trade_ton": str(quantize_ton(max(pnls))),
            "worst_trade_ton": str(quantize_ton(min(pnls))),
            "note": "Simulated trading only - no funds are involved.",
        }
