"""User lifecycle (Telegram identity, preferences, notification settings)."""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import NotificationCategory
from app.models.orm import User

DEFAULT_NOTIFICATION_PREFS: dict[str, bool] = {
    category.value: True for category in NotificationCategory
}
DEFAULT_UI_PREFS: dict[str, Any] = {
    "paper_mode": True,
    "default_slippage": "0.01",
    "risk_profile": "balanced",
}


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


async def get_user_by_telegram_id(session: AsyncSession, telegram_id: int) -> User | None:
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    return result.scalar_one_or_none()


async def get_user(session: AsyncSession, user_id: int) -> User | None:
    return await session.get(User, user_id)


async def get_or_create_user(
    session: AsyncSession,
    *,
    telegram_id: int,
    username: str | None = None,
    first_name: str | None = None,
    last_name: str | None = None,
    language_code: str | None = None,
    is_premium: bool = False,
    photo_url: str | None = None,
) -> User:
    user = await get_user_by_telegram_id(session, telegram_id)
    if user is None:
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            language_code=language_code,
            is_premium=is_premium,
            photo_url=photo_url,
            paper_balance_ton=100,
            notification_prefs=dict(DEFAULT_NOTIFICATION_PREFS),
            ui_prefs=dict(DEFAULT_UI_PREFS),
            last_seen_at=_now(),
        )
        session.add(user)
        await session.flush()
        return user

    user.last_seen_at = _now()
    for field, value in (
        ("username", username),
        ("first_name", first_name),
        ("last_name", last_name),
        ("language_code", language_code),
        ("photo_url", photo_url),
    ):
        if value:
            setattr(user, field, value)
    if is_premium:
        user.is_premium = True
    await session.flush()
    return user


def notification_enabled(user: User, category: NotificationCategory | str) -> bool:
    prefs = user.notification_prefs or {}
    key = category.value if isinstance(category, NotificationCategory) else category
    return bool(prefs.get(key, True))


async def update_notification_prefs(
    session: AsyncSession, user: User, updates: dict[str, bool]
) -> User:
    prefs = dict(user.notification_prefs or DEFAULT_NOTIFICATION_PREFS)
    for key, value in updates.items():
        if key in DEFAULT_NOTIFICATION_PREFS:
            prefs[key] = bool(value)
    user.notification_prefs = prefs
    await session.flush()
    return user


async def update_ui_prefs(session: AsyncSession, user: User, updates: dict[str, Any]) -> User:
    prefs = dict(user.ui_prefs or DEFAULT_UI_PREFS)
    prefs.update({k: v for k, v in updates.items() if v is not None})
    user.ui_prefs = prefs
    await session.flush()
    return user
