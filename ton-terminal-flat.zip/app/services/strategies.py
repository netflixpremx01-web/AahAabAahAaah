"""Strategy builder and evaluation.

Modes:
* ``alert``    - notify only,
* ``paper``    - open simulated positions (no funds involved),
* ``assisted`` - prepare the transaction, always requiring explicit wallet
                 approval in the user's own wallet app.
"""
from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import ValidationError
from app.core.money import d
from app.models.enums import StrategyMode
from app.models.orm import Opportunity, Strategy
from app.nft.numbers import matches_pattern
from app.services.paper import PaperTradingService

DEFAULT_RULES: dict[str, Any] = {
    "min_roi_pct": 25,
    "max_buy_price_ton": 100,
    "min_rarity": 80,
    "min_liquidity": 70,
    "min_confidence": 80,
    "min_score": 60,
    "max_risk": "medium",
    "collections": [],
    "traits": {},
    "number_patterns": [],
}

RISK_ORDER = {"low": 0, "medium": 1, "high": 2, "extreme": 3}


def _now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class StrategyService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(
        self,
        *,
        user_id: int,
        name: str,
        mode: StrategyMode | str = StrategyMode.ALERT,
        rules: dict[str, Any] | None = None,
    ) -> Strategy:
        mode = StrategyMode(str(mode))
        strategy = Strategy(
            user_id=user_id,
            name=name[:128],
            mode=mode.value,
            rules={**DEFAULT_RULES, **(rules or {})},
            stats={"matches": 0, "paper_trades": 0, "alerts": 0},
        )
        self.session.add(strategy)
        await self.session.flush()
        return strategy

    async def update(self, user_id: int, strategy_id: int, **fields: Any) -> Strategy:
        strategy = await self.session.get(Strategy, strategy_id)
        if strategy is None or strategy.user_id != user_id:
            raise ValidationError("strategy not found")
        if "mode" in fields and fields["mode"]:
            strategy.mode = StrategyMode(str(fields["mode"])).value
        if "name" in fields and fields["name"]:
            strategy.name = str(fields["name"])[:128]
        if "rules" in fields and isinstance(fields["rules"], dict):
            strategy.rules = {**strategy.rules, **fields["rules"]}
        if "is_active" in fields and fields["is_active"] is not None:
            strategy.is_active = bool(fields["is_active"])
        await self.session.flush()
        return strategy

    async def list(self, user_id: int, *, active_only: bool = False) -> Sequence[Strategy]:
        query = select(Strategy).where(Strategy.user_id == user_id)
        if active_only:
            query = query.where(Strategy.is_active.is_(True))
        result = await self.session.execute(query.order_by(Strategy.created_at.desc()))
        return list(result.scalars().all())

    async def delete(self, user_id: int, strategy_id: int) -> bool:
        strategy = await self.session.get(Strategy, strategy_id)
        if strategy is None or strategy.user_id != user_id:
            return False
        await self.session.delete(strategy)
        await self.session.flush()
        return True

    # ---------------------------------------------------------- evaluation
    def matches(self, strategy: Strategy, opportunity: Opportunity, **context: Any) -> tuple[bool, list[str]]:
        """Check an opportunity against the strategy rules."""
        rules = {**DEFAULT_RULES, **(strategy.rules or {})}
        reasons: list[str] = []

        def check(condition: bool, message: str) -> bool:
            if not condition:
                reasons.append(message)
            return condition

        ok = True
        ok &= check(
            d(opportunity.roi_pct) >= d(rules.get("min_roi_pct", 0)),
            f"ROI {opportunity.roi_pct}% < {rules.get('min_roi_pct')}%",
        )
        ok &= check(
            d(opportunity.listed_price_ton) <= d(rules.get("max_buy_price_ton", 10**9)),
            f"Price {opportunity.listed_price_ton} > {rules.get('max_buy_price_ton')} TON",
        )
        if rules.get("min_rarity"):
            ok &= check(
                int(opportunity.rarity_score or 0) >= int(rules["min_rarity"]),
                f"Rarity {opportunity.rarity_score} < {rules['min_rarity']}",
            )
        if rules.get("min_liquidity"):
            ok &= check(
                int(opportunity.liquidity_score or 0) >= int(rules["min_liquidity"]),
                f"Liquidity {opportunity.liquidity_score} < {rules['min_liquidity']}",
            )
        if rules.get("min_confidence"):
            ok &= check(
                int(opportunity.confidence or 0) >= int(rules["min_confidence"]),
                f"Confidence {opportunity.confidence} < {rules['min_confidence']}",
            )
        if rules.get("min_score"):
            ok &= check(
                int(opportunity.opportunity_score) >= int(rules["min_score"]),
                f"Score {opportunity.opportunity_score} < {rules['min_score']}",
            )
        max_risk = str(rules.get("max_risk", "high")).lower()
        ok &= check(
            RISK_ORDER.get(str(opportunity.risk_level), 1) <= RISK_ORDER.get(max_risk, 3),
            f"Risk {opportunity.risk_level} above {max_risk}",
        )
        collections = rules.get("collections") or []
        if collections:
            collection_address = context.get("collection_address")
            ok &= check(
                collection_address in collections,
                f"Collection {collection_address} not in strategy scope",
            )
        traits = rules.get("traits") or {}
        if traits:
            nft_traits = context.get("traits") or {}
            for trait_type, value in traits.items():
                ok &= check(
                    str(nft_traits.get(trait_type)) == str(value),
                    f"Trait {trait_type} != {value}",
                )
        patterns = rules.get("number_patterns") or []
        if patterns:
            ok &= check(
                matches_pattern(context.get("number"), patterns),
                f"Number {context.get('number')} does not match {patterns}",
            )
        return ok, reasons

    async def apply(
        self,
        strategy: Strategy,
        opportunity: Opportunity,
        *,
        collection_address: str | None = None,
        traits: dict | None = None,
        number: int | None = None,
        nft_address: str | None = None,
    ) -> dict[str, Any]:
        """Run the strategy against an opportunity in its configured mode."""
        matched, reasons = self.matches(
            strategy, opportunity, collection_address=collection_address, traits=traits, number=number
        )
        if not matched:
            return {"matched": False, "reasons": reasons}

        stats = dict(strategy.stats or {})
        stats["matches"] = int(stats.get("matches", 0)) + 1
        result: dict[str, Any] = {"matched": True, "mode": strategy.mode}

        if strategy.mode == StrategyMode.PAPER.value:
            paper = PaperTradingService(self.session)
            trade = await paper.open_position(
                user_id=strategy.user_id,
                nft_address=nft_address,
                collection_address=collection_address,
                entry_price=d(opportunity.listed_price_ton),
                strategy_id=strategy.id,
                notes=f"auto-opened by strategy '{strategy.name}'",
            )
            stats["paper_trades"] = int(stats.get("paper_trades", 0)) + 1
            result["paper_trade_id"] = trade.id
        elif strategy.mode == StrategyMode.ASSISTED.value:
            result["requires_wallet_approval"] = True
            result["note"] = (
                "Assisted execution prepares the transaction only. The user must "
                "approve it in their own wallet - nothing is signed server-side."
            )
        else:
            stats["alerts"] = int(stats.get("alerts", 0)) + 1
        strategy.stats = stats
        await self.session.flush()
        return result
