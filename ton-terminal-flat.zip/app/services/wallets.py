"""Wallet connection and balances.

The backend stores **public** wallet data only: address, network, public key.
Seed phrases and private keys are never requested, transmitted or stored.
"""
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.errors import AuthenticationError
from app.core.money import ton_from_nano
from app.integrations.toncenter.client import TonCenterClient
from app.integrations.tonconnect.verify import (
    WalletAuth,
    expected_domain,
    verify_ton_proof,
)
from app.models.orm import Wallet


async def list_wallets(session: AsyncSession, user_id: int) -> list[Wallet]:
    result = await session.execute(
        select(Wallet).where(Wallet.user_id == user_id).order_by(Wallet.is_primary.desc())
    )
    return list(result.scalars().all())


async def get_primary_wallet(session: AsyncSession, user_id: int) -> Wallet | None:
    wallets = await list_wallets(session, user_id)
    return next((w for w in wallets if w.is_primary), wallets[0] if wallets else None)


async def connect_wallet(
    session: AsyncSession,
    *,
    user_id: int,
    auth: WalletAuth,
    verify_proof: bool = True,
) -> Wallet:
    """Register a wallet address for a user after optional ``ton_proof`` check."""
    if not auth.address:
        raise AuthenticationError("wallet address is required")
    if verify_proof and auth.proof is not None:
        verify_ton_proof(auth, expected_domain=expected_domain())
    elif verify_proof and auth.proof is None:
        # No proof supplied: the address is still stored but remains unverified.
        pass

    settings = get_settings()
    result = await session.execute(
        select(Wallet).where(Wallet.user_id == user_id, Wallet.address == auth.address)
    )
    wallet = result.scalar_one_or_none()
    if wallet is None:
        wallet = Wallet(
            user_id=user_id,
            address=auth.address,
            network=auth.network or settings.ton_network,
            wallet_app=auth.wallet_app,
            public_key=auth.public_key or None,
            is_primary=False,
            verified=False,
        )
        session.add(wallet)
    wallet.wallet_app = auth.wallet_app or wallet.wallet_app
    wallet.public_key = auth.public_key or wallet.public_key
    wallet.verified = True if (verify_proof and auth.proof is not None) else wallet.verified
    wallet.verified_at = datetime.now(UTC).replace(tzinfo=None) if wallet.verified else None
    existing = await list_wallets(session, user_id)
    if len(existing) <= 1:
        wallet.is_primary = True
    await session.flush()
    return wallet


async def set_primary(session: AsyncSession, user_id: int, address: str) -> Wallet:
    wallets = await list_wallets(session, user_id)
    target = next((w for w in wallets if w.address == address), None)
    if target is None:
        raise AuthenticationError("wallet not found")
    for wallet in wallets:
        wallet.is_primary = wallet.id == target.id
    await session.flush()
    return target


async def disconnect_wallet(session: AsyncSession, user_id: int, address: str) -> None:
    await session.execute(
        delete(Wallet).where(Wallet.user_id == user_id, Wallet.address == address)
    )
    await session.flush()
    wallets = await list_wallets(session, user_id)
    if wallets and not any(w.is_primary for w in wallets):
        wallets[0].is_primary = True
        await session.flush()


async def sync_balances(session: AsyncSession, wallet: Wallet) -> dict[str, str]:
    """Refresh TON and USDT balances from the chain (TON Center)."""
    from app.core.constants import USDT_MASTER

    settings = get_settings()
    client = TonCenterClient()
    ton_nano = await client.get_balance_ton(wallet.address)
    wallet.balance_ton = ton_from_nano(ton_nano)
    usdt_raw = await client.get_jetton_balance(wallet.address, USDT_MASTER[settings.ton_network])
    wallet.last_synced_at = datetime.now(UTC).replace(tzinfo=None)
    await session.flush()
    return {
        "address": wallet.address,
        "ton": str(wallet.balance_ton),
        "usdt_raw": str(usdt_raw),
        "synced_at": wallet.last_synced_at.isoformat() if wallet.last_synced_at else None,
    }
