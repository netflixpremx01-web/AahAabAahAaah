"""Fair value engine.

Fair value is an **estimate** built from observable data: floor, comparable
sales, trait/number rarity and liquidity. It is explicitly *not* a guaranteed
resale price. Every result carries a confidence score and a human readable
explanation of how it was produced.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP

from app.core.money import clamp, d, median, positive, quantize_ton

MAX_RARITY_ADJUSTMENT = d("0.45")   # ±45% at the extremes of the rarity scale
MAX_NUMBER_PREMIUM = d("3.0")       # cap observed/derived number premiums
BASE_SPREAD_PCT = d("10")           # ±10% base uncertainty band


@dataclass
class FairValueInput:
    floor: object | None = None
    comparable_sales: Sequence[object] = ()      # sales of similar NFTs
    collection_sales: Sequence[object] = ()      # recent collection-wide sales
    rarity_score: int | None = None              # 0-100
    number_score: int | None = None              # 0-100
    number_premium: object | None = None         # from comparable sales, if any
    number_premium_source: str = "heuristic"
    liquidity_score: int | None = None           # 0-100
    trend: str | None = None                     # bullish | bearish | flat | volatile
    collection_health: int | None = None         # 0-100
    floor_age_hours: float | None = None


@dataclass
class FairValueResult:
    low: object
    mid: object
    high: object
    confidence: int
    method: str
    components: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "low": str(self.low),
            "mid": str(self.mid),
            "high": str(self.high),
            "confidence": self.confidence,
            "method": self.method,
            "components": {k: str(v) for k, v in self.components.items()},
            "notes": self.notes,
        }


def _clamp_factor(value: object, low: object, high: object) -> object:
    return clamp(d(value), d(low), d(high))


def estimate_fair_value(data: FairValueInput) -> FairValueResult:
    """Estimate a fair value range. Pure function - fully unit tested."""
    notes: list[str] = []
    floor = positive(quantize_ton(d(data.floor)))
    comparables = [d(x) for x in data.comparable_sales if d(x) > 0]
    collection_sales = [d(x) for x in data.collection_sales if d(x) > 0]

    # ------------------------------------------------------------ base price
    comp_median = median(comparables)
    sales_median = median(collection_sales)
    if comp_median is not None and floor:
        base = (d("0.6") * comp_median + d("0.4") * floor).quantize(d("0.000000001"))
        method = "comparable-weighted"
    elif comp_median is not None:
        base = comp_median
        method = "comparables-only"
    elif sales_median is not None and floor:
        base = (d("0.5") * sales_median + d("0.5") * floor).quantize(d("0.000000001"))
        method = "collection-sales-weighted"
    elif floor:
        base = floor
        method = "floor-only"
        notes.append("No comparable sales available - estimate is floor based.")
    else:
        return FairValueResult(
            low=d("0"),
            mid=d("0"),
            high=d("0"),
            confidence=0,
            method="insufficient-data",
            notes=["Neither floor nor sales data available."],
        )

    multiplier = d("1")

    # --------------------------------------------------------- rarity factor
    if data.rarity_score is not None:
        rarity_delta = (d(data.rarity_score) - d(50)) / d(50)
        rarity_factor = d("1") + rarity_delta * MAX_RARITY_ADJUSTMENT
        multiplier *= _clamp_factor(rarity_factor, d("0.7"), d("2.2"))
    else:
        notes.append("Rarity data unavailable - no rarity adjustment applied.")

    # --------------------------------------------------------- number factor
    if data.number_premium is not None:
        premium = min(d(data.number_premium), MAX_NUMBER_PREMIUM)
        multiplier *= _clamp_factor(premium, d("0.8"), MAX_NUMBER_PREMIUM)
        notes.append(
            f"Collector-number premium derived from comparable sales "
            f"({data.number_premium_source})."
        )
    elif data.number_score is not None:
        heuristic = d("1") + (d(data.number_score) / d(100)) * d("0.25")
        multiplier *= _clamp_factor(heuristic, d("1"), d("1.25"))
        notes.append("No comparable sales for this number - heuristic premium applied.")

    # ------------------------------------------------------ liquidity factor
    if data.liquidity_score is not None and d(data.liquidity_score) < 50:
        penalty = (d(50) - d(data.liquidity_score)) / d(50) * d("0.15")
        multiplier *= d("1") - penalty
        notes.append("Illiquidity discount applied.")

    # ---------------------------------------------------------- trend factor
    trend = (data.trend or "").lower()
    if trend == "bullish":
        multiplier *= d("1.03")
    elif trend == "bearish":
        multiplier *= d("0.95")
    elif trend == "volatile":
        notes.append("Volatile market - wider uncertainty band.")

    mid = quantize_ton(base * multiplier)

    # ----------------------------------------------------------- confidence
    confidence = 0
    confidence += min(40, int(len(comparables) * 8 + len(collection_sales) * 1.5))
    if data.rarity_score is not None:
        confidence += 15
    if data.liquidity_score is not None:
        confidence += int(d(data.liquidity_score) / 100 * 25)
    if trend in {"bullish", "flat"}:
        confidence += 20
    elif trend == "volatile":
        confidence += 10
    elif trend == "bearish":
        confidence += 12
    if data.floor_age_hours is not None:
        if data.floor_age_hours <= 6:
            confidence += 5
        elif data.floor_age_hours > 48:
            confidence -= 10
            notes.append("Floor price is stale.")
    confidence = int(max(0, min(100, confidence)))

    # -------------------------------------------------------- uncertainty
    spread_pct = BASE_SPREAD_PCT + (d(100 - confidence) * d("0.4"))
    if trend == "volatile":
        spread_pct += d("5")
    spread = (mid * spread_pct / d(100)).quantize(d("0.000000001"), rounding=ROUND_HALF_UP)

    return FairValueResult(
        low=quantize_ton(mid - spread),
        mid=mid,
        high=quantize_ton(mid + spread),
        confidence=confidence,
        method=method,
        components={
            "base": base,
            "multiplier": multiplier.quantize(d("0.0001")),
            "comparables": len(comparables),
            "collection_sales": len(collection_sales),
            "spread_pct": spread_pct.quantize(d("0.01")),
        },
        notes=notes,
    )


def discount_pct(price: object | None, fair_value: object | None) -> object:
    """Discount of ``price`` against the estimated fair value (positive = cheap)."""
    price_v, fair_v = d(price), d(fair_value)
    if price_v <= 0 or fair_v <= 0:
        return d("0")
    return (((fair_v - price_v) / fair_v) * 100).quantize(d("0.01"), rounding=ROUND_HALF_UP)
