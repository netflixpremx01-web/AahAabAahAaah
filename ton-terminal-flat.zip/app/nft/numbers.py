"""Rare / collector number engine.

Detects interesting token numbers (0, 1, 7, 69, 100, 111, 420, 777, 888,
palindromes, repeating digits, sequential and mirrored numbers) and - when
*enough historical sales exist* - derives the actual price premium observed for
those numbers instead of applying a fixed multiplier.
"""
from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field

from app.core.money import d, median

SPECIAL_NUMBERS: dict[int, str] = {
    0: "zero",
    1: "first",
    7: "lucky-seven",
    69: "sixty-nine",
    100: "century",
    111: "triple-one",
    420: "420",
    777: "triple-seven",
    888: "triple-eight",
    1000: "millennium",
    1337: "leet",
    8888: "quad-eight",
    9999: "quad-nine",
}

MIN_COMPARABLES = 8  # minimum sales per bucket before we trust a premium


@dataclass
class NumberProfile:
    value: int | None
    flags: list[str] = field(default_factory=list)
    labels: list[str] = field(default_factory=list)
    base_score: int = 0          # 0-100 heuristic desirability
    observed_premium: object | None = None  # Decimal, from comparable sales
    premium_source: str = "heuristic"
    comparables: int = 0

    @property
    def is_rare(self) -> bool:
        return self.base_score >= 60


def _digits(value: int) -> list[int]:
    return [int(ch) for ch in str(abs(value))]


def is_palindrome(value: int) -> bool:
    text = str(abs(value))
    return len(text) > 1 and text == text[::-1]


def is_repeating(value: int) -> bool:
    digits = _digits(value)
    return len(digits) > 1 and len(set(digits)) == 1


def is_sequential(value: int) -> bool:
    digits = _digits(value)
    if len(digits) < 3:
        return False
    ascending = all(digits[i + 1] - digits[i] == 1 for i in range(len(digits) - 1))
    descending = all(digits[i] - digits[i + 1] == 1 for i in range(len(digits) - 1))
    return ascending or descending


def is_mirrored(value: int) -> bool:
    """1234321, 1221 mirrored halves, or 123321 style."""
    text = str(abs(value))
    if len(text) < 4 or len(text) % 2:
        return False
    half = len(text) // 2
    return text[:half] == text[half:][::-1] or text[:half] == text[half:]


def is_round_number(value: int) -> bool:
    if value <= 0:
        return False
    return value % 10 == 0 and str(value).count("0") >= max(1, len(str(value)) - 2)


def classify(value: int | None) -> NumberProfile:
    """Classify a token number without any price assumption."""
    if value is None:
        return NumberProfile(value=None)
    flags: list[str] = []
    labels: list[str] = []
    score = 0

    if value in SPECIAL_NUMBERS:
        flags.append("special")
        labels.append(SPECIAL_NUMBERS[value])
        score += 60
    if is_repeating(value):
        flags.append("repeating")
        labels.append("repeating-digits")
        score += 45
    if is_palindrome(value):
        flags.append("palindrome")
        labels.append("palindrome")
        score += 40
    if is_sequential(value):
        flags.append("sequential")
        labels.append("sequential")
        score += 25
    if is_mirrored(value):
        flags.append("mirrored")
        labels.append("mirrored")
        score += 15
    if is_round_number(value):
        flags.append("round")
        labels.append("round-number")
        score += 20
    if abs(value) < 10:
        flags.append("single-digit")
        labels.append("single-digit")
        score += 50
    if abs(value) < 100:
        flags.append("low")
        labels.append("low-number")
        score += 25
    return NumberProfile(value=value, flags=flags, labels=labels, base_score=min(100, score))


def collector_score(value: int | None) -> int:
    """0-100 desirability of the number itself (heuristic, price independent)."""
    return classify(value).base_score


def derive_premium(
    value: int | None,
    *,
    rare_sales: Sequence[object],
    baseline_sales: Sequence[object],
    min_comparables: int = MIN_COMPARABLES,
) -> tuple[object | None, str, int]:
    """Derive the price premium for a number from real comparable sales.

    Returns ``(premium_multiplier, source, comparable_count)``. When there is
    not enough data the multiplier is ``None`` and the caller must fall back to
    the heuristic score, clearly labelled as such.
    """
    profile = classify(value)
    if not profile.is_rare:
        return (None, "not-rare", 0)

    rare = sorted(d(x) for x in rare_sales if d(x) > 0)
    base = sorted(d(x) for x in baseline_sales if d(x) > 0)
    if len(rare) < min_comparables or len(base) < min_comparables:
        return (None, "insufficient-data", min(len(rare), len(base)))

    rare_median = median(rare)
    base_median = median(base)
    if rare_median is None or base_median is None or base_median == 0:
        return (None, "insufficient-data", 0)

    premium = (rare_median / base_median).quantize(d("0.0001"))
    return (premium, "comparable-sales", len(rare))


def matches_pattern(value: int | None, patterns: Iterable[str] | None) -> bool:
    """Check a number against user-supplied collector patterns.

    Supported pattern syntax (case insensitive):

    ``420``            exact number
    ``*69``            ends with 69
    ``777*``           starts with 777
    ``palindrome``     named detector
    ``repeating``      named detector
    ``sequential``     named detector
    ``mirrored``       named detector
    ``<100``           numeric comparison
    """
    if value is None:
        return False
    for raw in patterns or []:
        pattern = str(raw).strip().lower()
        if not pattern:
            continue
        if pattern.isdigit():
            if value == int(pattern):
                return True
            continue
        if pattern in {"palindrome", "repeating", "sequential", "mirrored", "round"}:
            detector = {
                "palindrome": is_palindrome,
                "repeating": is_repeating,
                "sequential": is_sequential,
                "mirrored": is_mirrored,
                "round": is_round_number,
            }[pattern]
            if detector(value):
                return True
            continue
        if pattern.startswith("*") and pattern[1:].isdigit():
            if str(value).endswith(pattern[1:]):
                return True
            continue
        if pattern.endswith("*") and pattern[:-1].isdigit():
            if str(value).startswith(pattern[:-1]):
                return True
            continue
        if pattern[:1] in {"<", ">"} and pattern[1:].isdigit():
            operand = int(pattern[1:])
            if (pattern[0] == "<" and value < operand) or (pattern[0] == ">" and value > operand):
                return True
    return False
