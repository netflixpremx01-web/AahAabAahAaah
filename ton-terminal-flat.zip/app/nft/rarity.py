"""Rarity facade: turns raw collection composition into 0-100 scores."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from app.core.money import d
from app.nft.traits import (
    Trait,
    build_trait_index,
    combination_result,
    normalise_scores,
    project_score,
    rarity_score,
    trait_rarities,
)


@dataclass
class RarityReport:
    score: int | None                 # 0-100, normalised across the collection
    raw_score: object | None          # statistical rarity
    percentile: object | None
    rank: int | None
    traits: list[dict]
    combination: dict | None = None
    items_analysed: int = 0

    def as_dict(self) -> dict:
        return {
            "score": self.score,
            "raw_score": str(self.raw_score) if self.raw_score is not None else None,
            "percentile": str(self.percentile) if self.percentile is not None else None,
            "rank": self.rank,
            "traits": self.traits,
            "combination": self.combination,
            "items_analysed": self.items_analysed,
        }


def analyse_collection_rarity(
    *,
    target_traits: Mapping[str, str],
    collection_traits: Sequence[Mapping[str, str]],
    total_items: int | None = None,
    combination_query: Mapping[str, str] | None = None,
) -> RarityReport:
    """Compute rarity of one NFT relative to the collection composition.

    ``collection_traits`` is a list of ``{trait_type: value}`` mappings, one per
    NFT in the collection. ``total_items`` should be the real collection size
    when the sample is partial.
    """
    total = total_items or len(collection_traits)
    if total <= 0 or not collection_traits:
        return RarityReport(score=None, raw_score=None, percentile=None, rank=None, traits=[])

    index: dict[Trait, int] = build_trait_index(collection_traits)
    raw = rarity_score(target_traits, index, total)
    rarities = trait_rarities(target_traits, index, total)

    # Project the target onto the 0-100 scale defined by the collection sample.
    sample_scores = [rarity_score(traits, index, total) for traits in collection_traits]
    target_score = project_score(raw, sample_scores)
    normalised = normalise_scores({str(i): v for i, v in enumerate(sample_scores)})

    rank = 1
    if normalised:
        better = sum(1 for value in normalised.values() if value > target_score)
        rank = better + 1
    percentile = None
    if total:
        percentile = ((d(total - rank + 1) / d(total)) * 100).quantize(d("0.01"))

    combination = None
    if combination_query:
        result = combination_result(combination_query, collection_traits, total_items=total)
        combination = {
            "matches": result.matches,
            "total": result.total,
            "rarity_pct": str(result.rarity_pct),
            "label": result.label,
            "score": result.score,
            "traits": [{"type": t[0], "value": t[1]} for t in result.traits],
        }

    return RarityReport(
        score=target_score,
        raw_score=raw,
        percentile=percentile,
        rank=rank,
        traits=[
            {
                "type": item.trait_type,
                "value": item.trait_value,
                "count": item.count,
                "rarity_pct": str(item.rarity_pct),
            }
            for item in rarities
        ],
        combination=combination,
        items_analysed=len(collection_traits),
    )


def trait_combination_summary(
    query: Mapping[str, str], collection_traits: Sequence[Mapping[str, str]]
) -> dict:
    """Public helper used by the radar and the ``/analyze`` command."""
    return analyse_collection_rarity(
        target_traits=query,
        collection_traits=collection_traits,
        combination_query=query,
    ).as_dict()
