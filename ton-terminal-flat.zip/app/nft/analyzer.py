"""NFT analyser: combines metadata, rarity, fair value and liquidity."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from app.core.money import apply_bps, d, quantize_ton
from app.models.enums import RiskLevel
from app.nft.liquidity import LiquidityInput, LiquidityResult, assess_liquidity
from app.nft.metadata import ResolvedMetadata
from app.nft.numbers import NumberProfile, classify, derive_premium
from app.nft.rarity import RarityReport, analyse_collection_rarity
from app.nft.valuation import FairValueInput, FairValueResult, discount_pct, estimate_fair_value
from app.radar.scoring import (
    OpportunityScore,
    compute_costs,
    compute_opportunity_score,
    evaluate_risk,
)


@dataclass
class MarketSnapshot:
    """Everything the analyser knows about the market around one NFT."""

    floor: Any | None = None
    floor_age_hours: float | None = None
    comparable_sales: Sequence[Any] = ()
    collection_sales: Sequence[Any] = ()
    rare_number_sales: Sequence[Any] = ()
    baseline_sales: Sequence[Any] = ()
    listings_count: int = 0
    sales_7d: int = 0
    sales_30d: int = 0
    unique_buyers_7d: int = 0
    unique_sellers_7d: int = 0
    volume_7d_ton: Any = 0
    avg_holding_days: float | None = None
    collection_size: int | None = None
    trend: str | None = None
    collection_health: int | None = None
    marketplace_fee_bps: int = 500
    royalty_bps: int = 500
    network_fee_ton: Any | None = None


@dataclass
class NFTAnalysis:
    address: str
    name: str | None = None
    collection_address: str | None = None
    collection_name: str | None = None
    image_url: str | None = None
    number: int | None = None
    traits: dict[str, str] = field(default_factory=dict)
    listing_price: Any | None = None
    floor: Any | None = None
    fair_value: FairValueResult | None = None
    rarity: RarityReport | None = None
    number_profile: NumberProfile | None = None
    liquidity: LiquidityResult | None = None
    costs: dict[str, Any] = field(default_factory=dict)
    theoretical_profit: Any | None = None
    roi_pct: Any | None = None
    discount: Any | None = None
    score: OpportunityScore | None = None
    risk: RiskLevel = RiskLevel.MEDIUM
    analysed_at: datetime | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "name": self.name,
            "collection_address": self.collection_address,
            "collection_name": self.collection_name,
            "image_url": self.image_url,
            "number": self.number,
            "traits": self.traits,
            "listing_price": str(self.listing_price) if self.listing_price is not None else None,
            "floor": str(self.floor) if self.floor is not None else None,
            "fair_value": self.fair_value.as_dict() if self.fair_value else None,
            "rarity": self.rarity.as_dict() if self.rarity else None,
            "number_profile": {
                "value": self.number_profile.value,
                "flags": self.number_profile.flags,
                "labels": self.number_profile.labels,
                "score": self.number_profile.base_score,
            }
            if self.number_profile
            else None,
            "liquidity": self.liquidity.as_dict() if self.liquidity else None,
            "costs": {k: str(v) for k, v in self.costs.items()},
            "theoretical_profit": str(self.theoretical_profit)
            if self.theoretical_profit is not None
            else None,
            "roi_pct": str(self.roi_pct) if self.roi_pct is not None else None,
            "discount_pct": str(self.discount) if self.discount is not None else None,
            "score": self.score.as_dict() if self.score else None,
            "risk": self.risk.value,
            "analysed_at": self.analysed_at.isoformat() if self.analysed_at else None,
        }


def analyse_nft(
    metadata: ResolvedMetadata,
    snapshot: MarketSnapshot,
    *,
    collection_traits: Sequence[Mapping[str, str]] | None = None,
) -> NFTAnalysis:
    """Run the full analysis pipeline for a single NFT. Pure-ish: no I/O."""
    analysis = NFTAnalysis(
        address=metadata.address,
        name=metadata.name,
        collection_address=metadata.collection_address,
        collection_name=metadata.collection_name,
        image_url=metadata.image_url,
        number=metadata.number,
        traits=dict(metadata.attributes),
    )

    analysis.floor = quantize_ton(d(snapshot.floor)) if snapshot.floor else None
    analysis.listing_price = (
        quantize_ton(d(snapshot.floor)) if False else None
    )  # set by caller when a listing exists

    # ------------------------------------------------------------- rarity
    traits = dict(metadata.attributes)
    if collection_traits is not None and traits:
        analysis.rarity = analyse_collection_rarity(
            target_traits=traits,
            collection_traits=collection_traits,
            total_items=snapshot.collection_size,
            combination_query=traits,
        )

    # -------------------------------------------------------- number engine
    profile = classify(metadata.number)
    premium, source, comparables = derive_premium(
        metadata.number,
        rare_sales=list(snapshot.rare_number_sales),
        baseline_sales=list(snapshot.baseline_sales),
    )
    profile.observed_premium = premium
    profile.premium_source = source
    profile.comparables = comparables
    analysis.number_profile = profile

    # ----------------------------------------------------------- liquidity
    spread = None
    if analysis.floor:
        from app.nft.liquidity import spread_percentage

        spread = spread_percentage(analysis.listing_price, analysis.floor)
    analysis.liquidity = assess_liquidity(
        LiquidityInput(
            sales_7d=snapshot.sales_7d,
            sales_30d=snapshot.sales_30d,
            active_listings=snapshot.listings_count,
            unique_buyers_7d=snapshot.unique_buyers_7d,
            unique_sellers_7d=snapshot.unique_sellers_7d,
            volume_7d_ton=snapshot.volume_7d_ton,
            spread_pct=spread,
            avg_holding_days=snapshot.avg_holding_days,
            collection_size=snapshot.collection_size,
            price_ton=analysis.listing_price,
        )
    )

    # --------------------------------------------------------- fair value
    analysis.fair_value = estimate_fair_value(
        FairValueInput(
            floor=analysis.floor,
            comparable_sales=list(snapshot.comparable_sales),
            collection_sales=list(snapshot.collection_sales),
            rarity_score=analysis.rarity.score if analysis.rarity else None,
            number_score=profile.base_score,
            number_premium=premium,
            number_premium_source=source,
            liquidity_score=analysis.liquidity.score,
            trend=snapshot.trend,
            collection_health=snapshot.collection_health,
            floor_age_hours=snapshot.floor_age_hours,
        )
    )
    return analysis


def finalise_analysis(analysis: NFTAnalysis, *, listing_price: Any) -> NFTAnalysis:
    """Attach listing-specific economics (costs, upside, score, risk).

    Separated from :func:`analyse_nft` so the same analysis can be reused for a
    watchlist item, a portfolio position or a radar candidate.
    """
    from datetime import datetime

    price = quantize_ton(d(listing_price))
    analysis.listing_price = price
    analysis.analysed_at = datetime.now(UTC).replace(tzinfo=None)

    fee_bps, royalty_bps = 500, 500
    network_fee = d("0.05")
    costs = compute_costs(price, marketplace_fee_bps=fee_bps, royalty_bps=royalty_bps, network_fee_ton=network_fee)
    analysis.costs = costs

    fair_mid = analysis.fair_value.mid if analysis.fair_value else None
    analysis.discount = discount_pct(price, fair_mid)

    if fair_mid and d(fair_mid) > 0:
        exit_costs = (
            apply_bps(fair_mid, fee_bps) + apply_bps(fair_mid, royalty_bps) + network_fee
        )
        proceeds = quantize_ton(d(fair_mid) - exit_costs)
        profit = quantize_ton(proceeds - d(costs["total_outflow"]))
        analysis.theoretical_profit = profit
        analysis.roi_pct = ((profit / d(costs["total_outflow"])) * 100).quantize(d("0.01")) if d(
            costs["total_outflow"]
        ) > 0 else d("0")

    liquidity_score = analysis.liquidity.score if analysis.liquidity else 0
    rarity_score = analysis.rarity.score if analysis.rarity else None
    confidence = analysis.fair_value.confidence if analysis.fair_value else 0

    analysis.score = compute_opportunity_score(
        discount=analysis.discount,
        rarity_score=rarity_score,
        number_score=analysis.number_profile.base_score if analysis.number_profile else 0,
        liquidity_score=liquidity_score,
        confidence=confidence,
        roi_pct=analysis.roi_pct,
        price_ton=price,
        floor=analysis.floor,
    )
    analysis.risk = evaluate_risk(
        liquidity_score=liquidity_score,
        confidence=confidence,
        price_ton=price,
        floor=analysis.floor,
        discount=analysis.discount,
    )
    return analysis
