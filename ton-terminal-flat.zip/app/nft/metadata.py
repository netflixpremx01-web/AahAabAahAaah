"""NFT metadata resolver.

Implements the TON NFT metadata standard:
https://docs.ton.org/contracts/standard/tokens/nft/metadata

Handles, in order of preference:

1. indexed metadata from TON Center (``GET /metadata``),
2. off-chain JSON referenced by ``content.uri`` (HTTP or IPFS),
3. on-chain / decoded ``content`` fields (snake_case or camelCase),
4. graceful degradation for malformed, missing or unreachable metadata.

Every collection structures its content differently, so nothing is assumed -
each field is optional and parsing never raises.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from app.core.cache import cached
from app.core.config import get_settings
from app.core.http import HttpClient
from app.core.logging import get_logger
from app.integrations.toncenter.client import TonCenterClient
from app.models.enums import MetadataStatus

logger = get_logger(__name__)

IPFS_PREFIX = "ipfs://"
DEFAULT_GATEWAY = "https://ipfs.io/ipfs/"
MAX_METADATA_BYTES = 2 * 1024 * 1024

NUMBER_KEYS = ("number", "token_id", "tokenid", "id", "nft_id", "#", "index", "edition")

# Some collections (e.g. Fragment usernames) use 256-bit item indexes. Those are
# not collector numbers and would overflow a 64-bit column, so they are ignored.
MAX_COLLECTOR_NUMBER = 10**12
NAME_KEYS = ("name", "title")
DESCRIPTION_KEYS = ("description", "about", "bio")
IMAGE_KEYS = ("image", "image_url", "imageurl", "image_data", "animation_url", "video")


def is_ipfs(url: str | None) -> bool:
    return bool(url and url.startswith(IPFS_PREFIX))


def resolve_ipfs(url: str, gateway: str = DEFAULT_GATEWAY) -> str:
    return gateway + url[len(IPFS_PREFIX) :].lstrip("/")


def resolve_url(url: str | None, gateway: str = DEFAULT_GATEWAY) -> str | None:
    """Normalise a metadata/media URL (IPFS gateways, protocol relative)."""
    if not url or not isinstance(url, str):
        return None
    url = url.strip()
    if is_ipfs(url):
        return resolve_ipfs(url, gateway)
    if url.startswith("//"):
        return "https:" + url
    if url.startswith(("http://", "https://")):
        return url
    if url.startswith("data:"):
        return None
    return None


def _pick(data: dict[str, Any], keys: tuple[str, ...]) -> Any | None:
    lowered = {str(k).lower(): v for k, v in data.items()}
    for key in keys:
        if key in lowered and lowered[key] not in (None, ""):
            return lowered[key]
    return None


def normalise_attributes(raw: Any) -> dict[str, str]:
    """Normalise the many shapes traits arrive in into ``{type: value}``."""
    attributes: dict[str, str] = {}
    if isinstance(raw, dict):
        for key, value in raw.items():
            if isinstance(value, dict):
                value = value.get("value", value.get("trait_value"))
            attributes[str(key)] = str(value)
        return attributes
    if isinstance(raw, list):
        for entry in raw:
            if isinstance(entry, dict):
                key = (
                    entry.get("trait_type")
                    or entry.get("traitType")
                    or entry.get("type")
                    or entry.get("key")
                )
                value = entry.get("value") if "value" in entry else entry.get("trait_value")
                if key is None or value is None:
                    continue
                attributes[str(key)] = str(value)
            elif isinstance(entry, (list, tuple)) and len(entry) == 2:
                attributes[str(entry[0])] = str(entry[1])
    return attributes


def _bounded(value: int | None) -> int | None:
    """Return the value when it is a sane collector number, else ``None``."""
    if value is None or abs(value) > MAX_COLLECTOR_NUMBER:
        return None
    return value


def extract_number(
    *, attributes: dict[str, str], name: str | None = None, index: str | int | None = None
) -> int | None:
    """Best effort collector-number extraction (attributes > name > index).

    Indexes that are not plausible collector numbers (256-bit on-chain
    identifiers) are rejected instead of overflowing storage.
    """
    for key in NUMBER_KEYS:
        for attr_key, value in attributes.items():
            if attr_key.strip().lower().strip("#") == key:
                digits = re.search(r"-?\d+", str(value))
                if digits:
                    bounded = _bounded(int(digits.group()))
                    if bounded is not None:
                        return bounded
    if name:
        match = re.search(r"#\s*(\d+)", str(name))
        if match:
            bounded = _bounded(int(match.group(1)))
            if bounded is not None:
                return bounded
        match = re.fullmatch(r"\s*(\d+)\s*", str(name))
        if match:
            bounded = _bounded(int(match.group(1)))
            if bounded is not None:
                return bounded
    if index is not None:
        digits = re.search(r"-?\d+", str(index))
        if digits:
            return _bounded(int(digits.group()))
    return None


@dataclass
class ResolvedMetadata:
    address: str
    index: str | None = None
    name: str | None = None
    description: str | None = None
    image_url: str | None = None
    metadata_url: str | None = None
    attributes: dict[str, str] = field(default_factory=dict)
    number: int | None = None
    collection_address: str | None = None
    collection_name: str | None = None
    owner_address: str | None = None
    status: MetadataStatus = MetadataStatus.PENDING
    error: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "index": self.index,
            "name": self.name,
            "description": self.description,
            "image_url": self.image_url,
            "metadata_url": self.metadata_url,
            "attributes": self.attributes,
            "number": self.number,
            "collection_address": self.collection_address,
            "collection_name": self.collection_name,
            "owner_address": self.owner_address,
            "status": self.status.value,
            "error": self.error,
        }


class NFTMetadataService:
    """Resolve and cache NFT metadata from the chain and its metadata host."""

    def __init__(self, toncenter: TonCenterClient | None = None) -> None:
        self.toncenter = toncenter or TonCenterClient()
        self.http = HttpClient(limiter_name="metadata", timeout=15)

    # ----------------------------------------------------------- resolution
    async def resolve(
        self, address: str, *, item: dict[str, Any] | None = None, force: bool = False
    ) -> ResolvedMetadata:
        ttl = get_settings().metadata_cache_ttl_seconds
        cache_key = f"nft:metadata:{address}"

        async def call() -> dict[str, Any]:
            return (await self._resolve_uncached(address, item=item)).as_dict()

        if force:
            result = await self._resolve_uncached(address, item=item)
        else:
            data = await cached(cache_key, ttl, call)
            result = ResolvedMetadata(
                address=address,
                status=MetadataStatus(data.get("status", MetadataStatus.PENDING.value)),
                **{k: v for k, v in data.items() if k not in {"address", "status"}},
            )
        return result

    async def _resolve_uncached(
        self, address: str, *, item: dict[str, Any] | None = None
    ) -> ResolvedMetadata:
        resolved = ResolvedMetadata(address=address)
        try:
            if item is None:
                items = await self.toncenter.get_nft_items(address)
                item = items[0] if items else None
            if not item:
                resolved.status = MetadataStatus.FAILED
                resolved.error = "NFT not found on chain"
                return resolved

            resolved.index = str(item.get("index")) if item.get("index") is not None else None
            resolved.owner_address = item.get("owner_address")
            collection = item.get("collection") or {}
            resolved.collection_address = item.get("collection_address") or collection.get("address")
            resolved.collection_name = (
                (collection.get("collection_content") or {}).get("name")
                if isinstance(collection.get("collection_content"), dict)
                else None
            )

            content_raw = item.get("content")
            content = content_raw if isinstance(content_raw, dict) else {}

            # 1) indexed metadata from TON Center
            indexed = await self._indexed_metadata(address)

            # 2) off-chain JSON metadata
            metadata_url = resolve_url(_pick(content, ("uri", "metadata", "metadata_url")))
            json_meta: dict[str, Any] = {}
            if metadata_url:
                resolved.metadata_url = metadata_url
                try:
                    json_meta = await self.fetch_metadata_json(metadata_url)
                except Exception as exc:  # network/parse errors are non fatal
                    logger.info(
                        "metadata fetch failed",
                        extra={"extra_fields": {"address": address, "error": str(exc)}},
                    )
                    resolved.error = f"metadata fetch failed: {exc}"

            for source in (json_meta, indexed, content):
                if not isinstance(source, dict):
                    continue
                resolved.name = resolved.name or _as_text(_pick(source, NAME_KEYS))
                resolved.description = resolved.description or _as_text(
                    _pick(source, DESCRIPTION_KEYS)
                )
                image = resolve_url(_pick(source, IMAGE_KEYS))
                resolved.image_url = resolved.image_url or image
                traits = source.get("attributes")
                if traits is None:
                    traits = source.get("traits")
                if traits:
                    for key, value in normalise_attributes(traits).items():
                        resolved.attributes.setdefault(key, value)

            if not resolved.name:
                resolved.name = f"#{resolved.index}" if resolved.index else None

            resolved.number = extract_number(
                attributes=resolved.attributes, name=resolved.name, index=resolved.index
            )

            if resolved.name and resolved.image_url:
                resolved.status = MetadataStatus.OK
            elif resolved.name or resolved.image_url or resolved.attributes:
                resolved.status = MetadataStatus.PARTIAL
            else:
                resolved.status = MetadataStatus.FAILED
                resolved.error = resolved.error or "no metadata fields could be resolved"
        except Exception as exc:  # defensive: metadata must never break callers
            logger.warning(
                "metadata resolution failed",
                extra={"extra_fields": {"address": address, "error": str(exc)}},
            )
            resolved.status = MetadataStatus.FAILED
            resolved.error = str(exc)
        return resolved

    async def _indexed_metadata(self, address: str) -> dict[str, Any]:
        data = await self.toncenter.get_metadata(address)
        entry = (data or {}).get(address) or {}
        token_info = entry.get("token_info") or []
        return token_info[0] if token_info else {}

    async def fetch_metadata_json(self, url: str) -> dict[str, Any]:
        """Fetch and parse a metadata JSON document (HTTP/HTTPS/IPFS)."""
        response = await self.http.get(url, raw=True)
        text = response.text[:MAX_METADATA_BYTES]
        try:
            data = response.json()
        except ValueError as exc:
            raise ValueError("metadata is not valid JSON") from exc
        if not isinstance(data, dict):
            raise ValueError("metadata JSON is not an object")
        _ = text
        return data

    async def resolve_many(self, addresses: list[str]) -> dict[str, ResolvedMetadata]:
        return {address: await self.resolve(address) for address in addresses}

    async def aclose(self) -> None:
        await self.http.aclose()


def _as_text(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value.strip() or None
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict):
        for key in ("value", "name", "text"):
            if key in value:
                return _as_text(value[key])
    return None
