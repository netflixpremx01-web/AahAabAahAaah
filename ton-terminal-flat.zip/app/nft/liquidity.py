"""Liquidity engine.

Liquidity answers one question: *how quickly could this NFT be converted into
TON near the estimated value?* Low liquidity is the main reason a "cheap" NFT
is not actually an opportunity, so the radar flags
``HIGH VALUE + LOW LIQUIDITY`` explicitly.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import Decimal

from app.core.money import clamp, d
from app.models.enums import RiskLevel


@dataclass
class LiquidityInput:
    sales_7d: int = 0
    sales_30d: int = 0
    active_listings: int = 0
    unique_buyers_7d: int = 0
    unique_sellers_7d: int = 0
    volume_7d_ton: object = Decimal("0")
    spread_pct: object | None = None   # (ask - floor) / floor * 100
    avg_holding_days: float | None = None
    collection_size: int | None = None
    price_ton: object | None = None    # the NFT under evaluation


@dataclass
class LiquidityResult:
    score: int
    risk: RiskLevel
    metrics: dict = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "score": self.score,
            "risk": self.risk.value,
            "metrics": {k: str(v) for k, v in self.metrics.items()},
            "warnings": self.warnings,
        }


def _score_sales_frequency(sales_7d: int) -> int:
    """0-30: how often items in this collection actually sell."""
    import math

    if sales_7d <= 0:
        return 0
    return int(round(min(30, 30 * math.log1p(sales_7d) / math.log1p(20))))


def _score_depth(active_listings: int, sales_30d: int) -> int:
    """0-20: listings relative to sales. Over-supply is a liquidity risk."""
    if sales_30d <= 0:
        return 0
    ratio = active_listings / sales_30d
    if ratio <= 1:
        return 20
    return int(round(max(0, 20 * (1 - (ratio - 1) / 4))))


def _score_buyer_diversity(unique_buyers: int, sales_7d: int) -> int:
    """0-15: many unique buyers is healthier than one whale."""
    if sales_7d <= 0:
        return 0
    target = max(3, sales_7d * 0.5)
    return int(round(min(15, 15 * (unique_buyers / target))))


def _score_volume(volume_7d: object) -> int:
    """0-15: traded volume in TON over the last 7 days."""
    import math

    volume = float(d(volume_7d))
    if volume <= 0:
        return 0
    return int(round(min(15, 15 * math.log1p(volume) / math.log1p(1000))))


def _score_spread(spread_pct: object | None) -> int:
    """0-10: tighter spread between floor and ask = easier exit."""
    if spread_pct is None:
        return 5
    spread = float(d(spread_pct))
    return int(round(max(0, min(10, 10 * (1 - spread / 50)))))


def _score_holding_period(days: float | None) -> int:
    """0-10: observable holding period (shorter = more liquid)."""
    if days is None:
        return 5
    return int(round(max(0, min(10, 10 * (1 - days / 90)))))


def risk_from_score(score: int) -> RiskLevel:
    if score >= 70:
        return RiskLevel.LOW
    if score >= 45:
        return RiskLevel.MEDIUM
    if score >= 25:
        return RiskLevel.HIGH
    return RiskLevel.EXTREME


def assess_liquidity(data: LiquidityInput) -> LiquidityResult:
    """Pure function - fully unit tested."""
    warnings: list[str] = []
    frequency = _score_sales_frequency(data.sales_7d)
    depth = _score_depth(data.active_listings, data.sales_30d)
    diversity = _score_buyer_diversity(data.unique_buyers_7d, data.sales_7d)
    volume = _score_volume(data.volume_7d_ton)
    spread = _score_spread(data.spread_pct)
    holding = _score_holding_period(data.avg_holding_days)
    score = int(max(0, min(100, frequency + depth + diversity + volume + spread + holding)))
    risk = risk_from_score(score)

    if data.sales_7d == 0:
        warnings.append("No sales observed in the last 7 days.")
    if data.sales_30d and data.active_listings / max(1, data.sales_30d) > 5:
        warnings.append("Supply heavily exceeds demand (listings >> sales).")
    if data.unique_buyers_7d <= 1 and data.sales_7d > 2:
        warnings.append("Demand is concentrated in a single buyer.")
    if data.price_ton is not None and d(data.price_ton) >= d("25") and score < 45:
        warnings.append(
            "HIGH VALUE + LOW LIQUIDITY: exiting this position may take a long "
            "time or require a large discount."
        )
    if score < 25:
        warnings.append("Very low liquidity - treat any valuation as highly uncertain.")

    return LiquidityResult(
        score=score,
        risk=risk,
        metrics={
            "sales_frequency": frequency,
            "depth": depth,
            "buyer_diversity": diversity,
            "volume": volume,
            "spread": spread,
            "holding_period": holding,
            "sales_7d": data.sales_7d,
            "active_listings": data.active_listings,
        },
        warnings=warnings,
    )


def avg_holding_days(hold_periods: Sequence[float]) -> float | None:
    """Observable holding period from acquisition → sale timestamps."""
    if not hold_periods:
        return None
    return round(sum(hold_periods) / len(hold_periods), 2)


def spread_percentage(ask: object | None, floor: object | None) -> object | None:
    ask_v, floor_v = d(ask), d(floor)
    if ask_v <= 0 or floor_v <= 0:
        return None
    return clamp(((ask_v - floor_v) / floor_v) * 100, d("-100"), d("1000"))
