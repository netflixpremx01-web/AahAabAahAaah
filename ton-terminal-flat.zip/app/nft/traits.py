"""Trait rarity and trait-combination engine.

Rarity is computed from *actual collection composition* - never assumed.
Two layers are produced:

1. per-trait rarity (how often this trait value occurs in the collection),
2. trait-combination rarity (how many NFTs match several traits at once),
   which is what collectors actually pay premiums for.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP

from app.core.money import d

Trait = tuple[str, str]  # (trait_type, trait_value)


@dataclass
class TraitRarity:
    trait_type: str
    trait_value: str
    count: int
    total: int

    @property
    def rarity_pct(self) -> object:
        if self.total <= 0:
            return d("0")
        return ((d(self.count) / d(self.total)) * 100).quantize(d("0.0001"))

    @property
    def scarcity(self) -> object:
        """1 / frequency - higher means rarer."""
        if self.count <= 0:
            return d("0")
        return (d(self.total) / d(self.count)).quantize(d("0.0001"))


@dataclass
class CombinationResult:
    matches: int
    total: int
    rarity_pct: object
    label: str
    score: int
    traits: list[Trait] = field(default_factory=list)

    @property
    def extremely_rare(self) -> bool:
        return self.matches <= 3


COMBINATION_LABELS: list[tuple[float, str]] = [
    (0.05, "Extremely Rare"),
    (0.5, "Legendary"),
    (2.0, "Epic"),
    (6.0, "Rare"),
    (15.0, "Uncommon"),
    (100.0, "Common"),
]


def build_trait_index(items: Sequence[Mapping[str, str]]) -> dict[Trait, int]:
    """Count how often each ``(trait_type, trait_value)`` occurs."""
    index: dict[Trait, int] = {}
    for traits in items:
        for trait_type, trait_value in _iter_traits(traits):
            key = (str(trait_type), str(trait_value))
            index[key] = index.get(key, 0) + 1
    return index


def _iter_traits(traits: Mapping[str, str] | Iterable[tuple[str, str]]) -> Iterable[Trait]:
    if isinstance(traits, Mapping):
        for key, value in traits.items():
            yield str(key), str(value)
    else:
        for pair in traits:
            if isinstance(pair, (tuple, list)) and len(pair) == 2:
                yield str(pair[0]), str(pair[1])


def trait_rarities(
    nft_traits: Mapping[str, str], index: Mapping[Trait, int], total_items: int
) -> list[TraitRarity]:
    result: list[TraitRarity] = []
    for trait_type, trait_value in _iter_traits(nft_traits):
        key = (trait_type, trait_value)
        count = index.get(key, 0)
        result.append(
            TraitRarity(
                trait_type=trait_type, trait_value=trait_value, count=count, total=total_items
            )
        )
    return result


def rarity_score(
    nft_traits: Mapping[str, str], index: Mapping[Trait, int], total_items: int
) -> object:
    """Statistical rarity (sum of 1/frequency). Higher = rarer."""
    if total_items <= 0:
        return d("0")
    score = d("0")
    for trait_type, trait_value in _iter_traits(nft_traits):
        count = index.get((trait_type, trait_value), 0)
        if count <= 0:
            continue
        score += d(total_items) / d(count)
    return score.quantize(d("0.0001"), rounding=ROUND_HALF_UP)


def normalise_scores(raw_scores: Mapping[str, object]) -> dict[str, int]:
    """Map raw statistical rarity onto a 0-100 scale across the collection.

    A log scale is used because raw rarity scores are heavy tailed.
    """
    if not raw_scores:
        return {}
    values = [d(v) for v in raw_scores.values()]
    low, high = min(values), max(values)
    if high <= 0:
        return {key: 0 for key in raw_scores}
    if high == low:
        return {key: 50 for key in raw_scores}
    import math

    log_low, log_high = math.log(float(low) if low > 0 else 1e-9), math.log(float(high))
    span = (log_high - log_low) or 1
    out: dict[str, int] = {}
    for key, value in raw_scores.items():
        v = float(d(value))
        log_v = math.log(v) if v > 0 else log_low
        out[key] = int(round(((log_v - log_low) / span) * 100))
    return out


def project_score(value: object, reference: Sequence[object]) -> int:
    """Project ``value`` onto the 0-100 scale defined by ``reference`` scores."""
    values = [d(v) for v in reference if d(v) > 0]
    if not values:
        return 0
    low, high = min(values), max(values)
    target = d(value)
    if high == low:
        return 50
    import math

    log_low = math.log(float(low))
    log_high = math.log(float(high))
    log_v = math.log(float(target)) if target > 0 else log_low
    span = (log_high - log_low) or 1
    return int(max(0, min(100, round(((log_v - log_low) / span) * 100))))


def combination_result(
    query: Mapping[str, str],
    items: Sequence[Mapping[str, str]],
    *,
    total_items: int | None = None,
) -> CombinationResult:
    """How many NFTs in the collection match *all* the given traits at once."""
    keys = list(_iter_traits(query))
    if not keys:
        return CombinationResult(
            matches=0, total=total_items or len(items), rarity_pct=d("0"), label="No traits", score=0
        )
    matches = 0
    for traits in items:
        candidate = {str(k): str(v) for k, v in _iter_traits(traits)}
        if all(candidate.get(k) == v for k, v in keys):
            matches += 1
    total = total_items or len(items) or 1
    pct = (d(matches) / d(total)) * 100
    label = next(name for threshold, name in COMBINATION_LABELS if float(pct) <= threshold)
    score = _combination_score(matches, total)
    return CombinationResult(
        matches=matches,
        total=total,
        rarity_pct=pct.quantize(d("0.0001")),
        label=label,
        score=score,
        traits=keys,
    )


def _combination_score(matches: int, total: int) -> int:
    """0-100 collector score for a trait combination.

    Log scale between "half the collection has it" (0) and "one single item has
    it" (100)::

        score = 100 * log(0.5 / ratio) / log(0.5 * total)

    A combination present in 3 of 10 000 items scores ~87.
    """
    if total <= 0 or matches <= 0:
        return 0
    import math

    ratio = matches / total
    if ratio <= 0:
        return 0
    if ratio >= 0.5:
        return 0
    numerator = math.log(0.5 / ratio)
    denominator = math.log(0.5 * total)
    if denominator <= 0:
        return 0
    return int(max(0, min(100, round(100 * numerator / denominator))))


def rarest_traits(rarities: Sequence[TraitRarity], limit: int = 5) -> list[TraitRarity]:
    return sorted(rarities, key=lambda t: t.count)[:limit]
