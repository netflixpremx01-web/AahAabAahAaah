import type { ReactNode } from 'react';
import { short } from '../lib/format';

export type TabKey =
  | 'home'
  | 'radar'
  | 'trade'
  | 'swap'
  | 'portfolio'
  | 'analyze'
  | 'watchlist'
  | 'strategies'
  | 'market'
  | 'settings';

const TABS: Array<{ key: TabKey; label: string; icon: string }> = [
  { key: 'home', label: 'Hub', icon: '◆' },
  { key: 'radar', label: 'Radar', icon: '🔥' },
  { key: 'trade', label: 'Trade', icon: '🛒' },
  { key: 'swap', label: 'Swap', icon: '🔄' },
  { key: 'portfolio', label: 'Portfolio', icon: '💼' },
  { key: 'analyze', label: 'Analyze', icon: '🧬' },
  { key: 'watchlist', label: 'Watch', icon: '👀' },
  { key: 'strategies', label: 'Strategy', icon: '🧠' },
  { key: 'market', label: 'Market', icon: '🐋' },
  { key: 'settings', label: 'Settings', icon: '⚙️' },
];

export function Layout({
  title,
  subtitle,
  wallet,
  network,
  tab,
  onTab,
  children,
}: {
  title: string;
  subtitle?: string;
  wallet?: string | null;
  network?: string;
  tab: TabKey;
  onTab: (tab: TabKey) => void;
  children: ReactNode;
}) {
  return (
    <div className="app">
      <header className="header">
        <div className="header-row">
          <div>
            <div className="title">
              <span>◆</span> {title}
            </div>
            {subtitle && <div className="subtitle">{subtitle}</div>}
          </div>
          <span className={`badge ${wallet ? 'good' : 'muted'}`}>
            {wallet ? short(wallet, 4) : 'No wallet'}
          </span>
        </div>
        {network && <div className="subtitle">Network: {network}</div>}
      </header>
      {children}
      <nav className="tabs">
        {TABS.map((item) => (
          <button
            key={item.key}
            className={`tab${tab === item.key ? ' active' : ''}`}
            onClick={() => onTab(item.key)}
          >
            {item.icon} {item.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
