import type { ReactNode } from 'react';

export function Card({
  title,
  children,
  action,
  flat,
}: {
  title?: string;
  children: ReactNode;
  action?: ReactNode;
  flat?: boolean;
}) {
  return (
    <div className={`card${flat ? ' flat' : ''}`}>
      {title && (
        <div className="row">
          <span className="card-title">{title}</span>
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

export function Stat({ label, value, tone }: { label: string; value: ReactNode; tone?: string }) {
  return (
    <div className="stat">
      <span className="stat-label">{label}</span>
      <span className="stat-value" style={tone ? { color: `var(--${tone})` } : undefined}>
        {value}
      </span>
    </div>
  );
}

export function Badge({ children, tone = 'muted' }: { children: ReactNode; tone?: string }) {
  return <span className={`badge ${tone}`}>{children}</span>;
}

export function Row({ k, v }: { k: ReactNode; v: ReactNode }) {
  return (
    <div className="row">
      <span className="k">{k}</span>
      <span className="v">{v}</span>
    </div>
  );
}

export function Button({
  children,
  onClick,
  variant = 'primary',
  disabled,
  type = 'button',
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  disabled?: boolean;
  type?: 'button' | 'submit';
}) {
  const className = `btn${variant === 'primary' ? '' : ` ${variant}`}`;
  return (
    <button className={className} onClick={onClick} disabled={disabled} type={type}>
      {children}
    </button>
  );
}

export function Progress({ value, tone }: { value: number; tone?: string }) {
  return (
    <div className={`progress ${tone ?? ''}`}>
      <span style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Note({ children, warning }: { children: ReactNode; warning?: boolean }) {
  return <div className={`note${warning ? ' warning' : ''}`}>{children}</div>;
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="empty">{children}</div>;
}

export function Spinner() {
  return <div className="spinner" />;
}

export function Sheet({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div className="sheet" onClick={onClose}>
      <div className="sheet-body" onClick={(event) => event.stopPropagation()}>
        <div className="row">
          <span className="sheet-title">{title}</span>
          <button className="btn ghost" style={{ width: 'auto', padding: '6px 10px' }} onClick={onClose}>
            Close
          </button>
        </div>
        <div className="divider" />
        {children}
      </div>
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="field">
      <label>{label}</label>
      {children}
    </div>
  );
}
