/** Formatting helpers - the API returns Decimal strings to avoid drift. */

export function ton(value: unknown, places = 2): string {
  if (value === null || value === undefined || value === '') return '—';
  const num = Number(value);
  if (Number.isNaN(num)) return '—';
  return num.toLocaleString('en-US', { minimumFractionDigits: places, maximumFractionDigits: places });
}

export function short(address: unknown, size = 6): string {
  const text = String(address ?? '');
  if (text.length <= size * 2) return text || '—';
  return `${text.slice(0, size)}…${text.slice(-size)}`;
}

export function scoreTone(score: number | null | undefined): string {
  if (score === null || score === undefined) return 'muted';
  if (score >= 75) return 'good';
  if (score >= 50) return 'warn';
  return 'bad';
}

export function riskTone(risk: string): string {
  switch (risk) {
    case 'low':
      return 'good';
    case 'medium':
      return 'warn';
    default:
      return 'bad';
  }
}

export function signed(value: unknown, places = 2): string {
  const num = Number(value ?? 0);
  if (Number.isNaN(num)) return '—';
  return `${num >= 0 ? '+' : ''}${num.toLocaleString('en-US', {
    minimumFractionDigits: places,
    maximumFractionDigits: places,
  })}`;
}
