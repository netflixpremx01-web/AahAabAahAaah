/** Tiny API client for the terminal backend. */
import { initData } from './telegram';

const BASE = (import.meta.env.VITE_API_URL as string | undefined) ?? '/api';

export class ApiError extends Error {
  status: number;
  detail: unknown;
  constructor(status: number, detail: unknown) {
    super(typeof detail === 'string' ? detail : JSON.stringify(detail));
    this.status = status;
    this.detail = detail;
  }
}

async function request<T>(
  path: string,
  options: { method?: string; body?: unknown; params?: Record<string, string | number | undefined> } = {},
): Promise<T> {
  const url = new URL(`${BASE}${path}`, window.location.origin);
  Object.entries(options.params ?? {}).forEach(([key, value]) => {
    if (value !== undefined && value !== '') url.searchParams.set(key, String(value));
  });

  const response = await fetch(url.toString(), {
    method: options.method ?? 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Telegram-Init-Data': initData(),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  if (!response.ok) {
    let detail: unknown = response.statusText;
    try {
      detail = (await response.json()).detail ?? detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(response.status, detail);
  }
  return (await response.json()) as T;
}

export const api = {
  get: <T>(path: string, params?: Record<string, string | number | undefined>) =>
    request<T>(path, { params }),
  post: <T>(path: string, body?: unknown) => request<T>(path, { method: 'POST', body }),
  patch: <T>(path: string, body?: unknown) => request<T>(path, { method: 'PATCH', body }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
};

// ---------------------------------------------------------------- endpoints
export interface Config {
  app_name: string;
  ton_network: string;
  enable_real_trading: boolean;
  enable_paper_trading: boolean;
  dev_mode: boolean;
  default_marketplace_fee_bps: number;
  default_royalty_bps: number;
  network_fee_estimate_ton: string;
  quote_ttl_seconds: number;
}

export interface Opportunity {
  id: number;
  listing_id?: string | null;
  nft_address?: string | null;
  collection_address?: string | null;
  marketplace: string;
  listed_price_ton: string;
  fair_value_low?: string | null;
  fair_value_high?: string | null;
  fair_value_mid?: string | null;
  discount_pct?: string | null;
  rarity_score?: number | null;
  number_score?: number | null;
  liquidity_score?: number | null;
  confidence?: number | null;
  roi_pct?: string | null;
  estimated_costs_ton?: string | null;
  theoretical_profit_ton?: string | null;
  risk_level: string;
  opportunity_score: number;
  reasons?: string[];
  detected_at?: string;
}

export const endpoints = {
  // generic verbs (used for less common endpoints)
  get: <T>(path: string, params?: Record<string, string | number | undefined>) =>
    api.get<T>(path, params),
  post: <T>(path: string, body?: unknown) => api.post<T>(path, body),
  patch: <T>(path: string, body?: unknown) => api.patch<T>(path, body),
  delete: <T>(path: string) => api.delete<T>(path),
  config: () => api.get<Config>('/config'),
  providers: () => api.get<{ marketplaces: unknown[]; dex: unknown[] }>('/providers'),
  me: () => api.get<Record<string, unknown>>('/auth/me'),
  wallets: () => api.get<{ wallets: Array<Record<string, unknown>> }>('/wallets'),
  opportunities: (minScore = 0, limit = 20) =>
    api.get<{ opportunities: Opportunity[] }>('/radar', { min_score: minScore, limit }),
  scan: (collection: string, minScore = 0, limit = 25) =>
    api.post<{ opportunities: Opportunity[]; count: number }>('/radar/scan', {
      collection,
      min_score: minScore,
      limit,
    }),
  analysis: (address: string) => api.get<{ metadata: unknown; analysis?: unknown }>(`/nfts/${address}`),
  portfolio: () => api.get<Record<string, unknown>>('/portfolio'),
  swapQuote: (body: unknown) => api.post<Record<string, unknown>>('/swap/quote', body),
  swapProviders: () => api.get<{ providers: unknown[] }>('/swap/providers'),
  buyPrepare: (nftAddress: string) =>
    api.post<Record<string, unknown>>('/trading/buy/prepare', { nft_address: nftAddress }),
  sellPrepare: (nftAddress: string, price: number) =>
    api.post<Record<string, unknown>>('/trading/sell/prepare', {
      nft_address: nftAddress,
      price_ton: price,
    }),
  watchlist: () => api.get<{ watchlist: Array<Record<string, unknown>> }>('/watchlist'),
  addWatch: (body: unknown) => api.post<Record<string, unknown>>('/watchlist', body),
  removeWatch: (id: number) => api.delete<{ removed: boolean }>(`/watchlist/${id}`),
  strategies: () => api.get<{ strategies: Array<Record<string, unknown>> }>('/strategies'),
  createStrategy: (body: unknown) => api.post<Record<string, unknown>>('/strategies', body),
  paper: () => api.get<Record<string, any>>('/paper'),
  paperOpen: (body: unknown) => api.post<Record<string, unknown>>('/paper/open', body),
  paperClose: (body: unknown) => api.post<Record<string, unknown>>('/paper/close', body),
  market: (address: string) => api.get<Record<string, unknown>>(`/collections/${address}`),
  anomalies: (address: string) => api.get<{ anomalies: Array<Record<string, unknown>> }>(`/collections/${address}/anomalies`),
  whales: (address: string) => api.get<Record<string, unknown>>(`/collections/${address}/whales`),
  syncCollection: (address: string) => api.post<Record<string, unknown>>(`/collections/${address}/sync`, {}),
};
