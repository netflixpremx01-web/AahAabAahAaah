/** Telegram WebApp helpers (works outside Telegram too: every call is guarded). */

export interface WebAppUser {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
  photo_url?: string;
}

interface ThemeParams {
  bg_color?: string;
  text_color?: string;
  hint_color?: string;
  link_color?: string;
  button_color?: string;
  button_text_color?: string;
  secondary_bg_color?: string;
}

interface WebApp {
  initData: string;
  initDataUnsafe: { user?: WebAppUser };
  version: string;
  platform: string;
  colorScheme: 'light' | 'dark';
  themeParams: ThemeParams;
  ready: () => void;
  expand: () => void;
  close: () => void;
  openTelegramLink?: (url: string) => void;
  openLink?: (url: string, options?: { try_instant_view?: boolean }) => void;
  HapticFeedback?: {
    impactOccurred: (style: 'light' | 'medium' | 'heavy') => void;
    notificationOccurred: (type: 'success' | 'warning' | 'error') => void;
  };
  BackButton?: {
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
  MainButton?: {
    setText: (text: string) => void;
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
    enable: () => void;
    disable: () => void;
  };
}

declare global {
  interface Window {
    Telegram?: { WebApp: WebApp };
  }
}

export function webApp(): WebApp | null {
  return typeof window !== 'undefined' && window.Telegram?.WebApp ? window.Telegram.WebApp : null;
}

export function initData(): string {
  return webApp()?.initData ?? '';
}

export function currentUser(): WebAppUser | null {
  return webApp()?.initDataUnsafe?.user ?? null;
}

export function isTelegram(): boolean {
  return Boolean(webApp()?.initData);
}

export function haptic(kind: 'light' | 'medium' | 'heavy' | 'success' | 'error' = 'light'): void {
  const app = webApp();
  if (!app?.HapticFeedback) return;
  if (kind === 'success' || kind === 'error') {
    app.HapticFeedback.notificationOccurred(kind);
  } else {
    app.HapticFeedback.impactOccurred(kind);
  }
}

export function theme(): ThemeParams & { dark: boolean } {
  const app = webApp();
  const dark = app ? app.colorScheme !== 'light' : true;
  return {
    dark,
    bg_color: app?.themeParams?.bg_color ?? (dark ? '#0b0f19' : '#ffffff'),
    text_color: app?.themeParams?.text_color ?? (dark ? '#eef2ff' : '#101828'),
    hint_color: app?.themeParams?.hint_color ?? (dark ? '#8b95b2' : '#667085'),
    link_color: app?.themeParams?.link_color ?? '#4d8dff',
    button_color: app?.themeParams?.button_color ?? '#4d8dff',
    button_text_color: app?.themeParams?.button_text_color ?? '#ffffff',
    secondary_bg_color: app?.themeParams?.secondary_bg_color ?? (dark ? '#141a2a' : '#f2f4f7'),
  };
}

export function ready(): void {
  const app = webApp();
  if (!app) return;
  app.ready();
  app.expand();
}

export function openLink(url: string): void {
  const app = webApp();
  if (app?.openLink) app.openLink(url);
  else window.open(url, '_blank', 'noopener');
}
