/** Wallet sync: shares only PUBLIC wallet data with the backend. */
import { useEffect } from 'react';
import { useTonAddress, useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';
import { api } from './api';

export function useWalletSync() {
  const wallet = useTonWallet();
  const address = useTonAddress(false);
  const [tonConnectUI] = useTonConnectUI();

  useEffect(() => {
    if (!address || !wallet) return;
    const device = (wallet as any)?.device;
    const proof = (wallet as any)?.connectItems?.tonProof
      ? (wallet as any).connectItems.tonProof.proof
      : undefined;

    api
      .post('/wallets/connect', {
        address,
        publicKey: (wallet as any)?.publicKey,
        network: (wallet.account as any)?.chain === '-3' ? 'testnet' : 'mainnet',
        walletApp: (wallet as any)?.device?.appName,
        device: device
          ? { appName: device.appName, appVersion: device.appVersion, platform: device.platform }
          : undefined,
        proof,
      })
      .catch(() => {
        /* non fatal: the UI still works in read-only mode */
      });
  }, [address, wallet]);

  return { address, wallet, tonConnectUI };
}
