import { useEffect, useState } from 'react';
import { useTonAddress } from '@tonconnect/ui-react';
import { Layout, type TabKey } from './components/Layout';
import Dashboard from './pages/Dashboard';
import Radar from './pages/Radar';
import Trade from './pages/Trade';
import Swap from './pages/Swap';
import Portfolio from './pages/Portfolio';
import Analyze from './pages/Analyze';
import Market from './pages/Market';
import Watchlist from './pages/Watchlist';
import Strategies from './pages/Strategies';
import Settings from './pages/Settings';
import { endpoints, type Config } from './lib/api';
import { haptic } from './lib/format-helpers';

export default function App() {
  const [tab, setTab] = useState<TabKey>('home');
  const [config, setConfig] = useState<Config | null>(null);
  const [tradeAddress, setTradeAddress] = useState<string | undefined>(undefined);
  const [analyzeAddress, setAnalyzeAddress] = useState<string | undefined>(undefined);
  const address = useTonAddress(false);

  useEffect(() => {
    endpoints.config().then(setConfig).catch(() => undefined);
  }, []);

  const navigate = (next: string) => {
    haptic('light');
    setTab(next as TabKey);
  };

  const openTrade = (nftAddress?: string) => {
    if (nftAddress) setTradeAddress(nftAddress);
    navigate('trade');
  };

  const openAnalyze = (nftAddress?: string) => {
    if (nftAddress) setAnalyzeAddress(nftAddress);
    navigate('analyze');
  };

  return (
    <Layout
      title="TON NFT Trading Hub"
      subtitle={config ? `${config.ton_network.toUpperCase()} · paper mode ready` : undefined}
      wallet={address || null}
      network={config?.ton_network}
      tab={tab}
      onTab={setTab}
    >
      {tab === 'home' && <Dashboard onNavigate={navigate} />}
      {tab === 'radar' && <Radar onBuy={openTrade} onAnalyze={openAnalyze} />}
      {tab === 'trade' && <Trade initialAddress={tradeAddress} />}
      {tab === 'swap' && <Swap />}
      {tab === 'portfolio' && <Portfolio />}
      {tab === 'analyze' && <Analyze initial={analyzeAddress} />}
      {tab === 'watchlist' && <Watchlist />}
      {tab === 'strategies' && <Strategies />}
      {tab === 'market' && <Market />}
      {tab === 'settings' && <Settings />}
    </Layout>
  );
}
