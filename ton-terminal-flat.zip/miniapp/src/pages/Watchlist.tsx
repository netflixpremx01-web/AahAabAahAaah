import { useEffect, useState } from 'react';
import { Button, Card, Empty, Field, Note, Row, Badge } from '../components/ui';
import { endpoints } from '../lib/api';
import { short, ton } from '../lib/format-helpers';

const CONDITIONS = [
  { key: 'price_below', label: 'Price below' },
  { key: 'price_above', label: 'Price above' },
  { key: 'floor_below', label: 'Floor below' },
  { key: 'floor_above', label: 'Floor above' },
  { key: 'discount_above', label: 'Fair-value discount above %' },
];

export default function Watchlist() {
  const [rows, setRows] = useState<any[]>([]);
  const [target, setTarget] = useState('');
  const [condition, setCondition] = useState('price_below');
  const [threshold, setThreshold] = useState('');
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    try {
      const data = await endpoints.watchlist();
      setRows(data.watchlist ?? []);
    } catch {
      /* ignore */
    }
  };

  useEffect(() => {
    load();
  }, []);

  const add = async () => {
    setError(null);
    try {
      await endpoints.addWatch({
        target_type: target.length > 48 ? 'collection' : 'nft',
        target_ref: target.trim(),
        condition,
        threshold: threshold ? Number(threshold) : null,
        label: short(target.trim(), 8),
      });
      setTarget('');
      setThreshold('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add watch');
    }
  };

  return (
    <>
      <Card title="New alert">
        <Field label="NFT or collection address">
          <input className="input" placeholder="EQ… / 0:…" value={target} onChange={(event) => setTarget(event.target.value)} />
        </Field>
        <Field label="Condition">
          <select className="select" value={condition} onChange={(event) => setCondition(event.target.value)}>
            {CONDITIONS.map((item) => (
              <option key={item.key} value={item.key}>
                {item.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Threshold (TON)">
          <input
            className="input"
            inputMode="decimal"
            placeholder="60"
            value={threshold}
            onChange={(event) => setThreshold(event.target.value)}
          />
        </Field>
        <Button onClick={add} disabled={!target.trim()}>
          Add to watchlist
        </Button>
        {error && <Note warning>{error}</Note>}
      </Card>

      <Card title="Your watchlist">
        {rows.length === 0 ? (
          <Empty>Nothing watched yet.</Empty>
        ) : (
          rows.map((row) => (
            <div key={row.id} className="card flat" style={{ gap: 6 }}>
              <div className="row">
                <span className="mono">{short(row.target_ref, 6)}</span>
                <Badge tone={row.is_active ? 'good' : 'muted'}>{row.target_type}</Badge>
              </div>
              <Row k="Condition" v={`${row.condition} ${ton(row.threshold)}`} />
              <Row k="Triggers" v={row.trigger_count} />
              <button
                className="btn ghost"
                onClick={async () => {
                  await endpoints.removeWatch(row.id);
                  await load();
                }}
              >
                Remove
              </button>
            </div>
          ))
        )}
      </Card>
    </>
  );
}
