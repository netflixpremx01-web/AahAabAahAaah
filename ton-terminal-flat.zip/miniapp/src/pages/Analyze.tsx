import { useState } from 'react';
import { Button, Card, Empty, Field, Note, Row, Stat } from '../components/ui';
import { endpoints } from '../lib/api';
import { short, ton } from '../lib/format-helpers';

export default function Analyze({ initial }: { initial?: string }) {
  const [address, setAddress] = useState(initial ?? '');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    if (!address.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const result = await endpoints.analysis(address.trim().split('/').pop()!);
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const analysis = data?.analysis;
  const metadata = data?.metadata;
  const fair = analysis?.fair_value;
  const rarity = analysis?.rarity;
  const liquidity = analysis?.liquidity;
  const numberProfile = analysis?.number_profile;

  return (
    <>
      <Card title="Analyze an NFT">
        <Field label="NFT address or marketplace URL">
          <input
            className="input"
            placeholder="EQ… / 0:… / https://…"
            value={address}
            onChange={(event) => setAddress(event.target.value)}
          />
        </Field>
        <Button onClick={run} disabled={loading || !address.trim()}>
          {loading ? 'Analysing…' : 'Analyze'}
        </Button>
      </Card>

      {error && <Note warning>{error}</Note>}

      {data && (
        <Card title="NFT">
          {metadata?.image_url && (
            <img
              src={metadata.image_url}
              alt={metadata.name ?? 'NFT'}
              style={{ width: '100%', borderRadius: 12, border: '1px solid var(--line)' }}
            />
          )}
          <div className="row">
            <span style={{ fontWeight: 700 }}>{metadata?.name ?? 'Unnamed'}</span>
            <span className="mono">{short(metadata?.address, 6)}</span>
          </div>
          {metadata?.collection_address && (
            <Row k="Collection" v={<span className="mono">{short(metadata.collection_address, 6)}</span>} />
          )}
          {metadata?.number !== null && metadata?.number !== undefined && (
            <Row k="Collector number" v={`#${metadata.number}`} />
          )}
        </Card>
      )}

      {analysis && (
        <>
          <Card title="Valuation">
            <div className="grid three">
              <Stat label="Floor" value={`${ton(analysis.floor)} TON`} />
              <Stat label="Fair value" value={`${ton(fair?.low)}–${ton(fair?.high)}`} />
              <Stat label="Confidence" value={`${fair?.confidence ?? '—'}/100`} />
            </div>
            <Note>
              Estimated fair value, not a guaranteed resale price. Method: {fair?.method}.{' '}
              {fair?.notes?.join(' ')}
            </Note>
          </Card>

          <Card title="Rarity & traits">
            <div className="grid three">
              <Stat label="Rarity" value={`${rarity?.score ?? '—'}/100`} />
              <Stat label="Rank" value={rarity?.rank ?? '—'} />
              <Stat label="Percentile" value={ton(rarity?.percentile, 1)} />
            </div>
            {(rarity?.traits ?? []).slice(0, 8).map((trait: any) => (
              <Row
                key={`${trait.type}-${trait.value}`}
                k={`${trait.type}: ${trait.value}`}
                v={`${ton(trait.rarity_pct, 2)}%`}
              />
            ))}
            {rarity?.combination && (
              <Note>
                Trait combination: <b>{rarity.combination.label}</b> — {rarity.combination.matches}{' '}
                known matches of {rarity.combination.total} items (score{' '}
                {rarity.combination.score}/100).
              </Note>
            )}
            {numberProfile && (
              <Note>
                Number #{numberProfile.value}{' '}
                {numberProfile.labels?.length ? `(${numberProfile.labels.join(', ')})` : '(standard)'} —
                collector score {numberProfile.score}/100.
              </Note>
            )}
          </Card>

          <Card title="Liquidity">
            <div className="grid three">
              <Stat label="Score" value={`${liquidity?.score ?? '—'}/100`} />
              <Stat label="Risk" value={liquidity?.risk ?? '—'} />
              <Stat label="Listings" value={liquidity?.metrics?.active_listings ?? '—'} />
            </div>
            {(liquidity?.warnings ?? []).map((warning: string) => (
              <Note key={warning} warning>
                {warning}
              </Note>
            ))}
          </Card>
        </>
      )}

      {data && !analysis && <Empty>No analysis available for this NFT yet.</Empty>}
    </>
  );
}
