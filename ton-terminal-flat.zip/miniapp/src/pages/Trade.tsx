import { useEffect, useState } from 'react';
import { useTonAddress, useTonConnectUI } from '@tonconnect/ui-react';
import { Badge, Button, Card, Field, Note, Row, Stat } from '../components/ui';
import { endpoints } from '../lib/api';
import { short, ton } from '../lib/format-helpers';
import type { Config } from '../lib/api';

type Mode = 'buy' | 'sell';

export default function Trade({ initialAddress }: { initialAddress?: string }) {
  const [mode, setMode] = useState<Mode>('buy');
  const [address, setAddress] = useState(initialAddress ?? '');
  const [price, setPrice] = useState('');
  const [payload, setPayload] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [config, setConfig] = useState<Config | null>(null);
  const [tx, setTx] = useState<any>(null);

  const addressUser = useTonAddress(false);
  const [tonConnectUI] = useTonConnectUI();

  useEffect(() => {
    endpoints.config().then(setConfig).catch(() => undefined);
  }, []);

  useEffect(() => {
    if (initialAddress) setAddress(initialAddress);
  }, [initialAddress]);

  const prepare = async () => {
    setLoading(true);
    setError(null);
    setPayload(null);
    try {
      const result =
        mode === 'buy'
          ? await endpoints.buyPrepare(address.trim())
          : await endpoints.sellPrepare(address.trim(), Number(price));
      setPayload(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Preparation failed');
    } finally {
      setLoading(false);
    }
  };

  const sendTransaction = async () => {
    if (!payload?.available || !payload.transaction) return;
    const txRequest = {
      validUntil: payload.transaction.valid_until ?? Math.floor(Date.now() / 1000) + 300,
      messages: [
        {
          address: payload.transaction.to_address,
          amount: String(payload.transaction.amount_nano),
          payload: payload.transaction.payload_boc,
        },
      ],
    };
    try {
      const result = await tonConnectUI.sendTransaction(txRequest);
      setTx(result);
      await endpoints.post('/trading/submit', {
        kind: mode,
        wallet_address: addressUser,
        tx_hash: (result as any)?.boc ? undefined : undefined,
        subject_address: address,
        provider: payload.marketplace,
        amount_ton: Number(mode === 'buy' ? payload.price_ton : payload.price_ton),
        payload: { provider_payload: result },
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Transaction rejected');
    }
  };

  return (
    <>
      <Card title="Trade">
        <div className="btn-row">
          <Button variant={mode === 'buy' ? 'primary' : 'secondary'} onClick={() => setMode('buy')}>
            Buy
          </Button>
          <Button variant={mode === 'sell' ? 'primary' : 'secondary'} onClick={() => setMode('sell')}>
            Sell / List
          </Button>
        </div>
        <Field label="NFT address">
          <input
            className="input"
            placeholder="EQ… / 0:…"
            value={address}
            onChange={(event) => setAddress(event.target.value)}
          />
        </Field>
        {mode === 'sell' && (
          <Field label="Your price (TON)">
            <input
              className="input"
              inputMode="decimal"
              placeholder="50"
              value={price}
              onChange={(event) => setPrice(event.target.value)}
            />
          </Field>
        )}
        <Button onClick={prepare} disabled={loading || !address.trim() || (mode === 'sell' && !price)}>
          {loading ? 'Preparing…' : `Prepare ${mode}`}
        </Button>
        {config && !config.enable_real_trading && (
          <Note warning>
            Real-money execution is disabled on this deployment (testnet / demo mode). You can still
            review every figure below and use Paper Mode.
          </Note>
        )}
      </Card>

      {error && <Note warning>{error}</Note>}

      {payload && (
        <Card title={mode === 'buy' ? 'Confirm purchase' : 'Confirm listing'}>
          <Row k="NFT" v={payload.nft?.name ?? <span className="mono">{short(address, 6)}</span>} />
          <Row k="Collection" v={payload.collection?.name ?? '—'} />
          <Row k="Marketplace" v={payload.marketplace} />
          <Row k="Network" v={payload.network} />
          {mode === 'buy' ? (
            <>
              <Row k="Price" v={`${ton(payload.price_ton)} TON`} />
              <Row k="Fees + royalties" v={`${ton(payload.costs?.total_costs)} TON`} />
              <Stat label="Total" value={`${ton(payload.total_ton)} TON`} />
            </>
          ) : (
            <>
              <Row k="Floor" v={`${ton(payload.floor_ton)} TON`} />
              <Row k="Suggested range" v={`${ton(payload.suggested_range?.low)}–${ton(payload.suggested_range?.high)}`} />
              <Row k="Marketplace fee" v={`${ton(payload.marketplace_fee_ton)} TON`} />
              <Row k="Royalty" v={`${ton(payload.royalty_ton)} TON`} />
              <Stat label="Expected proceeds" value={`${ton(payload.expected_proceeds_ton)} TON`} />
            </>
          )}
          <Note>{payload.disclaimer}</Note>

          {payload.available ? (
            <>
              <Badge tone="good">Transaction ready</Badge>
              {!addressUser ? (
                <Button onClick={() => tonConnectUI.openModal()}>Connect wallet to continue</Button>
              ) : (
                <Button onClick={sendTransaction}>Confirm in wallet</Button>
              )}
            </>
          ) : (
            <>
              <Badge tone="warn">Execution unavailable</Badge>
              <Note warning>{payload.unavailable_reason}</Note>
              <Note>
                This project never fabricates transaction payloads. Once the marketplace publishes a
                public API (or grants access), the adapter is activated with no UI changes.
              </Note>
            </>
          )}
        </Card>
      )}

      {tx && (
        <Card title="Submitted">
          <Note>
            Transaction broadcast. The backend verifies it against the blockchain before marking it
            as confirmed — check Portfolio → History.
          </Note>
        </Card>
      )}
    </>
  );
}
