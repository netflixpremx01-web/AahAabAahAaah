import { useEffect, useState } from 'react';
import { Button, Card, Empty, Field, Note, Row, Badge, Stat } from '../components/ui';
import { endpoints } from '../lib/api';

const MODES = [
  { key: 'alert', label: 'Alert only' },
  { key: 'paper', label: 'Paper trading' },
  { key: 'assisted', label: 'Assisted execution' },
];

export default function Strategies() {
  const [rows, setRows] = useState<any[]>([]);
  const [name, setName] = useState('');
  const [mode, setMode] = useState('alert');
  const [rules, setRules] = useState({
    min_roi_pct: 25,
    max_buy_price_ton: 100,
    min_rarity: 80,
    min_liquidity: 70,
    min_confidence: 80,
    max_risk: 'medium',
  });

  const load = async () => {
    const data = await endpoints.strategies().catch(() => ({ strategies: [] }));
    setRows(data.strategies ?? []);
  };

  useEffect(() => {
    load();
  }, []);

  const create = async () => {
    await endpoints.createStrategy({ name: name || 'My strategy', mode, rules });
    setName('');
    await load();
  };

  return (
    <>
      <Card title="New strategy">
        <Field label="Name">
          <input className="input" value={name} placeholder="Blue-chip dips" onChange={(event) => setName(event.target.value)} />
        </Field>
        <Field label="Mode">
          <select className="select" value={mode} onChange={(event) => setMode(event.target.value)}>
            {MODES.map((item) => (
              <option key={item.key} value={item.key}>
                {item.label}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid tiles">
          <Field label="Min ROI %">
            <input
              className="input"
              type="number"
              value={rules.min_roi_pct}
              onChange={(event) => setRules({ ...rules, min_roi_pct: Number(event.target.value) })}
            />
          </Field>
          <Field label="Max buy price">
            <input
              className="input"
              type="number"
              value={rules.max_buy_price_ton}
              onChange={(event) => setRules({ ...rules, max_buy_price_ton: Number(event.target.value) })}
            />
          </Field>
          <Field label="Min rarity">
            <input
              className="input"
              type="number"
              value={rules.min_rarity}
              onChange={(event) => setRules({ ...rules, min_rarity: Number(event.target.value) })}
            />
          </Field>
          <Field label="Min liquidity">
            <input
              className="input"
              type="number"
              value={rules.min_liquidity}
              onChange={(event) => setRules({ ...rules, min_liquidity: Number(event.target.value) })}
            />
          </Field>
          <Field label="Min confidence">
            <input
              className="input"
              type="number"
              value={rules.min_confidence}
              onChange={(event) => setRules({ ...rules, min_confidence: Number(event.target.value) })}
            />
          </Field>
          <Field label="Max risk">
            <select
              className="select"
              value={rules.max_risk}
              onChange={(event) => setRules({ ...rules, max_risk: event.target.value })}
            >
              <option value="low">low</option>
              <option value="medium">medium</option>
              <option value="high">high</option>
            </select>
          </Field>
        </div>
        <Button onClick={create}>Create strategy</Button>
        <Note>
          Assisted execution only prepares transactions — you approve every one in your own wallet.
          Nothing is ever signed or submitted automatically.
        </Note>
      </Card>

      <Card title="Your strategies">
        {rows.length === 0 ? (
          <Empty>No strategies configured.</Empty>
        ) : (
          rows.map((row) => (
            <div key={row.id} className="card flat" style={{ gap: 6 }}>
              <div className="row">
                <b>{row.name}</b>
                <Badge tone={row.is_active ? 'good' : 'muted'}>{row.mode}</Badge>
              </div>
              <Row
                k="Rules"
                v={`ROI>${row.rules?.min_roi_pct}% · rarity>${row.rules?.min_rarity} · liq>${row.rules?.min_liquidity}`}
              />
              <Row k="Matches" v={row.stats?.matches ?? 0} />
              <button
                className="btn ghost"
                onClick={async () => {
                  await endpoints.patch(`/strategies/${row.id}`, { is_active: !row.is_active });
                  await load();
                }}
              >
                {row.is_active ? 'Pause' : 'Activate'}
              </button>
            </div>
          ))
        )}
      </Card>
    </>
  );
}
