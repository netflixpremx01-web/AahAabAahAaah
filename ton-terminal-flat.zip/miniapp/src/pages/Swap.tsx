import { useEffect, useState } from 'react';
import { useTonAddress, useTonConnectUI } from '@tonconnect/ui-react';
import { Button, Card, Field, Note, Row, Stat } from '../components/ui';
import { endpoints } from '../lib/api';
import { ton } from '../lib/format-helpers';

const TOKENS = [
  { key: 'TON', label: 'TON' },
  { key: 'USDT', label: 'USDT' },
];

export default function Swap() {
  const [from, setFrom] = useState('TON');
  const [to, setTo] = useState('USDT');
  const [amount, setAmount] = useState('10');
  const [quote, setQuote] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tokens, setTokens] = useState<Record<string, string>>({});
  const address = useTonAddress(false);
  const [tonConnectUI] = useTonConnectUI();

  useEffect(() => {
    endpoints
      .get('/swap/tokens')
      .then((data: any) => setTokens(data.tokens ?? {}))
      .catch(() => undefined);
  }, []);

  const getQuote = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await endpoints.swapQuote({ from_token: from, to_token: to, amount: Number(amount) });
      setQuote(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Quote failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Card title="Swap">
        <div className="btn-row">
          <Field label="From">
            <select className="select" value={from} onChange={(event) => setFrom(event.target.value)}>
              {TOKENS.map((token) => (
                <option key={token.key} value={token.key}>
                  {token.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="To">
            <select className="select" value={to} onChange={(event) => setTo(event.target.value)}>
              {TOKENS.map((token) => (
                <option key={token.key} value={token.key}>
                  {token.label}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="Amount">
          <input
            className="input"
            inputMode="decimal"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
          />
        </Field>
        <Button onClick={getQuote} disabled={loading || !Number(amount)}>
          {loading ? 'Quoting…' : 'Get live quote'}
        </Button>
        <Note>
          Rates are fetched live from the DEX provider. Nothing is hardcoded and the quote expires
          quickly — re-quote before confirming.
        </Note>
      </Card>

      {error && <Note warning>{error}</Note>}

      {quote && (
        <Card title="Quote">
          <div className="grid three">
            <Stat label="You pay" value={`${ton(quote.from_amount)} ${from}`} />
            <Stat label="You receive" value={`${ton(quote.to_amount)} ${to}`} />
            <Stat label="Rate" value={ton(quote.rate, 4)} />
          </div>
          <Row k="Minimum received" v={`${ton(quote.min_received)} ${to}`} />
          <Row k="Price impact" v={`${Number(quote.price_impact) * 100 < 0.01 ? '<0.01' : (Number(quote.price_impact) * 100).toFixed(2)}%`} />
          <Row k="Network fee" v={`${ton(quote.network_fee_ton)} TON`} />
          <Row k="Provider" v={quote.provider} />
          <Row k="Expires" v={new Date(quote.expires_at).toLocaleTimeString()} />
          {quote.notes && <Note>{quote.notes}</Note>}
          <Note warning>
            Swap execution needs a transaction message built with the official DEX SDK in the client.
            This app shows the verified quote; the wallet step is enabled when the SDK integration is
            configured for your deployment.
          </Note>
          {!address ? (
            <Button onClick={() => tonConnectUI.openModal()}>Connect wallet</Button>
          ) : (
            <Button variant="secondary" disabled>
              Confirm in wallet (SDK step)
            </Button>
          )}
        </Card>
      )}

      <Card title="Known tokens" flat>
        {Object.entries(tokens).map(([symbol, tokenAddress]) => (
          <Row key={symbol} k={symbol} v={<span className="mono">{String(tokenAddress).slice(0, 12)}…</span>} />
        ))}
      </Card>
    </>
  );
}
