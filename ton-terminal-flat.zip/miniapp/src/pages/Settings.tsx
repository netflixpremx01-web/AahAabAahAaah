import { useEffect, useState } from 'react';
import { Badge, Card, Note, Row, Stat } from '../components/ui';
import { api, endpoints, type Config } from '../lib/api';

const CATEGORIES = [
  'opportunity',
  'purchase',
  'sale',
  'listing',
  'swap',
  'floor',
  'whale',
  'anomaly',
  'watchlist',
  'portfolio',
  'system',
];

export default function Settings() {
  const [config, setConfig] = useState<Config | null>(null);
  const [prefs, setPrefs] = useState<Record<string, boolean>>({});
  const [providers, setProviders] = useState<any>(null);

  useEffect(() => {
    endpoints.config().then(setConfig).catch(() => undefined);
    endpoints.providers().then(setProviders).catch(() => undefined);
    endpoints.me().then((me: any) => setPrefs(me.notification_prefs ?? {})).catch(() => undefined);
  }, []);

  const toggle = async (category: string) => {
    const next = { ...prefs, [category]: !prefs[category] };
    setPrefs(next);
    await api.patch('/auth/me', { notification_prefs: next });
  };

  return (
    <>
      <Card title="Environment">
        <div className="grid tiles">
          <Stat label="Network" value={config?.ton_network ?? '…'} />
          <Stat label="Real trading" value={config?.enable_real_trading ? 'ENABLED' : 'DISABLED'} />
          <Stat label="Paper trading" value={config?.enable_paper_trading ? 'ON' : 'OFF'} />
          <Stat label="Quote TTL" value={`${config?.quote_ttl_seconds ?? '—'}s`} />
        </div>
        <Row k="Marketplace fee" v={`${((config?.default_marketplace_fee_bps ?? 0) / 100).toFixed(2)}%`} />
        <Row k="Royalty assumption" v={`${((config?.default_royalty_bps ?? 0) / 100).toFixed(2)}%`} />
      </Card>

      <Card title="Notifications">
        {CATEGORIES.map((category) => (
          <div key={category} className="row">
            <span className="k">{category}</span>
            <button
              className={`btn ${prefs[category] ? '' : 'secondary'}`}
              style={{ width: 'auto', padding: '6px 12px' }}
              onClick={() => toggle(category)}
            >
              {prefs[category] ? 'On' : 'Off'}
            </button>
          </div>
        ))}
      </Card>

      <Card title="Provider status">
        {(providers?.marketplaces ?? []).map((provider: any) => (
          <div key={provider.name} className="card flat" style={{ gap: 4 }}>
            <div className="row">
              <b>{provider.name}</b>
              <Badge
                tone={
                  provider.status === 'live' ? 'good' : provider.status === 'unavailable' ? 'bad' : 'warn'
                }
              >
                {provider.status}
              </Badge>
            </div>
            <span className="subtitle">{provider.status_note}</span>
          </div>
        ))}
        {(providers?.dex ?? []).map((provider: any) => (
          <div key={provider.name} className="card flat" style={{ gap: 4 }}>
            <div className="row">
              <b>{provider.name}</b>
              <Badge tone="warn">{provider.status}</Badge>
            </div>
            <span className="subtitle">{provider.status_note}</span>
          </div>
        ))}
      </Card>

      <Card title="Security" flat>
        <Note>
          This terminal is non-custodial. It never asks for a seed phrase, private key or wallet
          password, never stores keys, and never signs or submits a transaction for you. API keys stay
          on the server; the Mini App only receives data it is explicitly given.
        </Note>
        <Note warning>
          Estimates (fair value, opportunity scores, theoretical P/L) are model outputs from public
          data — not guarantees. Always verify prices in your wallet before approving.
        </Note>
      </Card>
    </>
  );
}
