import { useEffect, useState } from 'react';
import { Card, Empty, Note, Row, Spinner, Stat } from '../components/ui';
import { endpoints } from '../lib/api';
import { short, signed, ton } from '../lib/format-helpers';

export default function Portfolio() {
  const [data, setData] = useState<any>(null);
  const [paper, setPaper] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [portfolio, paperData] = await Promise.all([endpoints.portfolio(), endpoints.paper()]);
      setData(portfolio);
      setPaper(paperData);
    } catch {
      /* surfaced as empty state */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const sync = async () => {
    setSyncing(true);
    try {
      await endpoints.post('/portfolio/sync');
      await load();
    } catch {
      /* ignore */
    } finally {
      setSyncing(false);
    }
  };

  if (loading) {
    return (
      <Card flat>
        <Spinner />
      </Card>
    );
  }

  const balances = data?.balances;

  return (
    <>
      <Card title="Balances">
        {balances ? (
          <div className="grid three">
            <Stat label="TON" value={ton(balances.ton)} />
            <Stat label="USDT" value={ton(balances.usdt, 2)} />
            <Stat label="NFTs" value={data?.holdings_count ?? 0} />
          </div>
        ) : (
          <Empty>Connect a wallet on the Hub tab to see balances.</Empty>
        )}
        <button className="btn secondary" onClick={sync} disabled={syncing}>
          {syncing ? 'Syncing…' : 'Sync from chain'}
        </button>
      </Card>

      <Card title="NFT P/L">
        <div className="grid three">
          <Stat label="Est. value" value={`${ton(data?.estimated_nft_value_ton)} TON`} />
          <Stat
            label="Unrealised"
            value={`${signed(data?.unrealized_pnl_ton)} TON`}
            tone={Number(data?.unrealized_pnl_ton ?? 0) >= 0 ? 'good' : 'bad'}
          />
          <Stat
            label="Realised"
            value={`${signed(data?.realized_pnl_ton)} TON`}
            tone={Number(data?.realized_pnl_ton ?? 0) >= 0 ? 'good' : 'bad'}
          />
        </div>
        <Note>{data?.note}</Note>
      </Card>

      <Card title="Holdings">
        {(data?.holdings ?? []).length === 0 ? (
          <Empty>No tracked holdings yet.</Empty>
        ) : (
          (data?.holdings ?? []).slice(0, 30).map((holding: any) => (
            <Row
              key={holding.nft_address}
              k={
                <span>
                  {holding.name ?? <span className="mono">{short(holding.nft_address, 5)}</span>}
                  <br />
                  <span className="subtitle">
                    entry {ton(holding.avg_entry_ton)} · floor {ton(holding.floor_ton)}
                  </span>
                </span>
              }
              v={
                <span style={{ color: Number(holding.unrealized_pnl_ton) >= 0 ? 'var(--good)' : 'var(--bad)' }}>
                  {signed(holding.unrealized_pnl_ton)} TON
                </span>
              }
            />
          ))
        )}
      </Card>

      <Card title="Paper trading">
        <div className="grid three">
          <Stat label="Closed" value={paper?.stats?.trades ?? 0} />
          <Stat label="Win rate" value={`${paper?.stats?.win_rate_pct ?? 0}%`} />
          <Stat label="P/L" value={`${signed(paper?.stats?.realized_pnl_ton)} TON`} />
        </div>
        <Note>{paper?.stats?.note ?? 'Simulated trading only — no real funds are involved.'}</Note>
      </Card>
    </>
  );
}
