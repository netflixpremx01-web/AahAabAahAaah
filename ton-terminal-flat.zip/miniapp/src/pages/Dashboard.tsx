import { useEffect, useState } from 'react';
import { useTonAddress, useTonConnectUI } from '@tonconnect/ui-react';
import { Card, Stat, Button, Note, Empty } from '../components/ui';
import { endpoints } from '../lib/api';
import { useWalletSync } from '../lib/wallet';
import { haptic, short } from '../lib/format-helpers';

const TILES = [
  { key: 'radar', icon: '🔥', label: 'Radar', hint: 'Live opportunities' },
  { key: 'trade', icon: '🛒', label: 'Buy / Sell', hint: 'Prepare transactions' },
  { key: 'swap', icon: '🔄', label: 'Swap', hint: 'TON ⇄ USDT' },
  { key: 'portfolio', icon: '💼', label: 'Portfolio', hint: 'Holdings & P/L' },
  { key: 'analyze', icon: '🧬', label: 'Analyze NFT', hint: 'Rarity & fair value' },
  { key: 'watchlist', icon: '👀', label: 'Watchlist', hint: 'Price alerts' },
  { key: 'strategies', icon: '🧠', label: 'Strategies', hint: 'Automate your rules' },
  { key: 'market', icon: '🐋', label: 'Market', hint: 'Health, whales, anomalies' },
];

export default function Dashboard({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const [tonConnectUI] = useTonConnectUI();
  const address = useTonAddress(false);
  const [portfolio, setPortfolio] = useState<any>(null);
  const [counts, setCounts] = useState<{ opportunities: number; open: number }>({
    opportunities: 0,
    open: 0,
  });
  const [loading, setLoading] = useState(true);

  useWalletSync();

  useEffect(() => {
    let active = true;
    Promise.all([endpoints.portfolio(), endpoints.opportunities(50, 5), endpoints.paper()])
      .then(([portfolioData, radar, paper]) => {
        if (!active) return;
        setPortfolio(portfolioData);
        setCounts({
          opportunities: radar.opportunities.length,
          open: Number(paper.stats?.open ?? 0),
        });
      })
      .catch(() => undefined)
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [address]);

  const balances = portfolio?.balances;

  return (
    <>
      <Card title="Wallet">
        {address ? (
          <>
            <div className="row">
              <span className="k mono">{short(address, 8)}</span>
              <span className="badge good">connected</span>
            </div>
            <div className="grid three">
              <Stat label="TON" value={balances ? Number(balances.ton).toFixed(2) : '…'} />
              <Stat label="USDT" value={balances ? Number(balances.usdt).toFixed(2) : '…'} />
              <Stat label="NFTs" value={portfolio?.holdings_count ?? '…'} />
            </div>
            <div className="btn-row">
              <Button variant="secondary" onClick={() => tonConnectUI.disconnect()}>
                Disconnect
              </Button>
            </div>
          </>
        ) : (
          <>
            <Note>
              Connect your TON wallet to see balances and trade. The app never asks for a seed
              phrase or private key — transactions are approved in your own wallet.
            </Note>
            <Button onClick={() => tonConnectUI.openModal()}>Connect wallet</Button>
          </>
        )}
      </Card>

      <Card title="Today">
        <div className="grid three">
          <Stat label="Opportunities" value={loading ? '…' : counts.opportunities} />
          <Stat label="Paper open" value={loading ? '…' : counts.open} />
          <Stat
            label="Unrealised"
            value={portfolio ? Number(portfolio.unrealized_pnl_ton).toFixed(2) : '0.00'}
            tone={Number(portfolio?.unrealized_pnl_ton ?? 0) >= 0 ? 'good' : 'bad'}
          />
        </div>
      </Card>

      <div className="grid tiles">
        {TILES.map((tile) => (
          <button
            key={tile.key}
            className="tile"
            onClick={() => {
              haptic('light');
              onNavigate(tile.key);
            }}
          >
            <span className="tile-icon">{tile.icon}</span>
            <span className="tile-label">{tile.label}</span>
            <span className="tile-hint">{tile.hint}</span>
          </button>
        ))}
      </div>

      {!counts.opportunities && !loading && (
        <Card flat>
          <Empty>No high-score opportunities yet. Scan a collection on the Radar tab.</Empty>
        </Card>
      )}
    </>
  );
}
