import { useEffect, useState } from 'react';
import {
  Badge,
  Button,
  Card,
  Empty,
  Field,
  Note,
  Progress,
  Row,
  Sheet,
  Spinner,
  Stat,
} from '../components/ui';
import { endpoints, type Opportunity } from '../lib/api';
import { riskTone, scoreTone, short, ton, haptic } from '../lib/format-helpers';

export default function Radar({
  onBuy,
  onAnalyze,
}: {
  onBuy: (nftAddress?: string) => void;
  onAnalyze: (nftAddress?: string) => void;
}) {
  const [items, setItems] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);
  const [collection, setCollection] = useState('');
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Opportunity | null>(null);

  const load = async (minScore = 40) => {
    setLoading(true);
    try {
      const data = await endpoints.opportunities(minScore, 25);
      setItems(data.opportunities);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load opportunities');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const scan = async () => {
    if (!collection.trim()) return;
    setScanning(true);
    setError(null);
    try {
      const result = await endpoints.scan(collection.trim(), 0, 25);
      setItems(result.opportunities);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Scan failed');
    } finally {
      setScanning(false);
    }
  };

  const paperBuy = async (opportunity: Opportunity) => {
    await endpoints.paperOpen({
      nft_address: opportunity.nft_address,
      collection_address: opportunity.collection_address,
      entry_price: Number(opportunity.listed_price_ton),
      notes: 'opened from radar',
    });
    haptic('success');
    setSelected(null);
  };

  const watch = async (opportunity: Opportunity) => {
    if (!opportunity.nft_address) return;
    await endpoints.addWatch({
      target_type: 'nft',
      target_ref: opportunity.nft_address,
      condition: 'price_below',
      threshold: Number(opportunity.listed_price_ton),
    });
    haptic('success');
  };

  return (
    <>
      <Card title="Scan a collection">
        <Field label="Collection address">
          <input
            className="input"
            placeholder="EQ… / 0:…"
            value={collection}
            onChange={(event) => setCollection(event.target.value)}
          />
        </Field>
        <Button onClick={scan} disabled={scanning || !collection.trim()}>
          {scanning ? 'Scanning…' : 'Scan now'}
        </Button>
        <Note>
          Scanning indexes listings, sales and metadata, then scores every listing. Rate limits are
          respected — large collections take a few moments.
        </Note>
      </Card>

      {error && <Card flat><Note warning>{error}</Note></Card>}
      {loading ? (
        <Card flat><Spinner /></Card>
      ) : items.length === 0 ? (
        <Card flat>
          <Empty>Nothing above the threshold. Scan a collection or lower the filter.</Empty>
        </Card>
      ) : (
        items.map((item) => (
          <Card key={item.id} title={`${item.marketplace} · score ${item.opportunity_score}`}>
            <div className="row">
              <span className="mono">{short(item.nft_address ?? item.listing_id, 6)}</span>
              <div style={{ display: 'flex', gap: 6 }}>
                <Badge tone={riskTone(item.risk_level)}>{item.risk_level}</Badge>
                <Badge tone={scoreTone(item.opportunity_score)}>{item.opportunity_score}/100</Badge>
              </div>
            </div>
            <div className="grid three">
              <Stat label="Listed" value={`${ton(item.listed_price_ton)} TON`} />
              <Stat
                label="Fair value"
                value={`${ton(item.fair_value_low)}–${ton(item.fair_value_high)}`}
              />
              <Stat label="Discount" value={`${ton(item.discount_pct)}%`} tone="good" />
            </div>
            <div className="grid three">
              <Stat label="Rarity" value={item.rarity_score ?? '—'} />
              <Stat label="Liquidity" value={item.liquidity_score ?? '—'} />
              <Stat label="Confidence" value={item.confidence ?? '—'} />
            </div>
            <div className="btn-row">
              <Button variant="secondary" onClick={() => setSelected(item)}>
                Details
              </Button>
              <Button onClick={() => onBuy(item.nft_address ?? undefined)}>Buy</Button>
            </div>
          </Card>
        ))
      )}

      {selected && (
        <Sheet title="Opportunity details" onClose={() => setSelected(null)}>
          <div className="grid three">
            <Stat label="Score" value={`${selected.opportunity_score}/100`} />
            <Stat label="ROI (theoretical)" value={`${ton(selected.roi_pct)}%`} />
            <Stat label="Risk" value={selected.risk_level} tone={riskTone(selected.risk_level)} />
          </div>
          <Progress value={selected.opportunity_score} tone={scoreTone(selected.opportunity_score)} />
          <div className="divider" />
          <Row k="Listed price" v={`${ton(selected.listed_price_ton)} TON`} />
          <Row k="Fair value" v={`${ton(selected.fair_value_low)}–${ton(selected.fair_value_high)} TON`} />
          <Row k="Est. costs" v={`${ton(selected.estimated_costs_ton)} TON`} />
          <Row k="Theoretical upside" v={`${ton(selected.theoretical_profit_ton)} TON`} />
          <div className="divider" />
          {(selected.reasons ?? []).map((reason) => (
            <Note key={reason}>{reason}</Note>
          ))}
          <Note warning>
            Estimates only. Fair value is modelled from public data and is not a guaranteed resale
            price.
          </Note>
          <div className="btn-row">
            <Button variant="secondary" onClick={() => paperBuy(selected)}>
              Paper buy
            </Button>
            <Button variant="secondary" onClick={() => watch(selected)}>
              Watch
            </Button>
          </div>
          <Button variant="ghost" onClick={() => onAnalyze(selected.nft_address ?? undefined)}>
            Full analysis
          </Button>
        </Sheet>
      )}
    </>
  );
}
