import { useState } from 'react';
import { Badge, Button, Card, Empty, Field, Note, Row, Spinner, Stat } from '../components/ui';
import { endpoints } from '../lib/api';
import { short, ton } from '../lib/format-helpers';

export default function Market() {
  const [address, setAddress] = useState('');
  const [data, setData] = useState<any>(null);
  const [anomalies, setAnomalies] = useState<any[]>([]);
  const [whales, setWhales] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = async (sync: boolean) => {
    if (!address.trim()) return;
    setLoading(true);
    setError(null);
    try {
      if (sync) await endpoints.syncCollection(address.trim());
      const [collection, anomalyData, whaleData] = await Promise.all([
        endpoints.market(address.trim()),
        endpoints.anomalies(address.trim()),
        endpoints.whales(address.trim()),
      ]);
      setData(collection);
      setAnomalies(anomalyData.anomalies ?? []);
      setWhales(whaleData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load market data');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Card title="Collection intelligence">
        <Field label="Collection address">
          <input
            className="input"
            placeholder="EQ… / 0:…"
            value={address}
            onChange={(event) => setAddress(event.target.value)}
          />
        </Field>
        <div className="btn-row">
          <Button onClick={() => load(false)} disabled={loading || !address.trim()}>
            {loading ? 'Loading…' : 'Load'}
          </Button>
          <Button variant="secondary" onClick={() => load(true)} disabled={loading || !address.trim()}>
            Sync + load
          </Button>
        </div>
      </Card>

      {error && <Note warning>{error}</Note>}
      {loading && (
        <Card flat>
          <Spinner />
        </Card>
      )}

      {data && (
        <Card title={data.name ?? short(data.address, 6)}>
          <div className="grid three">
            <Stat label="Floor" value={`${ton(data.floor_price_ton)} TON`} />
            <Stat label="24h volume" value={`${ton(data.volume_24h_ton)} TON`} />
            <Stat label="7d volume" value={`${ton(data.volume_7d_ton)} TON`} />
          </div>
          <div className="grid three">
            <Stat label="Health" value={`${data.health?.score ?? '—'}/100`} />
            <Stat label="Trend" value={data.health?.trend ?? '—'} />
            <Stat label="Listings" value={data.listings_count ?? 0} />
          </div>
          {(data.health?.notes ?? []).map((note: string) => (
            <Note key={note}>{note}</Note>
          ))}
        </Card>
      )}

      {anomalies.length > 0 && (
        <Card title="Anomalies">
          {anomalies.map((anomaly: any) => (
            <div key={anomaly.kind} className="card flat" style={{ gap: 6 }}>
              <div className="row">
                <b>{anomaly.kind.replace(/_/g, ' ')}</b>
                <Badge tone={anomaly.severity === 'high' ? 'bad' : anomaly.severity === 'medium' ? 'warn' : 'muted'}>
                  {anomaly.severity}
                </Badge>
              </div>
              <span className="subtitle">{anomaly.message}</span>
            </div>
          ))}
          <Note>Pattern observations from public data. No accusation of wrongdoing is implied.</Note>
        </Card>
      )}

      {whales && (
        <Card title="Whale activity">
          <div className="grid three">
            <Stat label="Absorbed" value={whales.accumulation?.net_items_absorbed ?? 0} />
            <Stat label="Distributed" value={whales.accumulation?.net_items_distributed ?? 0} />
            <Stat
              label="Signal"
              value={whales.accumulation?.signal ?? '—'}
              tone={whales.accumulation?.signal === 'HIGH' ? 'good' : undefined}
            />
          </div>
          {(whales.signals ?? []).map((signal: any) => (
            <Row key={signal.wallet} k={<span className="mono">{short(signal.wallet, 5)}</span>} v={signal.message} />
          ))}
          {!whales.signals?.length && <Empty>No concentrated activity in the selected window.</Empty>}
          <Note>{whales.accumulation?.note}</Note>
        </Card>
      )}
    </>
  );
}
