import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The Mini App talks to the FastAPI backend through relative /api paths so it
// works behind the Telegram WebView, the Vite dev proxy and any reverse proxy.
export default defineConfig({
  plugins: [react()],
  base: './',
  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {
      '/api': 'http://localhost:8000',
      '/tonconnect-manifest.json': 'http://localhost:8000',
    },
  },
  build: { outDir: 'dist', sourcemap: false, emptyOutDir: true },
});
