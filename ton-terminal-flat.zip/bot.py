"""Entrypoint shim for the Telegram bot (same sys.path fix as ``main.py``).

Usage:  python bot.py
"""
from __future__ import annotations

import asyncio
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app.bot.main import main  # noqa: E402

if __name__ == "__main__":
    asyncio.run(main())
