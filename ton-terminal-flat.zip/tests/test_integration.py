"""Integration tests: API endpoints and services with mocked providers.

No network access and no real provider credentials are used anywhere here.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal

import pytest
from fastapi.testclient import TestClient


def _reset_engine() -> None:
    """Drop the cached SQLAlchemy engine so DATABASE_URL changes take effect."""
    import app.database.session as db_session_module

    db_session_module._engine = None
    db_session_module._sessionmaker = None


@pytest.fixture
def client(tmp_path, monkeypatch):
    db_file = tmp_path / "api.sqlite"
    monkeypatch.setenv("DATABASE_URL", f"sqlite+aiosqlite:///{db_file}")
    monkeypatch.setenv("DEV_MODE", "true")
    from app.core.config import get_settings

    get_settings.cache_clear()
    _reset_engine()
    from app.api.main import create_app

    app = create_app()
    with TestClient(app) as test_client:
        yield test_client
    get_settings.cache_clear()
    _reset_engine()


class FakeDexAdapter:
    """Deterministic stand-in for a real DEX API."""

    def __init__(self) -> None:
        self.name = "fake-dex"
        self.docs_url = "https://example.invalid/docs"
        self.status = "fake"
        self.status_note = "Test double"

    def capabilities(self):
        from app.integrations.dex.base import DexCapabilities

        return DexCapabilities(quote=True, route=True, pools=True, tokens=True, build_transaction=False)

    async def get_supported_tokens(self, search=None):
        from app.integrations.dex.base import TokenInfo

        return [TokenInfo(address="TON", symbol="TON", decimals=9, kind="native")]

    async def get_pool_data(self, token0, token1):
        from app.integrations.dex.base import PoolInfo

        return [PoolInfo(address="EQPOOL", token0=token0, token1=token1, reserve0=1000, reserve1=1000, provider="fake-dex")]

    async def get_quote(self, request):
        from app.integrations.dex.base import RouteHop, SwapQuote

        return SwapQuote(
            provider="fake-dex",
            from_token=request.from_token,
            to_token=request.to_token,
            from_amount=Decimal(str(request.amount)),
            to_amount=Decimal(str(request.amount)) * Decimal("2"),
            min_received=Decimal(str(request.amount)) * Decimal("1.98"),
            rate=Decimal("2"),
            price_impact=Decimal("0.001"),
            network_fee_ton=Decimal("0.05"),
            route=[RouteHop(provider="fake-dex", pool_address="EQPOOL", from_token=request.from_token, to_token=request.to_token)],
            slippage=request.slippage_value,
            raw={"offer_units": "1000000000"},
        )

    async def get_swap_route(self, request):
        return (await self.get_quote(request)).route

    async def prepare_swap_transaction(self, quote, wallet_address):
        from app.core.errors import CapabilityNotSupported

        raise CapabilityNotSupported("test double")

    async def get_token_decimals(self, address):
        return 9


def test_health_and_public_config_hide_secrets(client):
    assert client.get("/api/health").json()["status"] == "ok"
    config = client.get("/api/config").json()
    assert "toncenter_api_key" not in config
    assert "telegram_bot_token" not in config
    providers = client.get("/api/providers").json()
    assert any(p["name"] == "portals" and p["status"] == "unavailable" for p in providers["marketplaces"])
    assert any(p["name"] == "stonfi" for p in providers["dex"])


def test_user_bootstrap_and_preferences(client):
    me = client.get("/api/auth/me").json()
    assert me["telegram_id"] == 1  # dev-mode identity
    response = client.patch("/api/auth/me", json={"notification_prefs": {"whale": False}})
    assert response.json()["notification_prefs"]["whale"] is False


def test_swap_quote_uses_configured_adapter(client, monkeypatch):
    import app.integrations.dex.registry as registry

    monkeypatch.setattr(registry, "_ADAPTERS", {"fake-dex": FakeDexAdapter()})
    response = client.post(
        "/api/swap/quote", json={"from_token": "TON", "to_token": "USDT", "amount": 10}
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["provider"] == "fake-dex"
    assert Decimal(payload["to_amount"]) == Decimal("20")
    assert payload["quote_id"]


def test_paper_trading_round_trip(client):
    opened = client.post("/api/paper/open", json={"entry_price": 50}).json()
    assert opened["status"] == "open"
    closed = client.post(
        "/api/paper/close", json={"trade_id": opened["id"], "exit_price": 75}
    ).json()
    assert Decimal(closed["pnl_ton"]) > 0
    stats = client.get("/api/paper").json()["stats"]
    assert stats["trades"] == 1
    assert stats["win_rate_pct"] == "100.00"


def test_watchlist_crud(client):
    created = client.post(
        "/api/watchlist",
        json={"target_type": "nft", "target_ref": "EQTEST", "condition": "price_below", "threshold": 60},
    ).json()
    assert created["id"]
    listed = client.get("/api/watchlist").json()["watchlist"]
    assert listed[0]["target_ref"] == "EQTEST"
    assert client.delete(f"/api/watchlist/{created['id']}").json()["removed"] is True


def test_watchlist_threshold_is_required_for_price_conditions(client):
    response = client.post(
        "/api/watchlist", json={"target_type": "nft", "target_ref": "EQTEST", "condition": "price_below"}
    )
    assert response.status_code == 400


def test_buy_preparation_reports_unavailable_marketplace_honestly(client):
    response = client.post("/api/trading/buy/prepare", json={"nft_address": "EQUNKNOWN"})
    assert response.status_code == 404 or response.json().get("available") is False
    payload = response.json()
    if response.status_code == 200:
        assert "unavailable_reason" in payload
        assert payload["requires_wallet_approval"] is True


def test_real_trading_is_disabled_by_default(client, monkeypatch):
    from app.core.config import get_settings

    settings = get_settings()
    assert settings.enable_real_trading is False
    response = client.post(
        "/api/trading/submit",
        json={"kind": "buy", "wallet_address": "EQWALLET", "amount_ton": 1},
    )
    assert response.status_code == 403


def test_notifications_are_quiet_by_default(client):
    assert client.get("/api/notifications").json()["notifications"] == []


class FakeTonCenter:
    """Minimal TON Center stand-in returning decoded ``nft_purchase`` actions."""

    def __init__(self, actions):
        self.actions = actions

    async def get_nft_purchases(self, **kwargs):
        return self.actions

    async def get_nft_collections(self, address, **kwargs):
        return [
            {
                "address": address,
                "collection_content": {"name": "Test Collection"},
                "next_item_index": "1000",
                "owner_address": None,
            }
        ]

    async def get_metadata(self, address):
        return {}

    async def get_nft_items(self, *args, **kwargs):
        return []


@pytest.mark.asyncio
async def test_sales_are_ingested_from_nft_purchase_actions(session):
    from app.services.market import MarketService

    now = int(datetime.now(UTC).timestamp())
    actions = [
        {
            "trace_id": "trace-1",
            "end_utime": now,
            "type": "nft_purchase",
            "details": {
                "nft_item": "0:aaa",
                "nft_collection": "0:collection",
                "price": "50000000000",
                "old_owner": "0:seller",
                "new_owner": "0:buyer",
                "marketplace_address": "0:584ee61b2dff0837116d0fcb5078d93964bcbe9c05fd6a141b1bfca5d6a43e18",
            },
        },
        {
            "trace_id": "trace-2",
            "end_utime": now,
            "type": "nft_purchase",
            "details": {
                "nft_item": "0:bbb",
                "nft_collection": "0:collection",
                "price": "1000000000",
                "old_owner": "0:seller2",
                "new_owner": "0:buyer2",
                "marketplace_address": "0:unknown",
            },
        },
    ]
    service = MarketService(session)
    service.toncenter = FakeTonCenter(actions)  # type: ignore[assignment]

    collection = await service.ensure_collection("0:collection")
    count = await service.sync_sales("0:collection")
    assert count == 2
    assert collection.name == "Test Collection"

    from sqlalchemy import select

    from app.models.orm import Sale

    rows = (await session.execute(select(Sale))).scalars().all()
    prices = sorted(Decimal(str(row.price_ton)) for row in rows)
    assert prices == [Decimal("1"), Decimal("50")]
    marketplaces = {row.marketplace for row in rows}
    assert marketplaces == {"getgems", "unknown"}
    assert rows[0].sold_at <= datetime.now(UTC).replace(tzinfo=None) + timedelta(minutes=1)


@pytest.mark.asyncio
async def test_collection_health_reflects_ingested_sales(session):
    from app.services.market import MarketService

    now = int(datetime.now(UTC).timestamp())
    actions = [
        {
            "trace_id": f"trace-{i}",
            "end_utime": now - i * 3600,
            "type": "nft_purchase",
            "details": {
                "nft_item": f"0:nft{i}",
                "nft_collection": "0:collection2",
                "price": "20000000000",
                "old_owner": f"0:seller{i}",
                "new_owner": "0:whale",
                "marketplace_address": "0:unknown",
            },
        }
        for i in range(6)
    ]
    service = MarketService(session)
    service.toncenter = FakeTonCenter(actions)  # type: ignore[assignment]
    await service.sync_sales("0:collection2")
    report = await service.whales("0:collection2", hours=72)
    assert int(report["accumulation"]["wallets_analysed"]) >= 2
    assert any(signal["wallet"] == "0:whale" for signal in report["signals"])
