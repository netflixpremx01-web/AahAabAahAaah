"""Premium custom emoji system."""
from app.bot import emojis


def test_supplied_ids_are_centralised():
    assert emojis.CUSTOM_EMOJIS["one"] == "5247133031235329609"
    assert len(emojis.CUSTOM_EMOJIS) >= 30


def test_custom_emoji_entity_is_created():
    rendered = emojis.render(f"{emojis.e('one')} Wallet")
    assert rendered.text.startswith("1️⃣")
    assert len(rendered.entities) == 1
    entity = rendered.entities[0]
    assert entity.type == "custom_emoji"
    assert entity.custom_emoji_id == emojis.CUSTOM_EMOJIS["one"]
    assert entity.offset == 0
    assert entity.length == emojis.utf16_len("1️⃣")


def test_missing_id_falls_back_to_unicode_without_entity():
    rendered = emojis.render(f"{emojis.e('wallet')} Wallet")
    assert rendered.text.startswith("👛")
    assert rendered.entities == []


def test_unknown_token_is_left_alone():
    assert emojis.render("plain {unknown} text").text == "plain  text"


def test_malformed_ids_are_reported():
    problems = emojis.validate_ids()
    assert any(problem.startswith("six=") for problem in problems)


def test_offsets_are_utf16_code_units():
    rendered = emojis.render(f"a{emojis.e('one')}")
    assert rendered.entities[0].offset == 1
