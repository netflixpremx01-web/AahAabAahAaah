"""Fair value engine."""
from decimal import Decimal

from app.nft.valuation import FairValueInput, discount_pct, estimate_fair_value


def test_floor_only_has_low_confidence():
    result = estimate_fair_value(FairValueInput(floor=Decimal("50")))
    assert result.method == "floor-only"
    assert result.confidence < 40
    assert result.low < result.mid < result.high


def test_comparables_raise_confidence_and_value():
    result = estimate_fair_value(
        FairValueInput(
            floor=Decimal("50"),
            comparable_sales=[Decimal("90"), Decimal("95"), Decimal("100")],
            rarity_score=80,
            liquidity_score=75,
            trend="bullish",
        )
    )
    assert result.method == "comparable-weighted"
    assert result.mid > Decimal("50")
    assert result.confidence >= 50


def test_illiquidity_reduces_value():
    liquid = estimate_fair_value(FairValueInput(floor=Decimal("50"), liquidity_score=90))
    illiquid = estimate_fair_value(FairValueInput(floor=Decimal("50"), liquidity_score=10))
    assert illiquid.mid < liquid.mid
    assert any("Illiquidity" in note for note in illiquid.notes)


def test_insufficient_data_returns_zero_confidence():
    result = estimate_fair_value(FairValueInput())
    assert result.confidence == 0
    assert result.method == "insufficient-data"


def test_discount_percentage():
    assert discount_pct(Decimal("50"), Decimal("100")) == Decimal("50.00")
    assert discount_pct(Decimal("120"), Decimal("100")) == Decimal("-20.00")
    assert discount_pct(None, Decimal("100")) == Decimal("0")


def test_number_premium_is_capped():
    result = estimate_fair_value(
        FairValueInput(floor=Decimal("10"), number_premium=Decimal("50"), number_score=100)
    )
    assert result.mid <= Decimal("10") * 3 + Decimal("1")
