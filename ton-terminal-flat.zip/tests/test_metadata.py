"""NFT metadata parsing (TON metadata standard, malformed input included)."""

import pytest

from app.models.enums import MetadataStatus
from app.nft.metadata import (
    NFTMetadataService,
    extract_number,
    normalise_attributes,
    resolve_url,
)


def test_resolve_url_variants():
    assert resolve_url("ipfs://CID/path.json") == "https://ipfs.io/ipfs/CID/path.json"
    assert resolve_url("https://x.io/a.json") == "https://x.io/a.json"
    assert resolve_url("//cdn.io/a.json") == "https://cdn.io/a.json"
    assert resolve_url("data:application/json;base64,AAA") is None
    assert resolve_url(None) is None


def test_normalise_attributes_shapes():
    assert normalise_attributes({"Background": "Blue"}) == {"Background": "Blue"}
    assert normalise_attributes([{"trait_type": "Model", "value": "Rare"}]) == {"Model": "Rare"}
    assert normalise_attributes([["Number", 420]]) == {"Number": "420"}
    assert normalise_attributes(None) == {}
    assert normalise_attributes("bad") == {}


def test_extract_number_sources():
    assert extract_number(attributes={"Number": "420"}) == 420
    assert extract_number(attributes={}, name="Cool #777") == 777
    assert extract_number(attributes={}, name="Cool", index="42") == 42
    assert extract_number(attributes={}, name="Cool") is None


def test_malformed_metadata_does_not_raise():
    assert normalise_attributes([{"trait_type": "A"}, {"value": "B"}, "junk", 5]) == {}


class _FakeTonCenter:
    def __init__(self, item):
        self.item = item

    async def get_nft_items(self, address, **kwargs):
        return [self.item]

    async def get_metadata(self, address):
        return {}


@pytest.mark.asyncio
async def test_resolve_merges_uri_and_onchain_content():
    service = NFTMetadataService(toncenter=_FakeTonCenter({}))  # type: ignore[arg-type]

    async def fake_fetch(url: str) -> dict:
        return {
            "name": "XYZ #420",
            "description": "desc",
            "image": "ipfs://CID/img.png",
            "attributes": [{"trait_type": "Background", "value": "Midnight Blue"}],
        }

    service.fetch_metadata_json = fake_fetch  # type: ignore[method-assign]
    service.toncenter = _FakeTonCenter(  # type: ignore[assignment]
        {
            "address": "0:abc",
            "index": "420",
            "collection_address": "0:collection",
            "owner_address": "0:owner",
            "content": {"uri": "https://meta.io/420.json"},
        }
    )
    result = await service.resolve("0:abc")
    assert result.name == "XYZ #420"
    assert result.image_url == "https://ipfs.io/ipfs/CID/img.png"
    assert result.attributes == {"Background": "Midnight Blue"}
    assert result.status is MetadataStatus.OK


@pytest.mark.asyncio
async def test_missing_metadata_is_reported_not_faked():
    service = NFTMetadataService(toncenter=_FakeTonCenter({"address": "0:x", "content": {}}))  # type: ignore[arg-type]
    result = await service.resolve("0:x")
    assert result.status is MetadataStatus.FAILED
    assert result.error


@pytest.mark.asyncio
async def test_unreachable_metadata_falls_back_gracefully():
    service = NFTMetadataService(
        toncenter=_FakeTonCenter(  # type: ignore[arg-type]
            {"address": "0:y", "content": {"uri": "https://dead.invalid/meta.json"}}
        )
    )

    async def failing(url: str) -> dict:
        raise RuntimeError("unreachable")

    service.fetch_metadata_json = failing  # type: ignore[method-assign]
    result = await service.resolve("0:y")
    assert result.status is MetadataStatus.FAILED
    assert "unreachable" in (result.error or "")
