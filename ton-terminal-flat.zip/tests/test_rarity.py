"""Trait rarity, combination rarity and normalisation."""
from decimal import Decimal

from app.nft.rarity import analyse_collection_rarity
from app.nft.traits import build_trait_index, combination_result, rarity_score


def test_trait_index_counts():
    items = [{"BG": "Blue"}, {"BG": "Blue"}, {"BG": "Red"}]
    index = build_trait_index(items)
    assert index[("BG", "Blue")] == 2
    assert index[("BG", "Red")] == 1


def test_statistical_rarity():
    items = [{"Model": "Rare"}] + [{"Model": "Common"}] * 99
    index = build_trait_index(items)
    rare = rarity_score({"Model": "Rare"}, index, 100)
    common = rarity_score({"Model": "Common"}, index, 100)
    assert rare == Decimal("100")
    # 99 of 100 items share the trait -> scarcity just above 1.0
    assert common == Decimal("1.0101")


def test_combination_rarity_and_label():
    items = [{"BG": "Blue", "Model": "Rare"}] * 3 + [{"BG": "Red", "Model": "Common"}] * 9997
    result = combination_result({"BG": "Blue", "Model": "Rare"}, items, total_items=10000)
    assert result.matches == 3
    assert result.label == "Extremely Rare"
    assert result.score >= 80
    assert result.rarity_pct == Decimal("0.0300")


def test_combination_present_everywhere_is_common():
    items = [{"BG": "Blue"}] * 100
    result = combination_result({"BG": "Blue"}, items, total_items=100)
    assert result.label == "Common"
    assert result.score == 0


def test_full_report_projects_onto_collection_scale():
    collection = [{"BG": "Blue", "Model": "Rare"}] * 5 + [{"BG": "Red", "Model": "Common"}] * 95
    rare = analyse_collection_rarity(
        target_traits={"BG": "Blue", "Model": "Rare"}, collection_traits=collection
    )
    common = analyse_collection_rarity(
        target_traits={"BG": "Red", "Model": "Common"}, collection_traits=collection
    )
    assert rare.score == 100
    assert rare.rank == 1
    assert common.score < 20
    assert rare.traits and rare.traits[0]["rarity_pct"]
