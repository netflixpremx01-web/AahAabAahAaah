"""Bot message rendering: templates + custom emoji entities never crash."""
from app.bot import formatting as fmt
from app.bot.emojis import render
from app.models.orm import User

TEMPLATES = {
    "welcome": fmt.welcome("Ada"),
    "help": fmt.help_text(),
    "wallet_empty": fmt.wallet_card(None, None),
    "wallet": fmt.wallet_card({"ton": "12.5", "usdt": "40.0"}, "EQWALLET"),
    "radar": fmt.radar_card(
        {
            "name": "Cool #420",
            "listed_price_ton": "50",
            "fair_value_low": "83",
            "fair_value_high": "105",
            "discount_pct": "46.8",
            "rarity_score": 94,
            "number_score": 98,
            "liquidity_score": 83,
            "estimated_costs_ton": "8",
            "theoretical_profit_ton": "36",
            "risk_level": "medium",
            "confidence": 88,
            "opportunity_score": 91,
        }
    ),
    "analysis": fmt.analysis_card(
        {
            "name": "Cool #420",
            "fair_value": {"low": "83", "high": "105", "confidence": 80, "method": "comparable-weighted"},
            "liquidity": {"score": 70, "risk": "low"},
            "rarity": {"score": 90, "percentile": "99.41"},
            "number_profile": {"value": 420, "labels": ["special", "palindrome"]},
            "floor": "60",
            "listing_price": "50",
            "theoretical_profit_ton": "36",
        }
    ),
    "collection": fmt.collection_card(
        {"address": "0:abc", "name": "Test", "floor_price_ton": "60", "volume_24h_ton": "100"},
        {"score": 72, "trend": "bullish", "notes": ["healthy volume"]},
    ),
    "anomalies": fmt.anomalies_card(
        [{"kind": "floor_crash", "severity": "high", "message": "floor dropped 22%", "evidence": {}}]
    ),
    "whale": fmt.whale_card(
        {
            "collection": "0:abc",
            "accumulation": {"net_items_absorbed": 12, "net_items_distributed": 2, "signal": "HIGH"},
            "signals": [{"wallet": "0:whale1234567890", "message": "absorbed 12 NFTs"}],
        }
    ),
    "buy": fmt.buy_confirmation(
        {
            "nft": {"name": "Cool #420", "address": "0:nft"},
            "collection": {"name": "Test"},
            "marketplace": "portals",
            "price_ton": "50",
            "costs": {"total_costs": "5.05"},
            "total_ton": "55.05",
            "network": "mainnet",
            "available": False,
            "unavailable_reason": "no public API",
            "requires_wallet_approval": True,
        }
    ),
    "swap": fmt.swap_quote_card(
        {
            "from_amount": "10",
            "to_amount": "13.63",
            "rate": "1.363",
            "price_impact": "0.0005",
            "network_fee_ton": "0.045",
            "min_received": "13.49",
            "expires_at": "2026-01-01T00:00:00",
            "provider": "stonfi",
        }
    ),
    "portfolio": fmt.portfolio_card(
        {
            "wallet": {"address": "EQWALLET"},
            "balances": {"ton": "12.5", "usdt": "40"},
            "holdings_count": 3,
            "estimated_nft_value_ton": "180",
            "unrealized_pnl_ton": "12.5",
            "realized_pnl_ton": "-4.2",
            "note": "note",
        }
    ),
    "paper": fmt.paper_card(
        {
            "trades": 4,
            "open": 1,
            "win_rate_pct": "75.00",
            "realized_pnl_ton": "18.5",
            "max_drawdown_ton": "5",
            "best_trade_ton": "12",
            "worst_trade_ton": "-3",
            "note": "simulated",
        }
    ),
    "settings": fmt.settings_card(User(telegram_id=1, notification_prefs={"whale": True}), "mainnet", False),
    "history": "{history} <b>HISTORY</b>",
}


def test_every_template_renders_without_error():
    for name, template in TEMPLATES.items():
        rendered = render(template)
        assert rendered.text, name
        assert "{" not in rendered.text, f"unresolved token in {name}"


def test_disclaimers_are_present():
    assert "guarantee" in fmt.radar_card({"opportunity_score": 10}).lower()
    assert "not financial advice" in fmt.analysis_card({}).lower()


def test_empty_data_templates_do_not_crash():
    assert render(fmt.radar_card({})).text
    assert render(fmt.analysis_card({})).text
    assert render(fmt.collection_card({})).text
