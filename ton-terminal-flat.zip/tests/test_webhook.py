"""Telegram webhook: secret verification and graceful degradation."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("DATABASE_URL", f"sqlite+aiosqlite:///{tmp_path/'wh.sqlite'}")
    monkeypatch.setenv("DEV_MODE", "true")
    monkeypatch.setenv("TELEGRAM_WEBHOOK_SECRET", "s3cr3t")
    from app.core.config import get_settings

    get_settings.cache_clear()
    import app.database.session as dbm

    dbm._engine = None
    dbm._sessionmaker = None
    from app.api.main import create_app

    with TestClient(create_app()) as test_client:
        yield test_client
    get_settings.cache_clear()
    dbm._engine = None
    dbm._sessionmaker = None


def test_webhook_rejects_wrong_secret(client):
    response = client.post(
        "/telegram/webhook",
        json={"update_id": 1},
        headers={"X-Telegram-Bot-Api-Secret-Token": "wrong"},
    )
    assert response.status_code == 401


def test_webhook_requires_a_bot_token(client):
    response = client.post(
        "/telegram/webhook",
        json={"update_id": 1},
        headers={"X-Telegram-Bot-Api-Secret-Token": "s3cr3t"},
    )
    # no TELEGRAM_BOT_TOKEN in the test environment -> honest 503
    assert response.status_code == 503


def test_webhook_info_is_protected(client):
    assert client.get("/telegram/webhook/info").status_code == 401
