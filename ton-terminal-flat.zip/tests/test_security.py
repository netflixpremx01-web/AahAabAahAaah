"""Security: Telegram initData validation and TON Connect proof verification."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from urllib.parse import urlencode

import pytest

from app.security.initdata import build_data_check_string, verify_signature


def _build_init_data(token: str, user: dict, age: int = 0) -> str:
    payload = {
        "query_id": "AAH",
        "user": json.dumps(user),
        "auth_date": str(int(time.time()) - age),
    }
    data_check_string = build_data_check_string(payload)
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    digest = hmac.new(secret, data_check_string.encode(), hashlib.sha256).hexdigest()
    return urlencode({**payload, "hash": digest})


def test_valid_init_data_is_accepted():
    token = "123456:AA-TEST-TOKEN"
    raw = _build_init_data(token, {"id": 7, "first_name": "Ada"})
    data = verify_signature(raw, token)
    assert data.telegram_id == 7
    assert data.display_name == "Ada"


def test_tampered_init_data_is_rejected():
    from urllib.parse import parse_qsl, urlencode

    from app.core.errors import AuthenticationError

    token = "123456:AA-TEST-TOKEN"
    raw = _build_init_data(token, {"id": 7})
    pairs = dict(parse_qsl(raw))
    user = json.loads(pairs["user"])
    user["id"] = 9
    pairs["user"] = json.dumps(user)  # signature no longer matches
    tampered = urlencode(pairs)
    with pytest.raises(AuthenticationError):
        verify_signature(tampered, token)


def test_wrong_token_is_rejected():
    from app.core.errors import AuthenticationError

    raw = _build_init_data("111:AAA", {"id": 7})
    with pytest.raises(AuthenticationError):
        verify_signature(raw, "222:BBB")


def test_stale_init_data_is_rejected():
    from app.core.errors import AuthenticationError

    token = "123456:AA-TEST-TOKEN"
    raw = _build_init_data(token, {"id": 7}, age=7200)
    with pytest.raises(AuthenticationError):
        verify_signature(raw, token)


def test_ton_proof_verification_round_trip():
    from nacl.signing import SigningKey

    from app.integrations.tonconnect.verify import (
        TonProof,
        WalletAuth,
        build_proof_message,
        verify_ton_proof,
    )

    signing_key = SigningKey.generate()
    verify_key = signing_key.verify_key
    public_hex = bytes(verify_key).hex()
    address = "0:" + hashlib.sha256(public_hex.encode()).hexdigest()

    timestamp = int(time.time())
    message = build_proof_message(address, "app.example.com", timestamp, "payload-1")
    signature = signing_key.sign(message).signature
    signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip("=")

    auth = WalletAuth(
        address=address,
        network="mainnet",
        public_key=public_hex,
        proof=TonProof(
            timestamp=timestamp,
            domain="app.example.com",
            signature=signature_b64,
            payload="payload-1",
        ),
    )
    assert verify_ton_proof(auth, expected_domain="app.example.com") is True


def test_ton_proof_rejects_wrong_domain_and_stale_payload():
    from nacl.signing import SigningKey

    from app.core.errors import AuthenticationError
    from app.integrations.tonconnect.verify import (
        TonProof,
        WalletAuth,
        build_proof_message,
        verify_ton_proof,
    )

    signing_key = SigningKey.generate()
    public_hex = bytes(signing_key.verify_key).hex()
    address = "0:" + hashlib.sha256(public_hex.encode()).hexdigest()
    timestamp = int(time.time())
    message = build_proof_message(address, "evil.example.com", timestamp, "p")
    signature = base64.urlsafe_b64encode(signing_key.sign(message).signature).decode().rstrip("=")
    auth = WalletAuth(
        address=address,
        network="mainnet",
        public_key=public_hex,
        proof=TonProof(
            timestamp=timestamp, domain="evil.example.com", signature=signature, payload="p"
        ),
    )
    with pytest.raises(AuthenticationError):
        verify_ton_proof(auth, expected_domain="app.example.com")

    stale = WalletAuth(
        address=address,
        network="mainnet",
        public_key=public_hex,
        proof=TonProof(
            timestamp=int(time.time()) - 10_000,
            domain="app.example.com",
            signature=signature,
            payload="p",
        ),
    )
    with pytest.raises(AuthenticationError):
        verify_ton_proof(stale, expected_domain="app.example.com")


def test_secret_redaction():
    from app.security.secrets import public_config, redact_mapping

    payload = {"api_key": "super-secret", "nested": {"token": "abc"}, "ok": 1}
    redacted = redact_mapping(payload)
    assert redacted["api_key"] == "***redacted***"
    assert redacted["nested"]["token"] == "***redacted***"
    assert redacted["ok"] == 1
    assert "toncenter_api_key" not in public_config()
