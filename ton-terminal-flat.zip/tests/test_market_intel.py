"""Collection health, anomaly detection, whale analytics and replay."""
from datetime import datetime, timedelta
from decimal import Decimal

from app.models.enums import Trend
from app.radar.anomaly import detect_anomalies
from app.radar.replay import replay_opportunity, replay_summary
from app.radar.stats import CollectionHealthInput, compute_collection_health, compute_trend
from app.radar.whale import analyse_whales


def test_health_and_trend():
    health = compute_collection_health(
        CollectionHealthInput(
            floor_now=Decimal("60"),
            floor_24h_ago=Decimal("59"),
            floor_7d_ago=Decimal("50"),
            volume_24h_ton=Decimal("200"),
            volume_7d_ton=Decimal("1400"),
            sales_7d=45,
            buyers_24h=12,
            sellers_24h=6,
            listings_count=100,
            collection_size=5000,
        )
    )
    assert health.score >= 70
    assert health.trend is Trend.BULLISH


def test_bearish_and_volatile_trends():
    # A >10% move inside 24h is classified volatile (it dominates direction).
    assert compute_trend(Decimal("40"), Decimal("45"), Decimal("60")) is Trend.VOLATILE
    # A steady 7d decline without intraday chaos is bearish.
    assert compute_trend(Decimal("40"), Decimal("41"), Decimal("60")) is Trend.BEARISH


def test_floor_crash_detection_has_evidence():
    now = datetime.utcnow()
    floors = [(now - timedelta(hours=i), Decimal(100 - i * 4)) for i in range(6)]
    anomalies = detect_anomalies(floor_series=floors, volume_series=[])
    crash = next(a for a in anomalies if a.kind == "floor_crash")
    assert "change_pct" in crash.evidence
    assert "%" in crash.message


def test_volume_spike_and_concentration():
    now = datetime.utcnow()
    volumes = [(now - timedelta(days=i), Decimal("10")) for i in range(6)][::-1]
    volumes.append((now, Decimal("500")))
    anomalies = detect_anomalies(
        floor_series=[],
        volume_series=volumes,
        listing_prices=[Decimal("50")] * 40,
        floor=Decimal("50"),
        collection_size=100,
    )
    kinds = {a.kind for a in anomalies}
    assert "volume_spike" in kinds
    assert "listing_concentration" in kinds


def test_whale_accumulation_signal():
    now = datetime.utcnow()
    sales = [
        {"buyer": "w1", "seller": f"s{i}", "price": Decimal("50"), "ts": now - timedelta(hours=i)}
        for i in range(12)
    ]
    report = analyse_whales(sales, collection="X", window_hours=72, now=now)
    assert report.signals[0].wallet == "w1"
    assert report.signals[0].net_items == 12
    assert report.accumulation["signal"] == "HIGH"
    assert "advice" in report.accumulation["note"]


def test_replay_computes_theoretical_and_actual():
    result = replay_opportunity(
        detection_price=Decimal("50"),
        horizon_hours=24,
        observed_price=Decimal("62"),
        projected_price=Decimal("70"),
        costs=Decimal("5"),
    )
    assert result.actual_result == Decimal("7")
    assert result.theoretical_result == Decimal("15")
    assert "not imply future results" in result.note


def test_replay_summary_aggregates():
    results = [
        replay_opportunity(detection_price=Decimal("50"), horizon_hours=24, observed_price=Decimal("60")),
        replay_opportunity(detection_price=Decimal("50"), horizon_hours=24, observed_price=Decimal("40")),
    ]
    summary = replay_summary(results)
    assert summary["samples"] == 2
    assert summary["positive"] == 1
    assert summary["best_ton"] == Decimal("10")
    assert summary["worst_ton"] == Decimal("-10")
