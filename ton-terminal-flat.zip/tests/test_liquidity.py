"""Liquidity engine."""
from decimal import Decimal

from app.models.enums import RiskLevel
from app.nft.liquidity import LiquidityInput, assess_liquidity, risk_from_score, spread_percentage


def test_healthy_collection_scores_high():
    result = assess_liquidity(
        LiquidityInput(
            sales_7d=40,
            sales_30d=150,
            active_listings=60,
            unique_buyers_7d=25,
            volume_7d_ton=Decimal("1500"),
            spread_pct=Decimal("5"),
            avg_holding_days=10,
        )
    )
    assert result.score >= 70
    assert result.risk is RiskLevel.LOW


def test_dead_collection_scores_zero():
    result = assess_liquidity(LiquidityInput())
    assert result.score < 25
    assert result.risk in {RiskLevel.HIGH, RiskLevel.EXTREME}
    assert any("No sales" in w for w in result.warnings)


def test_high_value_low_liquidity_warning():
    result = assess_liquidity(
        LiquidityInput(
            sales_7d=1,
            sales_30d=2,
            active_listings=40,
            unique_buyers_7d=1,
            volume_7d_ton=Decimal("30"),
            price_ton=Decimal("60"),
        )
    )
    assert any("HIGH VALUE + LOW LIQUIDITY" in w for w in result.warnings)


def test_risk_thresholds():
    assert risk_from_score(80) is RiskLevel.LOW
    assert risk_from_score(50) is RiskLevel.MEDIUM
    assert risk_from_score(30) is RiskLevel.HIGH
    assert risk_from_score(5) is RiskLevel.EXTREME


def test_spread():
    assert spread_percentage(Decimal("110"), Decimal("100")) == Decimal("10")
    assert spread_percentage(None, Decimal("1")) is None
