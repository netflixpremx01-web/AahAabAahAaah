"""Shared pytest fixtures: temporary SQLite database and mocked providers."""
from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/test.db")
os.environ.setdefault("DEV_MODE", "true")
os.environ.setdefault("TELEGRAM_BOT_TOKEN", "")

import asyncio  # noqa: E402
from collections.abc import AsyncIterator  # noqa: E402

import pytest  # noqa: E402
import pytest_asyncio  # noqa: E402
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine  # noqa: E402

import app.models.orm  # noqa: F401,E402
from app.database.base import Base  # noqa: E402

Path("./data").mkdir(exist_ok=True)


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def session(tmp_path) -> AsyncIterator[AsyncSession]:

    db_path = tmp_path / "test.sqlite"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_path}")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    maker = async_sessionmaker(bind=engine, expire_on_commit=False)
    async with maker() as db:
        yield db
    await engine.dispose()


@pytest.fixture
def fake_user(session):
    from app.models.orm import User

    user = User(
        telegram_id=42,
        username="tester",
        first_name="Test",
        paper_balance_ton=100,
        notification_prefs={},
        ui_prefs={},
    )
    return user
