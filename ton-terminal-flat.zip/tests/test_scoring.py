"""Opportunity scoring, costs and risk."""
from decimal import Decimal

from app.models.enums import RiskLevel
from app.radar.scoring import (
    compute_costs,
    compute_opportunity_score,
    evaluate_risk,
    theoretical_upside,
)


def test_cost_model_round_trip():
    costs = compute_costs(Decimal("50"), marketplace_fee_bps=500, royalty_bps=500, network_fee_ton=Decimal("0.05"))
    assert Decimal(costs["marketplace_fee"]) == Decimal("2.5")
    assert Decimal(costs["royalty"]) == Decimal("2.5")
    assert Decimal(costs["total_outflow"]) == Decimal("50.05")
    assert Decimal(costs["total_costs"]) == Decimal("5.05")


def test_score_components_explained():
    score = compute_opportunity_score(
        discount=Decimal("46.8"),
        rarity_score=94,
        number_score=98,
        liquidity_score=83,
        confidence=88,
        roi_pct=Decimal("72"),
        price_ton=Decimal("50"),
        floor=Decimal("60"),
    )
    assert 80 <= score.score <= 100
    assert score.components["discount"] == 30
    assert score.components["rarity"] == 19
    assert any("46.8" in reason for reason in score.reasons)


def test_no_discount_scores_low():
    score = compute_opportunity_score(
        discount=Decimal("0"),
        rarity_score=10,
        number_score=0,
        liquidity_score=20,
        confidence=30,
        roi_pct=Decimal("0"),
        price_ton=Decimal("100"),
        floor=Decimal("50"),
    )
    assert score.score < 20


def test_risk_classification():
    assert evaluate_risk(liquidity_score=80, confidence=90, price_ton=Decimal("60"), floor=Decimal("50")) is RiskLevel.LOW
    assert evaluate_risk(liquidity_score=10, confidence=20, price_ton=Decimal("500"), floor=Decimal("50")) is RiskLevel.EXTREME


def test_theoretical_upside_nets_costs():
    costs = compute_costs(Decimal("50"))
    upside = theoretical_upside(Decimal("50"), Decimal("94"), costs)
    assert Decimal(upside["gross"]) == Decimal("44")
    assert Decimal(upside["roi_pct"]) > 0
    assert Decimal(upside["break_even_price"]) > Decimal("50")
