"""Rare number engine: detection, patterns and data-driven premiums."""
from decimal import Decimal

from app.nft.numbers import (
    classify,
    collector_score,
    derive_premium,
    is_palindrome,
    is_repeating,
    is_sequential,
    matches_pattern,
)


def test_special_numbers_detected():
    for value in (0, 1, 7, 69, 100, 111, 420, 777, 888):
        profile = classify(value)
        assert "special" in profile.flags, value
        assert profile.is_rare


def test_structural_patterns():
    assert is_palindrome(12321)
    assert is_repeating(7777)
    assert is_sequential(1234)
    assert not is_palindrome(1234)
    assert classify(12321).flags == ["palindrome"]
    assert classify(0).base_score >= 60


def test_common_number_is_not_rare():
    profile = classify(4731)
    assert not profile.is_rare
    assert collector_score(4731) == 0


def test_pattern_matching():
    assert matches_pattern(169, ["*69"])
    assert matches_pattern(7771, ["777*"])
    assert matches_pattern(99, ["<100"])
    assert matches_pattern(12321, ["palindrome"])
    assert not matches_pattern(1234, ["palindrome"])


def test_premium_requires_enough_comparables():
    rare_sales = [Decimal("90")] * 3
    baseline = [Decimal("50")] * 3
    premium, source, count = derive_premium(420, rare_sales=rare_sales, baseline_sales=baseline)
    assert premium is None and source == "insufficient-data"


def test_premium_derived_from_sales():
    rare_sales = [Decimal("90"), Decimal("100"), Decimal("110"), Decimal("95")]
    baseline = [Decimal("50"), Decimal("48"), Decimal("52"), Decimal("51")]
    premium, source, count = derive_premium(
        420, rare_sales=rare_sales, baseline_sales=baseline, min_comparables=4
    )
    assert source == "comparable-sales"
    assert Decimal("1.5") < premium < Decimal("2.5")
    assert count == 4


def test_non_rare_number_has_no_premium():
    premium, source, _ = derive_premium(4731, rare_sales=[Decimal("9")] * 10, baseline_sales=[Decimal("5")] * 10)
    assert premium is None and source == "not-rare"
