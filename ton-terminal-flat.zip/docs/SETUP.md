# Setup guide (local → production)

## 0. Requirements
* Python **3.11+**
* Node **20+** (only if you rebuild the Mini App)
* Optional: PostgreSQL 16, Redis 7 (SQLite + in-memory cache work fine for dev)

---

## 1. Local run (5 minutes)

```bash
cd ton-nft-terminal
python -m venv .venv && source .venv/bin/activate
python -m pip install -e ".[dev]"      # backend
cp .env.example .env                   # then edit (see §2)
python -m uvicorn app.api.main:app --host 0.0.0.0 --port 8000
```

* Mini App (served by the backend): **http://localhost:8000/**
* API docs: **http://localhost:8000/docs**
* Health: **http://localhost:8000/api/health**

Already built Mini App? `miniapp/dist` is served automatically; rebuild with:

```bash
cd miniapp && npm install && npm run build
```

---

## 2. `.env` — minimum viable configuration

```env
DEV_MODE=true                 # lets the Mini App open in a normal browser
TELEGRAM_BOT_TOKEN=           # from @BotFather (needed for the bot + webhook)
TON_NETWORK=testnet           # testnet | mainnet
TONCENTER_API_KEY=            # optional: lifts the 1 rps anonymous limit
TON_APP_URL=                  # public HTTPS URL of the Mini App (TON Connect)

DATABASE_URL=sqlite+aiosqlite:///./data/terminal.db
REDIS_URL=                    # empty = in-process cache

ENABLE_REAL_TRADING=false     # keep false until you are ready
ENABLE_PAPER_TRADING=true
```

Apply the schema (either way works):

```bash
python -m alembic upgrade head        # migrations (recommended)
# or let the app create it on boot    (SQLite/local dev)
```

> `DEV_MODE` must be **false** in production — otherwise Telegram `initData` auth is relaxed.

---

## 3. Telegram bot

1. [@BotFather](https://t.me/BotFather) → `/newbot` → copy the token → `.env`.
2. Commands are auto-registered at startup (or set them manually from the list in
   `docs/BOT_SETUP.md`).
3. Run it:
   * **Polling (local/dev):** `python -m app.bot.main`
   * **Webhook (prod):** set `TELEGRAM_WEBHOOK_URL=https://your-domain/telegram/webhook`
     and `TELEGRAM_WEBHOOK_SECRET=…`, then:

```bash
curl -X POST https://your-domain/telegram/webhook/setup \
     -H "X-Telegram-Bot-Api-Secret-Token: YOUR_SECRET"
curl https://your-domain/telegram/webhook/info -H "X-Telegram-Bot-Api-Secret-Token: YOUR_SECRET"
```

---

## 4. Mini App + TON Connect inside Telegram

Telegram only loads **HTTPS** URLs, so for local testing use a tunnel:

```bash
ngrok http 8000            # or: cloudflared tunnel --url http://localhost:8000
```

Then, with the resulting `https://xxxx.ngrok-free.app`:

```env
TON_APP_URL=https://xxxx.ngrok-free.app
```

* BotFather → `/newapp` (or *Edit Bot → Menu Button*) → paste the same URL.
* TON Connect manifest is served at `/tonconnect-manifest.json`; keep
  `miniapp/public/tonconnect-manifest.json` (`url`, `iconUrl`, `termsOfUseUrl`,
  `privacyPolicyUrl`) in sync with your domain.
* Never expose an API key to the Mini App — the backend only returns `public_config()`.

---

## 5. Load real data

```bash
# index + score a collection (mainnet example)
TON_NETWORK=mainnet python scripts/scan_collection.py 0:COLLECTION… --items 50 --limit 25

# let the background scanner keep watching it
python scripts/set_monitor.py 0:COLLECTION…
python scripts/set_monitor.py --list
```

Then enable workers in `.env`:

```env
SCANNER_ENABLED=true
SCANNER_INTERVAL_SECONDS=300
PORTFOLIO_SYNC_INTERVAL_SECONDS=600
OPPORTUNITY_REPLAY_ENABLED=true
```

---

## 6. Production (Docker)

```bash
cp .env.example .env      # fill: TON_APP_URL, TELEGRAM_BOT_TOKEN, DEV_MODE=false, …
docker compose up --build
```

* `api` → FastAPI + Mini App on `:8000`
* `bot` → polling (switch its command to webhook mode if you prefer)
* `postgres` (`:5432`) and `redis` (`:6379`)
* Production DB URL: `postgresql+asyncpg://terminal:terminal@postgres:5432/terminal`

Behind a reverse proxy, forward `https://your-domain/telegram/webhook`
to `api:8000/telegram/webhook` **including** the `X-Telegram-Bot-Api-Secret-Token` header.

---

## 7. Going live with real money

1. `TON_NETWORK=mainnet`, `DEV_MODE=false`
2. `TONCENTER_API_KEY=…` (otherwise 1 rps and frequent HTTP 429)
3. `ENABLE_REAL_TRADING=true` — **only after** testing in Paper Mode
4. Keep `MAX_BUY_PRICE_TON`, `DEFAULT_SLIPPAGE`, `MAX_SLIPPAGE` sane
5. Portals: no public API exists — supply `PORTALS_API_BASE_URL` + `MARKETPLACE_API_KEY` +
   `PORTALS_ENDPOINT_MAP` to activate buy/sell; until then the UI says “execution unavailable”
   instead of faking a transaction.

---

## 8. Verify / troubleshoot

```bash
python -m pytest -q            # 72 tests
python -m ruff check app tests
curl localhost:8000/api/providers     # live capability matrix per provider
curl localhost:8000/api/config        # public config (no secrets)
```

| Symptom | Cause / fix |
|---|---|
| `429` from TON Center | anonymous rate limit → add `TONCENTER_API_KEY` |
| Mini App stuck on `/auth/me` 401 | `DEV_MODE=false` without valid `initData`; open inside Telegram or set a tunnel URL |
| TON Connect “manifest not found” | `TON_APP_URL` / manifest URLs not HTTPS or not reachable |
| No opportunities | scan a collection first (`scripts/scan_collection.py`) |
| Swap quotes slow | live provider call (~5 s); quotes are cached, not hardcoded |
| Bot not responding | token missing (bot exits with a clear message) or webhook URL not set |
