# Mini App hosting — poora process (shuru se live tak)

## 0. Mini App hoti kya hai?

`miniapp/` ek React + TypeScript + Vite app hai. `npm run build` usse **static files**
(`miniapp/dist/index.html`, `assets/*.js|css`) bana deta hai. Telegram sirf ek **HTTPS URL**
kholta hai — bas itna.

Do tareeke hain:

| Mode | Kahan host | Kab chuno |
|---|---|---|
| **A. Same server (recommended)** | FastAPI hi `miniapp/dist` serve karta hai (`/` aur `/app`) | Simple, CORS-free, ek domain |
| **B. Split hosting** | Mini App → Vercel/Netlify/Cloudflare Pages · API → apna server | Static host fast + CDN, par CORS aur `VITE_API_URL` set karna padta hai |

---

## Mode A — same server (sabse aasan) ✅

### Step 1 — domain + server ready
1. VPS (Ubuntu 24.04) banao, domain ka **A record** server IP par point karo.
2. `ssh root@IP` → Docker install: `curl -fsSL https://get.docker.com | sh`
3. Caddy install (free auto HTTPS), `/etc/caddy/Caddyfile`:

```
terminal.aapka-domain.com {
    reverse_proxy localhost:8000
}
```

### Step 2 — code + env
```bash
git clone <repo> ton-nft-terminal && cd ton-nft-terminal
cp .env.example .env && nano .env
```

```env
DEV_MODE=false
TON_APP_URL=https://terminal.aapka-domain.com
TELEGRAM_BOT_TOKEN=123456:AAF…
TELEGRAM_WEBHOOK_URL=https://terminal.aapka-domain.com/telegram/webhook
TELEGRAM_WEBHOOK_SECRET=<openssl rand -hex 32>
TON_NETWORK=mainnet
TONCENTER_API_KEY=…
DATABASE_URL=postgresql+asyncpg://terminal:terminal@postgres:5432/terminal
REDIS_URL=redis://redis:6379/0
ENABLE_REAL_TRADING=false
```

### Step 3 — Mini App build (server par hi)
```bash
cd miniapp && npm install && npm run build && cd ..
# ya:  make install-miniapp && make build-miniapp
```
Ye `miniapp/dist` banata hai — FastAPI usse automatically serve karta hai.

### Step 4 — stack chalao
```bash
docker compose up --build -d
curl https://terminal.aapka-domain.com/api/health     # {"status":"ok"}
curl -I https://terminal.aapka-domain.com/            # 200 (Mini App HTML)
```

### Step 5 — BotFather
```
/newbot          → token (.env me dala)
/newapp          → URL: https://terminal.aapka-domain.com
/setcommands     → 14 commands (docs/BOT_SETUP.md se copy)
```
Telegram me bot kholo → `/start` → **“🚀 Open Trading Terminal”**.

✅ Ho gaya.

---

## Mode B — split hosting (Mini App alag, API alag)

### Step 1 — API host karo (VPS/Docker, upar Mode A Step 1–2 jaisa) par domain alag:
`https://api.aapka-domain.com` → reverse proxy → `localhost:8000`

### Step 2 — Mini App ko API ka pata batao
```bash
cd miniapp
cp .env.example .env
echo "VITE_API_URL=https://api.aapka-domain.com/api" >> .env
npm install && npm run build
# ya:  make build-miniapp-split API=https://api.aapka-domain.com/api
```

### Step 3 — `dist/` static host par daalo
```bash
# Vercel
npx vercel deploy dist --prod
# Netlify
npx netlify deploy --dir=dist --prod
# Cloudflare Pages
npx wrangler pages deploy dist --project-name=ton-nft-terminal
```
Mila: `https://ton-nft-terminal.vercel.app`

### Step 4 — CORS allow karo (API side)
`.env` me:
```env
TON_APP_URL=https://ton-nft-terminal.vercel.app
```
Backend non-dev mode me sirf isi origin ko allow karta hai (secrets kabhi expose nahi hote).

### Step 5 — BotFather
`/newapp` → URL: **static host wala URL** (`https://ton-nft-terminal.vercel.app`)

---

## TON Connect manifest (dono modes me)

Bot/wallet manifest mangta hai → **API serve karta hai**: `https://api…/tonconnect-manifest.json`.
Static URLs apne domain se update karo:

`miniapp/public/tonconnect-manifest.json`
```json
{
  "url": "https://terminal.aapka-domain.com",
  "name": "TON NFT Trading Terminal",
  "iconUrl": "https://terminal.aapka-domain.com/icons/icon-180.png",
  "termsOfUseUrl": "https://terminal.aapka-domain.com/terms.html",
  "privacyPolicyUrl": "https://terminal.aapka-domain.com/privacy.html"
}
```
Build ke baad `dist/` me copy ho jayega. Check:
```bash
curl https://api.aapka-domain.com/tonconnect-manifest.json
```

---

## Updates kaise daalein (redeploy)

**Mode A:**
```bash
cd ton-nft-terminal && git pull
make build-miniapp                 # ya: cd miniapp && npm run build
docker compose up --build -d
docker compose exec api python -m alembic upgrade head
```

**Mode B:**
```bash
cd miniapp && npm run build && npx vercel deploy dist --prod
# API badla ho toh:  docker compose up --build -d api
```

> Telegram Mini App **cache** karta hai — naya build dikh na rahe ho toh URL me `?v=2` add karke
> ek baar kholo, ya BotFather me URL update karke dobara `/start`.

---

## Rebuild jaruri kab hai?

| Change | Rebuild? |
|---|---|
| Python/backend code | `docker compose up --build -d` |
| `miniapp/src/**` | `npm run build` (+ redeploy) |
| `.env` | service restart (`docker compose restart api bot`) |
| `miniapp/public/**` (manifest, icons, terms) | `npm run build` |

---

## Final checklist

```bash
curl https://terminal.aapka-domain.com/api/health                 # ok
curl https://terminal.aapka-domain.com/tonconnect-manifest.json   # JSON with your domain
curl https://terminal.aapka-domain.com/api/config                 # no secrets in response
curl https://terminal.aapka-domain.com/api/providers              # capability matrix
```

Telegram me:
1. `/start` → Mini App khule
2. **Connect wallet** → wallet approve → address dikhe
3. `/scan <collection>` → real data
4. Swap quote → live STON.fi rate

---

## Common problems

| Problem | Fix |
|---|---|
| Mini App blank / 401 | `DEV_MODE=false` + Telegram ke andar kholo; `VITE_API_URL` sahi hai? |
| API calls fail (CORS) | `TON_APP_URL` static host ka URL set karo |
| “manifest not reachable” | manifest URLs HTTPS + reachable hone chahiye |
| Purana UI dikh raha | cache: URL me `?v=N`, ya BotFather URL refresh |
| Wallet connect nahi ho raha | domain HTTPS hona chahiye; manifest icon 180×180 PNG |
| API 429 | `TONCENTER_API_KEY` daalo |
