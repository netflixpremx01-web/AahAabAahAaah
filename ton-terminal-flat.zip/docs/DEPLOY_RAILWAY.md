# Railway par deploy — step by step

## Step 1 — GitHub par repo daalo
```bash
cd ton-nft-terminal
git init && git add . && git commit -m "TON NFT Trading Terminal"
# GitHub par empty repo banao, phir:
git remote add origin https://github.com/<you>/ton-nft-terminal.git
git push -u origin main
```
(CLI se bhi ho sakta hai: `npm i -g @railway/cli` → `railway login` → `railway up`)

## Step 2 — Railway project
1. https://railway.app → **Login with GitHub**
2. **New Project → Deploy from GitHub repo** → apna repo chuno
3. Railway `Dockerfile` pehchan lega (repo me `railway.json` hai: builder **DOCKERFILE**, healthcheck `/api/health`)

## Step 3 — Postgres add karo (pehle ye)
Project me **+ New → Database → Add PostgreSQL**
- Banne ke baad us service ke **Variables** me `DATABASE_URL` dikhega
- API service me isko reference karo: `${{Postgres.DATABASE_URL}}`
- App khud `postgresql://` ko `postgresql+asyncpg://` bana deta hai — aapko kuch nahi karna

## Step 4 — Redis add karo (optional par recommended)
**+ New → Database → Add Redis** → variable: `REDIS_URL=${{Redis.REDIS_URL}}`
(Nahi diya toh app in-process cache use karta hai — chalega, par multi-instance me slow)

## Step 5 — API service ke Variables (yahi sab kuch hai)
API service kholo → **Variables → Raw Editor** me ye paste karo:

```env
DEV_MODE=false
ENV=production
LOG_LEVEL=INFO

TELEGRAM_BOT_TOKEN=123456:AAF_your_token
TON_APP_URL=${{RAILWAY_PUBLIC_DOMAIN}}
TON_NETWORK=mainnet
TONCENTER_API_KEY=
TON_API_KEY=

DATABASE_URL=${{Postgres.DATABASE_URL}}
REDIS_URL=${{Redis.REDIS_URL}}

ENABLE_REAL_TRADING=false
ENABLE_PAPER_TRADING=true
MAX_BUY_PRICE_TON=1000
DEFAULT_SLIPPAGE=0.01
MAX_SLIPPAGE=0.05

SCANNER_ENABLED=true
SCANNER_INTERVAL_SECONDS=300
PORTFOLIO_SYNC_INTERVAL_SECONDS=600
OPPORTUNITY_REPLAY_ENABLED=true
```

> `${{RAILWAY_PUBLIC_DOMAIN}}` deploy ke baad Railway apna HTTPS domain dega
> (jaise `ton-nft-terminal.up.railway.app`) — `TON_APP_URL` me wahi chahiye.
> Chahein toh **Settings → Networking → Generate Domain** karke fixed domain lo,
> phir `TON_APP_URL=https://<wo-domain>` likh do (recommended).

**Kabhi mat daalna:** seed phrase, private key, wallet password.
Mini App ko sirf public config milti hai (`/api/config` me koi secret nahi hota).

## Step 6 — Bot service (alag service)
1. **+ New → GitHub Repo** (same repo) → ye doosri service banegi
2. Us service ke **Settings → Deploy → Start Command**:
   ```
   python -m app.bot.main
   ```
3. Variables: **same list** as above (kam se kam `TELEGRAM_BOT_TOKEN` + `DATABASE_URL` + `TON_NETWORK`)
4. Bot **polling** mode me chalega — webhook ki jarurat nahi

> Ek hi token se polling aur webhook dono mat chalana — bot confuse ho jata hai.

## Step 7 — Mini App
Build pehle se repo me hai (`miniapp/dist`), aur FastAPI use serve karta hai.
Agar `miniapp/src` me change kiya ho:
```bash
cd miniapp && npm install && npm run build
git add miniapp/dist && git commit -m "rebuild mini app" && git push
```
Railway auto-redeploy kar dega.

## Step 8 — BotFather
```
/newbot       → token (Step 5 me dala)
/newapp       → URL: https://<railway-domain>     (HTTPS, Railway deta hai)
/setcommands  → commands list (docs/BOT_SETUP.md)
```
Aur `miniapp/public/tonconnect-manifest.json` me apna Railway domain 4 jagah
(`url`, `iconUrl`, `termsOfUseUrl`, `privacyPolicyUrl`) → rebuild + push.

## Step 9 — Verify
```bash
curl https://<railway-domain>/api/health            # {"status":"ok",...}
curl https://<railway-domain>/api/config            # koi secret nahi
curl https://<railway-domain>/tonconnect-manifest.json
curl https://<railway-domain>/api/providers
```
Telegram: `/start` → **Open Terminal** → wallet connect → `/scan <collection>`

## Step 10 — Data load karo
Railway CLI se (ek baar):
```bash
railway run python scripts/scan_collection.py 0:COLLECTION… --items 50 --limit 25
railway run python scripts/set_monitor.py 0:COLLECTION…
```
Ya Mini App ke **Market** tab me collection address daal ke **Sync + load** dabao.

---

## Common issues

| Problem | Fix |
|---|---|
| `InvalidPasswordError` / DB connect fail | `DATABASE_URL` reference galat → Step 3 dekho |
| App boot nahi hua | Logs dekho; `PORT` ab auto hai, par `DATABASE_URL` jaruri hai |
| Bot reply nahi | bot service ka Start Command `python -m app.bot.main` hai? |
| Mini App 401 | `DEV_MODE=false` + Telegram ke andar kholo |
| API 429 | `TONCENTER_API_KEY` daalo (@toncenter bot se free) |
| Purana UI | `miniapp/dist` rebuild + push |

## Cost
Hobby plan ~$5/mo (Postgres + Redis + 2 services) — Mini App + bot + API sab included.
