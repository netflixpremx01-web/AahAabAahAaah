# Provider notes (verified against live APIs)

Everything below was checked against the **current official documentation and the live API** while
this project was built. No endpoint is invented; when a capability does not exist the adapter says so
(`CapabilityNotSupported` / `ProviderUnavailable`) instead of returning invented data.

## 1. TON Center API v3 — indexer

* Docs: https://docs.ton.org/api/v3/overview
* Bases: `https://toncenter.com/api/v3` (mainnet), `https://testnet.toncenter.com/api/v3` (testnet)
* Auth: `X-API-Key` header (server-side only). Anonymous access is limited to **1 request/second**.
* Verified endpoints: `/masterchainInfo`, `/accountStates`, `/walletStates`, `/addressBook`,
  `/metadata`, `/transactions`, `/messages`, `/actions`, `/nft/collections`, `/nft/items`,
  `/nft/transfers`, `/nft/sales`, `/jetton/masters`, `/jetton/wallets`, `/jetton/transfers`.

### Behaviours found while testing

| Finding | Handling |
|---|---|
| `GET /actions?action_type=nft_purchase` returns decoded **sales**: `price` (nanoTON), `nft_item`, `nft_collection`, `old_owner` (seller), `new_owner` (buyer), `marketplace_address`, `payout_amount` | Used as the primary sales-history source (see `MarketService.sync_sales`) |
| Adding `start_utime` / `end_utime` to that query regularly returns **HTTP 500 "timeout: context deadline exceeded"** | Time windows are applied **client-side** while paging with `offset` only (`TonCenterClient.get_nft_purchases`) |
| `GET /nft/sales` requires a **sale/auction contract address** (not a collection) | Not used for collection scans |
| Collections may return `next_item_index = 0` (unknown size) | Treated as *unknown*, never as "0 items" |
| Some collections (Fragment usernames) use **256-bit item indexes** | Indexes that are not plausible collector numbers are ignored (they would overflow a 64-bit column) |
| Anonymous usage returns **HTTP 429** under load | `HttpClient` retries with exponential backoff + jitter; `RateLimiter` throttles to 1 rps |

Request an API key from [@toncenter](https://t.me/toncenter) for production use.

## 2. STON.fi — DEX

* Docs: https://docs.ston.fi/developer-section/dex/api/reference · Base: `https://api.ston.fi`
* Verified: `GET /v1/assets/{address}`, `GET /v1/pools/by_market/{a0}/{a1}`,
  `POST /v1/swap/simulate` (v1.168.0).

| Finding | Handling |
|---|---|
| **`POST /v1/swap/simulate` takes its parameters in the QUERY STRING** — a JSON body fails with `Failed to deserialize query string: missing field offer_address` | Query params (`offer_address`, `ask_address`, `units`, `slippage_tolerance`, `dex_v2`, `referral_address`) |
| Response fields: `ask_units`, `min_ask_units`, `swap_rate`, `price_impact`, `fee_percent`, `gas_params{forward_gas, estimated_gas_consumption}`, `pool_address`, `router_address` | Parsed into `SwapQuote` (rate, min received, price impact, fees, route) |
| Native TON is the pseudo-address `EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c` (9 decimals); USDT is `EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs` (6 decimals) | `app/core/constants.py` |
| Building the actual swap message requires `@ston-fi/sdk` / Omniston | The adapter exposes every SDK parameter via `build_sdk_params()` and never fabricates a BOC |

Live check performed: `10 TON → 13.635837 USDT`, rate `1.3635837`, price impact `0.000005319`,
network fee `0.045 TON`; reverse `50 USDT → 36.501654 TON`.

## 3. DeDust — DEX

* Docs: https://docs.dedust.io/reference/getting-available-pools · Base: `https://api.dedust.io/v2`
* Verified: `GET /v2/pools` (≈52,300 pools, **≈25 MB response**), `GET /v2/pools/{address}/trades`.

| Finding | Handling |
|---|---|
| **No REST quote endpoint exists** | Quotes are computed locally from public reserves (constant product + `tradeFee`) and flagged `estimate_only=True`, with a note shown in the UI |
| `/v2/pools` is huge | Cached for 900 s (Redis/DB), never fetched per request |
| Assets are identified **by address**, not symbol | Symbols are rejected early (avoids the 25 MB download) |
| Execution requires `@dedust/sdk` | `build_transaction=False` → `CapabilityNotSupported` |

## 4. TonAPI — read-only NFT data

* Docs: https://docs.tonconsole.com/tonapi · Base: `https://tonapi.io/v2`
* Verified (works without a key, 1 req/4 s): `/v2/nfts/{id}`, `/v2/nfts/collections/{id}`,
  `/v2/nfts/collections/{id}/items`, `/v2/accounts/{id}/nfts`.
* Addresses are in raw `0:hex` form. An API token raises the rate limit — optional.
* Used for collection items + active listings (includes `sale` objects). No collection-wide sales
  history endpoint exists, which is why TON Center's `nft_purchase` actions are used for sales.

## 5. Portals — marketplace

* Site: https://portals.to
* **No official public API documentation exists.** Only unofficial, reverse-engineered clients
  (`portalsmp` and similar) could be found; using them (or scraping/bypassing auth) would violate the
  project's "never bypass auth or anti-bot protections" rule.
* Therefore `PortalsAdapter` ships the **full interface**, reports `status="unavailable"` and raises
  `ProviderUnavailable` for every method. Provide
  `PORTALS_API_BASE_URL` + `MARKETPLACE_API_KEY` + `PORTALS_ENDPOINT_MAP` (JSON endpoint map) to
  activate it — no other code changes are required.

## 6. TON Connect

* Docs: https://docs.ton.org/applications/ton-connect/get-started
* The backend serves `/tonconnect-manifest.json`, verifies `ton_proof` (ed25519 via PyNaCl:
  `ton-proof-item-v2/` + domain + timestamp + payload), and re-reads transactions from the chain
  after broadcast before marking them confirmed.
* Only the **public** address / public key is stored. Seed phrases and private keys are never
  requested.
