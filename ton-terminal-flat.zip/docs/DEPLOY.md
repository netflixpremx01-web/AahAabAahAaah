# Deployment runbook — kahan, kaise, kya bharna hai

## 1. Kya kahan chalta hai (big picture)

```
Telegram (user)
   │
   ├── Bot  ──────────►  aapka server (bot process)         ← TELEGRAM_BOT_TOKEN
   │                       polling  (simple)  ya  webhook   ← /telegram/webhook
   │
   └── Mini App ──────►  aapka server (FastAPI, port 8000)  ← TON_APP_URL (HTTPS)
                            │
                            ├── PostgreSQL   (permanent data)
                            ├── Redis        (cache / rate limit)
                            └── Providers: TON Center, STON.fi, DeDust, TonAPI
                                            (keys server-side, kabhi client par nahi)
```

**Ek hi server** (ya Railway/Render jaisa PaaS) sab kuch chala deta hai: API + Mini App + bot.
Database aur Redis usi machine par Docker se chal sakte hain (chhote projects ke liye theek).

---

## 2. Hosting options (apne hisaab se chuno)

| Option | Cost | Difficulty | Kab use karein |
|---|---|---|---|
| **Local + ngrok** (test) | free | ⭐ | Telegram ke andar Mini App test karna (Telegram ko HTTPS chahiye) |
| **Railway / Render / Fly.io** | ~$5–10/mo | ⭐⭐ | Sabse aasan — git push, env vars dashboard par, HTTPS built-in |
| **VPS (Hetzner/DigitalOcean)** + Docker + Caddy | ~$4–6/mo | ⭐⭐⭐ | Full control, sasta, production-grade |

Niche **VPS + Docker + Caddy** wala tareeka hai (sabse solid). PaaS ke liye §5 dekho.

---

## 3. VPS setup (Ubuntu 24.04) — copy-paste

### 3.1 Server + domain

1. VPS banao (Hetzner CX22 / DO Droplet, **Ubuntu 24.04**, ~2 GB RAM).
2. Domain (Cloudflare/Namecheap) → DNS me **A record**: `terminal` (ya `@`) → **server ka IP**.
   Cloudflare use kar rahe ho toh proxy **DNS only** (grey cloud) rakho pehle, SSL baad me.
3. Server me login: `ssh root@YOUR_IP`

### 3.2 Install Docker

```bash
apt update && apt upgrade -y
curl -fsSL https://get.docker.com | sh
apt install -y git
```

### 3.3 Code le aao

```bash
git clone <your-repo> ton-nft-terminal && cd ton-nft-terminal
# ya zip upload karke:  unzip ton-nft-terminal.zip && cd ton-nft-terminal
```

### 3.4 `.env` bharo (§4 dekho)

```bash
cp .env.example .env
nano .env
```

### 3.5 Stack chalao

```bash
docker compose up --build -d
docker compose logs -f api
curl localhost:8000/api/health      # {"status":"ok",...}
```

### 3.6 HTTPS (Caddy — auto SSL, free)

```bash
apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
apt update && apt install -y caddy
```

`/etc/caddy/Caddyfile`:

```
terminal.aapka-domain.com {
    reverse_proxy localhost:8000
}
```

```bash
systemctl reload caddy
```

Ab **https://terminal.aapka-domain.com** live hai (certificate automatic).

---

## 4. Kya-kya bharna hai (fill-in map)

| Variable | Kya dalna hai | Kahan se milega |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | `123456789:AAF…` | **@BotFather** → `/newbot` |
| `TON_APP_URL` | `https://terminal.aapka-domain.com` | apna domain (Telegram **HTTPS only**) |
| `TELEGRAM_WEBHOOK_URL` | `https://terminal.aapka-domain.com/telegram/webhook` | domain + path |
| `TELEGRAM_WEBHOOK_SECRET` | koi bhi lamba random string | `openssl rand -hex 32` |
| `TON_NETWORK` | `testnet` pehle, baad me `mainnet` | — |
| `TONCENTER_API_KEY` | API key | Telegram par **@toncenter** bot (`/apikey`) — warna 1 req/sec + 429 |
| `TON_API_KEY` | optional | https://tonconsole.com (TonAPI) |
| `DATABASE_URL` | `postgresql+asyncpg://terminal:terminal@postgres:5432/terminal` | docker-compose default |
| `REDIS_URL` | `redis://redis:6379/0` | docker-compose default |
| `DEV_MODE` | `false` (**production me jaruri**) | — |
| `ENABLE_REAL_TRADING` | `false` jab tak test na ho jaye | — |
| `ENABLE_PAPER_TRADING` | `true` | — |
| `SCANNER_ENABLED` | `true` (auto radar) | — |
| `SCANNER_INTERVAL_SECONDS` | `300` | — |
| `MARKETPLACE_API_KEY`, `PORTALS_API_BASE_URL`, `PORTALS_ENDPOINT_MAP` | khali chhodo jab tak official access na mile | — |

**Kabhi mat bharna / kabhi mat bhejna:** seed phrase, private key, wallet password.
Mini App ko sirf public config milti hai.

---

## 5. PaaS (Railway / Render) par

1. Repo connect karo → **service: Docker** chuno (repo me `Dockerfile` hai).
2. **Postgres** aur **Redis** plugin/addon add karo, unka URL `.env` me daalo
   (Railway: `${{Postgres.DATABASE_URL}}`).
3. Env vars (§4) service ke Variables tab me daalo — `PORT=8000`.
4. Deploy ke baad mila domain (`https://xxx.up.railway.app`) → `TON_APP_URL` me daalo.
5. Bot ko alag service me `command: python -m app.bot.main` ke saath chalao (polling — sabse simple).

> Polling chal raha hai toh webhook set karne ki jarurat nahi. Dono ek saath mat chalana.

---

## 6. BotFather me kya karna hai

```
/newbot                → naam + username → TOKEN milega
/setcommands           → niche ki list paste karo
/newapp   (ya Edit Bot → Menu Button) → URL: https://terminal.aapka-domain.com
/setdescription        → optional
```

Commands list:

```
start - Welcome & Mini App
help - All commands
wallet - Connect wallet & balances
radar - Live NFT opportunities
scan - Scan a collection
analyze - Full NFT analysis
buy - Prepare a purchase
sell - Prepare a listing
swap - Quote a TON/USDT swap
portfolio - Holdings & P/L
watchlist - Price & discount alerts
strategy - Strategy builder
history - Trades & transactions
settings - Notifications & risk
```

### Mini App ke static URLs (domain ke hisaab se update karo)

`miniapp/public/tonconnect-manifest.json`:

```json
{
  "url": "https://terminal.aapka-domain.com",
  "name": "TON NFT Trading Terminal",
  "iconUrl": "https://terminal.aapka-domain.com/icons/icon-180.png",
  "termsOfUseUrl": "https://terminal.aapka-domain.com/terms.html",
  "privacyPolicyUrl": "https://terminal.aapka-domain.com/privacy.html"
}
```

Phir `cd miniapp && npm run build` (ya docker compose rebuild).

---

## 7. Local testing bina domain ke (ngrok)

```bash
ngrok http 8000                       # HTTPS URL milega
# .env me:  TON_APP_URL=https://xxxx.ngrok-free.app
# BotFather /newapp me wahi URL
```

Ngrok free URL har restart par badalta hai — sirf testing ke liye.

---

## 8. Deploy ke baad checklist

```bash
curl https://terminal.aapka-domain.com/api/health        # ok
curl https://terminal.aapka-domain.com/api/providers     # kaun live / unavailable
curl https://terminal.aapka-domain.com/tonconnect-manifest.json
docker compose logs -f bot                                # bot polling chal raha?
```

Telegram me:
1. Bot khojo → `/start` → **“Open Terminal”** button → Mini App khulna chahiye.
2. Mini App me **Connect wallet** → wallet approve → address dikhna chahiye.
3. `/scan <collection>` → real data aana chahiye.
4. Swap quote try karo → live STON.fi rate.

### Webhook mode chuno toh

```bash
curl -X POST https://terminal.aapka-domain.com/telegram/webhook/setup \
  -H "X-Telegram-Bot-Api-Secret-Token: $TELEGRAM_WEBHOOK_SECRET"
curl https://terminal.aapka-domain.com/telegram/webhook/info \
  -H "X-Telegram-Bot-Api-Secret-Token: $TELEGRAM_WEBHOOK_SECRET"
```
Phir bot service command webhook mode me chalao (`bot` container pehle se webhook-capable API ke sath chal raha hai; polling service ko rok dena).

---

## 9. Live money chalane se pehle

1. `TON_NETWORK=mainnet`, `DEV_MODE=false`
2. `TONCENTER_API_KEY` set (429 se bachne ke liye)
3. Paper Mode me strategy test karo (`/strategy`)
4. `ENABLE_REAL_TRADING=true`, `MAX_BUY_PRICE_TON`, `MAX_SLIPPAGE` sane rakho
5. Portals access mile tabhi buy/sell live hoga — warna UI honestly “execution unavailable” bolega

---

## 10. Common errors

| Error | Fix |
|---|---|
| Telegram Mini App blank / 401 | `DEV_MODE=false` + `TON_APP_URL` galat, ya Telegram ke bahar khol rahe ho |
| “manifest not reachable” | `TON_APP_URL` HTTPS nahi, ya `miniapp/public/tonconnect-manifest.json` update nahi hua |
| API `429` | `TONCENTER_API_KEY` daalo |
| Bot reply nahi de raha | token missing / polling aur webhook dono chal rahe |
| Port busy 8000 | `docker compose ps`, purani process band karo |
| DB migration fail | `docker compose exec api python -m alembic upgrade head` |
