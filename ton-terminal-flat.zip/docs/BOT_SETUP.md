# Telegram bot & Mini App setup

## 1. Create the bot

1. Talk to [@BotFather](https://t.me/BotFather) → `/newbot`.
2. Copy the token into `.env` → `TELEGRAM_BOT_TOKEN=…` (server-side only, never shipped to the client).
3. Register the command list (the bot also sets it at startup):

```
start — Welcome & Mini App
help — All commands
wallet — Connect wallet & balances
radar — Live NFT opportunities
scan — Scan a collection
analyze — Full NFT analysis
buy — Prepare a purchase
sell — Prepare a listing
swap — Quote a TON/USDT swap
portfolio — Holdings & P/L
watchlist — Price & discount alerts
strategy — Strategy builder
history — Trades & transactions
settings — Notifications & risk
```

## 2. Connect the Mini App

1. `/newapp` in BotFather (or `Edit Bot` → `Menu Button` → `Configure Menu Button`).
2. Point the Web App URL at the **public HTTPS** deployment of this API (`https://…/` serves the
   built Mini App). `http://localhost` only works locally with a tunnel.
3. Put the same URL into `TON_APP_URL` (used for the TON Connect manifest and the button).
4. TON Connect needs an HTTPS-reachable manifest: the backend serves
   `/tonconnect-manifest.json`. `miniapp/public/tonconnect-manifest.json` is the build-time copy —
   keep both `url`, `iconUrl` and the policy URLs in sync with your domain.

## 3. ⭐ Custom emoji ids

All ids live in **one** dict: `app/bot/emojis.py → CUSTOM_EMOJIS`.

```python
CUSTOM_EMOJIS = {
    "one": "5247133031235329609",
    ...
    "wallet": "",      # fill in as you collect ids
}
```

How to obtain them:

1. Open Telegram → Settings → **Emoji Status / Custom Emoji** (or any premium sticker pack served as
   custom emoji) → copy the link/share the emoji.
2. In a private chat with [@RawDataBot](https://t.me/RawDataBot) (or via `getCustomEmojiStickers`),
   forward the emoji and read `custom_emoji_id`.
3. Paste the id into `CUSTOM_EMOJIS` — nothing else needs to change.

Messages never print the id: `render()` turns `{name}` tokens into
`MessageEntity(type="custom_emoji", custom_emoji_id=…)` entities over a placeholder glyph.
Missing or malformed ids fall back to the Unicode glyph (`FALLBACK_EMOJIS`) and are listed by
`validate_ids()`.

Current status: the six supplied numeric ids are wired up; the ids for
wallet/ton/usdt/nft/buy/sell/swap/radar/profit/loss/warning/success/analytics/rarity/collection/
whale/market/portfolio/strategy/settings/security/verified/notification/error are intentionally empty
pending your values — the Unicode fallback keeps everything readable until then.

## 4. Polling vs webhook

* Local/dev: `make bot` (long polling).
* Production: set `TELEGRAM_WEBHOOK_URL=https://your-domain/telegram/webhook` and
  `TELEGRAM_WEBHOOK_SECRET` (compared with `hmac.compare_digest` against the
  `X-Telegram-Bot-Api-Secret-Token` header). Then either call
  `POST /telegram/webhook/setup` (requires the secret header) or let Telegram deliver updates to
  `POST /telegram/webhook`. `GET /telegram/webhook/info` shows the current state.

## 5. Security reminders

* The bot never asks for a seed phrase, private key or password.
* Every transaction is approved by the user in their own wallet.
* Real-money execution stays disabled until `ENABLE_REAL_TRADING=true`.
